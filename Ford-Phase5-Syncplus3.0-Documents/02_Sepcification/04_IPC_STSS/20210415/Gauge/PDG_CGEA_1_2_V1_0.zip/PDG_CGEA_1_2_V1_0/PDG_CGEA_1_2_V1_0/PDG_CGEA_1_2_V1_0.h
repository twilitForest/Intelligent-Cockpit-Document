/*
 * File: PDG_CGEA_1_2_V1_0.h
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V1_0'.
 *
 * Model version                  : 1.1158
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Wed May 07 13:06:48 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (7), Warnings (3), Error (0)
 */

#ifndef RTW_HEADER_PDG_CGEA_1_2_V1_0_h_
#define RTW_HEADER_PDG_CGEA_1_2_V1_0_h_
#ifndef PDG_CGEA_1_2_V1_0_COMMON_INCLUDES_
# define PDG_CGEA_1_2_V1_0_COMMON_INCLUDES_
#include <math.h>
#include <stddef.h>
#include <string.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#endif                                 /* PDG_CGEA_1_2_V1_0_COMMON_INCLUDES_ */

#include "PDG_CGEA_1_2_V1_0_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Switch;                       /* '<S8>/Switch' */
  real_T Switch2;                      /* '<S8>/Switch2' */
  real_T pg_decay_rise_fall_switch;    /* '<S5>/rising_or_falling' */
  real_T pg_torque_in_for_tc_filter_minu;/* '<S9>/Subtract1' */
  real_T output;                       /* '<S5>/DynamicSwitch' */
  real32_T pg_decay_output_unit_delay; /* '<S5>/Unit Delay' */
  real32_T Sum1;                       /* '<S5>/Sum1' */
  real32_T pre_decay_output_unit_delay;/* '<S9>/Unit Delay' */
  real32_T pg_torque_with_delay_times_tc_i;/* '<S9>/Product1' */
  real32_T PrplWhlTot_Tq_Actl_filt;    /* '<S9>/Subtract' */
  real32_T Yk1;                        /* '<S2>/UD' */
  real32_T Switch_m;                   /* '<S3>/Switch' */
  real32_T Yk1Uk;                      /* '<S2>/Diff' */
  real32_T PoleYk1Uk;                  /* '<S2>/Product' */
  real32_T Sum;                        /* '<S2>/Sum' */
  boolean_T LowerRelop1;               /* '<S8>/LowerRelop1' */
  boolean_T UpperRelop;                /* '<S8>/UpperRelop' */
  boolean_T output_o;                  /* '<S3>/DynamicCompare' */
} BlockIO_PDG_CGEA_1_2_V1_0;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T Sum1_DWORK1;                  /* '<S5>/Sum1' */
  real32_T UnitDelay_DSTATE;           /* '<S5>/Unit Delay' */
  real32_T UnitDelay_DSTATE_e;         /* '<S9>/Unit Delay' */
  real32_T UD_DSTATE;                  /* '<S2>/UD' */
  real32_T Front_Power;                /* '<S1>/PDG' */
  real32_T Max_Power;                  /* '<S1>/PDG' */
  real32_T Rear_Power;                 /* '<S1>/PDG' */
} D_Work_PDG_CGEA_1_2_V1_0;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T prpwhltot_tq_actl;            /* '<Root>/prpwhltot_tq_actl' */
  real32_T veh_v_actleng;              /* '<Root>/veh_v_actleng' */
  real32_T awdlck_tq_req;              /* '<Root>/awdlck_tq_req' */
  real32_T AwdRng_D_Actl;              /* '<Root>/AwdRng_D_Actl' */
  real32_T AwdRngFalt_D_Stat;          /* '<Root>/AwdRngFalt_D_Stat' */
  real_T GearLvrPos_D_Actl;            /* '<Root>/GearLvrPos_D_Actl' */
  real32_T PG_LINEARITY_FACTOR;        /* '<Root>/PG_LINEARITY_FACTOR' */
  real32_T PG_MAX_POWER_VALUE;         /* '<Root>/PG_MAX_POWER_VALUE' */
  real32_T PG_WHL_TRQ_FILTER;          /* '<Root>/PG_WHL_TRQ_FILTER' */
  real32_T PG_PERCENT_FILL_CONV_CONSTANT;/* '<Root>/PG_PERCENT_FILL_CONV_CONSTANT' */
  real32_T PG_POWER_CONV_CONSTANT;     /* '<Root>/PG_POWER_CONV_CONSTANT' */
  real32_T PG_POWER_MULTIPLIER;        /* '<Root>/PG_POWER_MULTIPLIER' */
  real32_T PG_REAR_AXLE_RATIO;         /* '<Root>/PG_REAR_AXLE_RATIO' */
  real32_T PG_WHEEL_RPM_CONV_CONSTANT; /* '<Root>/PG_WHEEL_RPM_CONV_CONSTANT' */
  real_T PG_DECAY_RISING;              /* '<Root>/PG_DECAY_RISING' */
  real_T PG_DECAY_FALLING_HI_TORQ;     /* '<Root>/PG_DECAY_FALLING_HI_TORQ' */
  real_T PG_PT_TORQUE_MAX;             /* '<Root>/PG_PT_TORQUE_MAX' */
  real_T PG_DECAY_FALLING_LO_TORQ;     /* '<Root>/PG_DECAY_FALLING_LO_TORQ' */
  real_T PG_PRPLWHL_TQ_LOW_LIMIT;      /* '<Root>/PG_PRPLWHL_TQ_LOW_LIMIT' */
  real_T PG_DECAY_FALLING_SWITCHPOINT; /* '<Root>/PG_DECAY_FALLING_SWITCHPOINT' */
} ExternalInputs_PDG_CGEA_1_2_V1_;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real32_T PG_front_percent_fill;      /* '<Root>/PG_front_percent_fill' */
  real32_T PG_rear_percent_fill;       /* '<Root>/PG_rear_percent_fill' */
} ExternalOutputs_PDG_CGEA_1_2_V1;

/* Parameters (auto storage) */
struct Parameters_PDG_CGEA_1_2_V1_0_ {
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S5>/Constant'
                                        */
  real32_T Constant_Value_j;           /* Computed Parameter: Constant_Value_j
                                        * Referenced by: '<S3>/Constant'
                                        */
  real32_T UnitDelay_InitialCondition; /* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S5>/Unit Delay'
                                        */
  real32_T rising_or_falling_Threshold;/* Computed Parameter: rising_or_falling_Threshold
                                        * Referenced by: '<S5>/rising_or_falling'
                                        */
  real32_T UnitDelay_InitialCondition_o;/* Computed Parameter: UnitDelay_InitialCondition_o
                                         * Referenced by: '<S9>/Unit Delay'
                                         */
  real32_T UD_InitialCondition;        /* Computed Parameter: UD_InitialCondition
                                        * Referenced by: '<S2>/UD'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_PDG_CGEA_1_2_V1_0 {
  const char_T * volatile errorStatus;
};

/* Block parameters (auto storage) */
extern Parameters_PDG_CGEA_1_2_V1_0 PDG_CGEA_1_2_V1_0_P;

/* Block signals (auto storage) */
extern BlockIO_PDG_CGEA_1_2_V1_0 PDG_CGEA_1_2_V1_0_B;

/* Block states (auto storage) */
extern D_Work_PDG_CGEA_1_2_V1_0 PDG_CGEA_1_2_V1_0_DWork;

/* External inputs (root inport signals with auto storage) */
extern ExternalInputs_PDG_CGEA_1_2_V1_ PDG_CGEA_1_2_V1_0_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExternalOutputs_PDG_CGEA_1_2_V1 PDG_CGEA_1_2_V1_0_Y;

/* Model entry point functions */
extern void PDG_CGEA_1_2_V1_0_initialize(void);
extern void PDG_CGEA_1_2_V1_0_step(void);
extern void PDG_CGEA_1_2_V1_0_terminate(void);

/* Real-time Model object */
extern RT_MODEL_PDG_CGEA_1_2_V1_0 *const PDG_CGEA_1_2_V1_0_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PDG_CGEA_1_2_V1_0'
 * '<S1>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge'
 * '<S2>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/Dynamic Pole'
 * '<S3>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/Engine_Brake_Logic'
 * '<S4>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/PDG'
 * '<S5>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/PG Torque Decay'
 * '<S6>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/Engine_Brake_Logic/DynamicCompare'
 * '<S7>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/PG Torque Decay/DynamicSwitch'
 * '<S8>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/PG Torque Decay/Saturation Dynamic'
 * '<S9>'   : 'PDG_CGEA_1_2_V1_0/Power Gauge/PG Torque Decay/TC filter'
 */
#endif                                 /* RTW_HEADER_PDG_CGEA_1_2_V1_0_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
