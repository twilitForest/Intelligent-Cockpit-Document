/*
 * File: PDG_CGEA_1_2_V1_0_data.c
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V1_0'.
 *
 * Model version                  : 1.1158
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Wed May 07 13:06:48 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (7), Warnings (3), Error (0)
 */

#include "PDG_CGEA_1_2_V1_0.h"
#include "PDG_CGEA_1_2_V1_0_private.h"

/* Block parameters (auto storage) */
Parameters_PDG_CGEA_1_2_V1_0 PDG_CGEA_1_2_V1_0_P = {
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S5>/Constant'
                                        */
  0.0F,                                /* Computed Parameter: Constant_Value_j
                                        * Referenced by: '<S3>/Constant'
                                        */
  0.0F,                                /* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S5>/Unit Delay'
                                        */
  0.0F,                                /* Computed Parameter: rising_or_falling_Threshold
                                        * Referenced by: '<S5>/rising_or_falling'
                                        */
  0.0F,                                /* Computed Parameter: UnitDelay_InitialCondition_o
                                        * Referenced by: '<S9>/Unit Delay'
                                        */
  0.0F                                 /* Computed Parameter: UD_InitialCondition
                                        * Referenced by: '<S2>/UD'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
