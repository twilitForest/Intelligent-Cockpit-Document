/*
 * File: PDG_CGEA_1_2_V1_0_private.h
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V1_0'.
 *
 * Model version                  : 1.1158
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Wed May 07 13:06:48 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (7), Warnings (3), Error (0)
 */

#ifndef RTW_HEADER_PDG_CGEA_1_2_V1_0_private_h_
#define RTW_HEADER_PDG_CGEA_1_2_V1_0_private_h_
#include "rtwtypes.h"
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

extern real32_T rt_powf_snf(real32_T u0, real32_T u1);

/* Exported functions */
#endif                                 /* RTW_HEADER_PDG_CGEA_1_2_V1_0_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
