/*
* File: ert_main.c
*
* Code generated for Simulink model 'PDG_CGEA_1_2_V1_0'.
*
* Model version                  : 1.1158
* Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
* TLC version                    : 8.3 (Jul 21 2012)
* C/C++ source code generated on : Wed May 07 13:06:48 2014
*
* Target selection: ert.tlc
* Embedded hardware selection: Generic->Custom
* Code generation objectives:
*    1. MISRA-C:2004 guidelines
*    2. Execution efficiency
* Validation result: Passed (7), Warnings (3), Error (0)
*/

#include <stdio.h>                     /* This ert_main.c example uses printf/fflush */
#include "PDG_CGEA_1_2_V1_0.h"         /* Model's header file */
#include "rtwtypes.h"                  /* MathWorks types */

/*
* Associating rt_OneStep with a real-time clock or interrupt service routine
* is what makes the generated code "real-time".  The function rt_OneStep is
* always associated with the base rate of the model.  Subrates are managed
* by the base rate from inside the generated code.  Enabling/disabling
* interrupts and floating point context switches are target specific.  This
* example code indicates where these should take place relative to executing
* the generated code step function.  Overrun behavior should be tailored to
* your application needs.  This example simply sets an error status in the
* real-time model and returns from rt_OneStep.
*/
void rt_OneStep(void);
void rt_OneStep(void)
{
	static boolean_T OverrunFlag = 0;

	/* Disable interrupts here */

	/* Check for overrun */
	if (OverrunFlag) {
		rtmSetErrorStatus(PDG_CGEA_1_2_V1_0_M, "Overrun");
		return;
	}

	OverrunFlag = TRUE;

	/* Save FPU context here (if necessary) */
	/* Re-enable timer or interrupt here */
	/* Set model inputs here */

	/* Step the model */
	PDG_CGEA_1_2_V1_0_step();

	/* Get model outputs here */

	/* Indicate task complete */
	OverrunFlag = FALSE;

	/* Disable interrupts here */
	/* Restore FPU context here (if necessary) */
	/* Enable interrupts here */
}

/*
* The example "main" function illustrates what is required by your
* application code to initialize, execute, and terminate the generated code.
* Attaching rt_OneStep to a real-time clock is target specific.  This example
* illustates how you do this relative to initializing the model.
*/
int_T main(int_T argc, const char_T *argv[]);
int_T main(int_T argc, const char_T *argv[])
{
	FILE * IN;
	FILE * OUT;

	float awdlck_tq_req    	  = 0;
	float AwdRngFalt_D_Stat	  = 0;
	float AwdRng_D_Actl    	  = 0;
	float GearLvrPos_D_Actl	  = 0;
	float prpwhltot_tq_actl	  = 0;
	float veh_v_actleng    	  = 0;

	/* Initialize model */
	PDG_CGEA_1_2_V1_0_initialize();

	/* Attach rt_OneStep to a timer or interrupt service routine with
	* period 0.016 seconds (the model's base sample time) here.  The
	* call syntax for rt_OneStep is
	*
	*  rt_OneStep();
	*/

	PDG_CGEA_1_2_V1_0_U.PG_LINEARITY_FACTOR           = .8;
	PDG_CGEA_1_2_V1_0_U.PG_MAX_POWER_VALUE            = 120;
	PDG_CGEA_1_2_V1_0_U.PG_WHL_TRQ_FILTER             = .1;
	PDG_CGEA_1_2_V1_0_U.PG_PERCENT_FILL_CONV_CONSTANT = .65;
	PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT        = 32000;
	PDG_CGEA_1_2_V1_0_U.PG_POWER_MULTIPLIER           = 1;
	PDG_CGEA_1_2_V1_0_U.PG_REAR_AXLE_RATIO		      = 3.73;
	PDG_CGEA_1_2_V1_0_U.PG_WHEEL_RPM_CONV_CONSTANT	  = 6.64;
	PDG_CGEA_1_2_V1_0_U.PG_DECAY_RISING				  = .5;
	PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_HI_TORQ	  = .5;
	PDG_CGEA_1_2_V1_0_U.PG_PT_TORQUE_MAX			  = 4000;
	PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_LO_TORQ	  = .35;
	PDG_CGEA_1_2_V1_0_U.PG_PRPLWHL_TQ_LOW_LIMIT		  = 1;
	PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_SWITCHPOINT  = 500;
	

	IN = fopen ("WOT_Turn_Tip_TipTurn.csv","r");
	OUT = fopen ("Results_WOT_Turn_Tip_TipTurn.csv","w+");

	while(fscanf(IN,"%f,%f,%f,%f,%f,%f\n",&(awdlck_tq_req     )
								         ,&(AwdRngFalt_D_Stat )
								         ,&(AwdRng_D_Actl     )
								         ,&(GearLvrPos_D_Actl )
								         ,&(prpwhltot_tq_actl )
										 ,&(veh_v_actleng     )) != EOF)
	{

		PDG_CGEA_1_2_V1_0_U.awdlck_tq_req	  =	awdlck_tq_req     ;
		PDG_CGEA_1_2_V1_0_U.AwdRngFalt_D_Stat =	AwdRngFalt_D_Stat ;
		PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl	  =	AwdRng_D_Actl     ;
		PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl =	GearLvrPos_D_Actl ;
		PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl =	prpwhltot_tq_actl ;
		PDG_CGEA_1_2_V1_0_U.veh_v_actleng	  =	veh_v_actleng     ;

		printf("%f,",PDG_CGEA_1_2_V1_0_U.awdlck_tq_req);
		printf("%f,",PDG_CGEA_1_2_V1_0_U.AwdRngFalt_D_Stat);
		printf("%f,",PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl);
		printf("%f,",PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl);
		printf("%f,",PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl);
		printf("%f,",PDG_CGEA_1_2_V1_0_U.veh_v_actleng);
		rt_OneStep();
		printf("%f, %f \n",PDG_CGEA_1_2_V1_0_Y.PG_front_percent_fill,PDG_CGEA_1_2_V1_0_Y.PG_rear_percent_fill);
		
		fprintf(OUT,"%f,%f,%f,%f,%f,%f,%f,%f\n",PDG_CGEA_1_2_V1_0_U.awdlck_tq_req,
										        PDG_CGEA_1_2_V1_0_U.AwdRngFalt_D_Stat,
										        PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl,
										        PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl,
										        PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl,
										        PDG_CGEA_1_2_V1_0_U.veh_v_actleng,
										        PDG_CGEA_1_2_V1_0_Y.PG_front_percent_fill,
										        PDG_CGEA_1_2_V1_0_Y.PG_rear_percent_fill);
	}

	fclose(IN);
	fclose(OUT);

	/* Disable rt_OneStep() here */

	/* Terminate model */
PDG_CGEA_1_2_V1_0_terminate();
	return 0;
}

/*
* File trailer for generated code.
*
* [EOF]
*/
