/*
 * File: PDG_CGEA_1_2_V1_0_types.h
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V1_0'.
 *
 * Model version                  : 1.1158
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Wed May 07 13:06:48 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (7), Warnings (3), Error (0)
 */

#ifndef RTW_HEADER_PDG_CGEA_1_2_V1_0_types_h_
#define RTW_HEADER_PDG_CGEA_1_2_V1_0_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_PDG_CGEA_1_2_V1_0_ Parameters_PDG_CGEA_1_2_V1_0;

/* Forward declaration for rtModel */
typedef struct tag_RTM_PDG_CGEA_1_2_V1_0 RT_MODEL_PDG_CGEA_1_2_V1_0;

#endif                                 /* RTW_HEADER_PDG_CGEA_1_2_V1_0_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
