/*
 * File: PDG_CGEA_1_2_V1_0.c
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V1_0'.
 *
 * Model version                  : 1.1158
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Wed May 07 13:06:48 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (7), Warnings (3), Error (0)
 */

#include "PDG_CGEA_1_2_V1_0.h"
#include "PDG_CGEA_1_2_V1_0_private.h"

/* Block signals (auto storage) */
BlockIO_PDG_CGEA_1_2_V1_0 PDG_CGEA_1_2_V1_0_B;

/* Block states (auto storage) */
D_Work_PDG_CGEA_1_2_V1_0 PDG_CGEA_1_2_V1_0_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_PDG_CGEA_1_2_V1_ PDG_CGEA_1_2_V1_0_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_PDG_CGEA_1_2_V1 PDG_CGEA_1_2_V1_0_Y;

/* Real-time model */
RT_MODEL_PDG_CGEA_1_2_V1_0 PDG_CGEA_1_2_V1_0_M_;
RT_MODEL_PDG_CGEA_1_2_V1_0 *const PDG_CGEA_1_2_V1_0_M = &PDG_CGEA_1_2_V1_0_M_;
real32_T rt_powf_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  real32_T tmp;
  real32_T tmp_0;
  if (rtIsNaNF(u0) || rtIsNaNF(u1)) {
    y = (rtNaNF);
  } else {
    tmp = (real32_T)fabs(u0);
    tmp_0 = (real32_T)fabs(u1);
    if (rtIsInfF(u1)) {
      if (tmp == 1.0F) {
        y = (rtNaNF);
      } else if (tmp > 1.0F) {
        if (u1 > 0.0F) {
          y = (rtInfF);
        } else {
          y = 0.0F;
        }
      } else if (u1 > 0.0F) {
        y = 0.0F;
      } else {
        y = (rtInfF);
      }
    } else if (tmp_0 == 0.0F) {
      y = 1.0F;
    } else if (tmp_0 == 1.0F) {
      if (u1 > 0.0F) {
        y = u0;
      } else {
        y = 1.0F / u0;
      }
    } else if (u1 == 2.0F) {
      y = u0 * u0;
    } else if ((u1 == 0.5F) && (u0 >= 0.0F)) {
      y = (real32_T)sqrt(u0);
    } else if ((u0 < 0.0F) && (u1 > (real32_T)floor(u1))) {
      y = (rtNaNF);
    } else {
      y = (real32_T)pow(u0, u1);
    }
  }

  return y;
}

/* Model step function */
void PDG_CGEA_1_2_V1_0_step(void)
{
  real32_T Rear_Axle_Torque;
  real32_T Wheel_RPM;
  boolean_T guard = FALSE;

  /* UnitDelay: '<S5>/Unit Delay' */
  PDG_CGEA_1_2_V1_0_B.pg_decay_output_unit_delay =
    PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE;

  /* RelationalOperator: '<S8>/LowerRelop1' incorporates:
   *  Inport: '<Root>/PG_PT_TORQUE_MAX'
   *  Inport: '<Root>/prpwhltot_tq_actl'
   */
  PDG_CGEA_1_2_V1_0_B.LowerRelop1 = (PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl >
    PDG_CGEA_1_2_V1_0_U.PG_PT_TORQUE_MAX);

  /* RelationalOperator: '<S8>/UpperRelop' incorporates:
   *  Constant: '<S5>/Constant'
   *  Inport: '<Root>/prpwhltot_tq_actl'
   */
  PDG_CGEA_1_2_V1_0_B.UpperRelop = (PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl <
    PDG_CGEA_1_2_V1_0_P.Constant_Value);

  /* Switch: '<S8>/Switch' incorporates:
   *  Constant: '<S5>/Constant'
   *  Inport: '<Root>/prpwhltot_tq_actl'
   */
  if (PDG_CGEA_1_2_V1_0_B.UpperRelop) {
    PDG_CGEA_1_2_V1_0_B.Switch = PDG_CGEA_1_2_V1_0_P.Constant_Value;
  } else {
    PDG_CGEA_1_2_V1_0_B.Switch = PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl;
  }

  /* End of Switch: '<S8>/Switch' */

  /* Switch: '<S8>/Switch2' incorporates:
   *  Inport: '<Root>/PG_PT_TORQUE_MAX'
   */
  if (PDG_CGEA_1_2_V1_0_B.LowerRelop1) {
    PDG_CGEA_1_2_V1_0_B.Switch2 = PDG_CGEA_1_2_V1_0_U.PG_PT_TORQUE_MAX;
  } else {
    PDG_CGEA_1_2_V1_0_B.Switch2 = PDG_CGEA_1_2_V1_0_B.Switch;
  }

  /* End of Switch: '<S8>/Switch2' */

  /* Sum: '<S5>/Sum1' */
  PDG_CGEA_1_2_V1_0_B.Sum1 = (real32_T)(PDG_CGEA_1_2_V1_0_B.Switch2 - (real_T)
    PDG_CGEA_1_2_V1_0_B.pg_decay_output_unit_delay);

  /* Chart: '<S5>/DynamicSwitch' incorporates:
   *  Inport: '<Root>/PG_DECAY_FALLING_HI_TORQ'
   *  Inport: '<Root>/PG_DECAY_FALLING_LO_TORQ'
   *  Inport: '<Root>/PG_DECAY_FALLING_SWITCHPOINT'
   */
  /* Gateway: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* During: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* Entry Internal: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* Transition: '<S7>:12' */
  if (PDG_CGEA_1_2_V1_0_B.Switch2 >=
      PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_SWITCHPOINT) {
    /* Transition: '<S7>:15' */
    /* Transition: '<S7>:20' */
    PDG_CGEA_1_2_V1_0_B.output = PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_HI_TORQ;

    /* Transition: '<S7>:24' */
  } else {
    if (PDG_CGEA_1_2_V1_0_B.Switch2 <
        PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_SWITCHPOINT) {
      /* Transition: '<S7>:16' */
      /* Transition: '<S7>:19' */
      PDG_CGEA_1_2_V1_0_B.output = PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_LO_TORQ;

      /* Transition: '<S7>:22' */
    }
  }

  /* End of Chart: '<S5>/DynamicSwitch' */

  /* Switch: '<S5>/rising_or_falling' incorporates:
   *  Inport: '<Root>/PG_DECAY_RISING'
   */
  if (PDG_CGEA_1_2_V1_0_B.Sum1 >=
      PDG_CGEA_1_2_V1_0_P.rising_or_falling_Threshold) {
    PDG_CGEA_1_2_V1_0_B.pg_decay_rise_fall_switch =
      PDG_CGEA_1_2_V1_0_U.PG_DECAY_RISING;
  } else {
    PDG_CGEA_1_2_V1_0_B.pg_decay_rise_fall_switch = PDG_CGEA_1_2_V1_0_B.output;
  }

  /* End of Switch: '<S5>/rising_or_falling' */

  /* UnitDelay: '<S9>/Unit Delay' */
  PDG_CGEA_1_2_V1_0_B.pre_decay_output_unit_delay =
    PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE_e;

  /* Sum: '<S9>/Subtract1' */
  PDG_CGEA_1_2_V1_0_B.pg_torque_in_for_tc_filter_minu = (real_T)
    PDG_CGEA_1_2_V1_0_B.pre_decay_output_unit_delay -
    PDG_CGEA_1_2_V1_0_B.Switch2;

  /* Product: '<S9>/Product1' */
  PDG_CGEA_1_2_V1_0_B.pg_torque_with_delay_times_tc_i = (real32_T)
    (PDG_CGEA_1_2_V1_0_B.pg_decay_rise_fall_switch *
     PDG_CGEA_1_2_V1_0_B.pg_torque_in_for_tc_filter_minu);

  /* Sum: '<S9>/Subtract' */
  PDG_CGEA_1_2_V1_0_B.PrplWhlTot_Tq_Actl_filt =
    PDG_CGEA_1_2_V1_0_B.pre_decay_output_unit_delay -
    PDG_CGEA_1_2_V1_0_B.pg_torque_with_delay_times_tc_i;

  /* UnitDelay: '<S2>/UD' */
  PDG_CGEA_1_2_V1_0_B.Yk1 = PDG_CGEA_1_2_V1_0_DWork.UD_DSTATE;

  /* Chart: '<S3>/DynamicCompare' incorporates:
   *  Inport: '<Root>/PG_PRPLWHL_TQ_LOW_LIMIT'
   *  Inport: '<Root>/prpwhltot_tq_actl'
   */
  /* Gateway: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* During: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* Entry Internal: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* Transition: '<S6>:2' */
  if (PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl <=
      PDG_CGEA_1_2_V1_0_U.PG_PRPLWHL_TQ_LOW_LIMIT) {
    /* Transition: '<S6>:5' */
    /* Transition: '<S6>:13' */
    PDG_CGEA_1_2_V1_0_B.output_o = TRUE;

    /* Transition: '<S6>:12' */
  } else {
    if (PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl >
        PDG_CGEA_1_2_V1_0_U.PG_PRPLWHL_TQ_LOW_LIMIT) {
      /* Transition: '<S6>:6' */
      /* Transition: '<S6>:10' */
      PDG_CGEA_1_2_V1_0_B.output_o = FALSE;

      /* Transition: '<S6>:11' */
    }
  }

  /* End of Chart: '<S3>/DynamicCompare' */

  /* Switch: '<S3>/Switch' incorporates:
   *  Constant: '<S3>/Constant'
   *  Inport: '<Root>/awdlck_tq_req'
   */
  if (PDG_CGEA_1_2_V1_0_B.output_o) {
    PDG_CGEA_1_2_V1_0_B.Switch_m = PDG_CGEA_1_2_V1_0_P.Constant_Value_j;
  } else {
    PDG_CGEA_1_2_V1_0_B.Switch_m = PDG_CGEA_1_2_V1_0_U.awdlck_tq_req;
  }

  /* End of Switch: '<S3>/Switch' */

  /* Sum: '<S2>/Diff' */
  PDG_CGEA_1_2_V1_0_B.Yk1Uk = PDG_CGEA_1_2_V1_0_B.Yk1 -
    PDG_CGEA_1_2_V1_0_B.Switch_m;

  /* Product: '<S2>/Product' incorporates:
   *  Inport: '<Root>/PG_WHL_TRQ_FILTER'
   */
  PDG_CGEA_1_2_V1_0_B.PoleYk1Uk = PDG_CGEA_1_2_V1_0_U.PG_WHL_TRQ_FILTER *
    PDG_CGEA_1_2_V1_0_B.Yk1Uk;

  /* Sum: '<S2>/Sum' */
  PDG_CGEA_1_2_V1_0_B.Sum = PDG_CGEA_1_2_V1_0_B.PoleYk1Uk +
    PDG_CGEA_1_2_V1_0_B.Switch_m;

  /* Chart: '<S1>/PDG' incorporates:
   *  Inport: '<Root>/AwdRngFalt_D_Stat'
   *  Inport: '<Root>/AwdRng_D_Actl'
   *  Inport: '<Root>/GearLvrPos_D_Actl'
   *  Inport: '<Root>/PG_MAX_POWER_VALUE'
   *  Inport: '<Root>/PG_POWER_CONV_CONSTANT'
   *  Inport: '<Root>/PG_POWER_MULTIPLIER'
   *  Inport: '<Root>/PG_REAR_AXLE_RATIO'
   *  Inport: '<Root>/PG_WHEEL_RPM_CONV_CONSTANT'
   *  Inport: '<Root>/veh_v_actleng'
   */
  /* Gateway: Power Gauge/PDG */
  /* During: Power Gauge/PDG */
  /* Entry Internal: Power Gauge/PDG */
  /* Transition: '<S4>:33' */
  /* ReverseDriveSportDLowfirstsecondthirdfourthfifthsixth */
  if (((PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == 0.0F) ||
       (PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == (real32_T)0x4) ||
       (PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == (real32_T)0x5) ||
       (PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == (real32_T)0x6)) &&
      ((PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x1) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x3) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x4) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x5) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x6) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x7) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x8) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0x9) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0xA) ||
       (PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl == (real_T)0xB))) {
    /* Transition: '<S4>:12' */
    if (PDG_CGEA_1_2_V1_0_U.AwdRngFalt_D_Stat != 1.0F) {
      /* Transition: '<S4>:30' */
      if (PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == (real32_T)0x5) {
        /* Transition: '<S4>:15' */
        /* 4x4 Auto Mode */
        /* Transition: '<S4>:9' */
        Wheel_RPM = PDG_CGEA_1_2_V1_0_U.veh_v_actleng *
          PDG_CGEA_1_2_V1_0_U.PG_WHEEL_RPM_CONV_CONSTANT;
        PDG_CGEA_1_2_V1_0_DWork.Max_Power =
          PDG_CGEA_1_2_V1_0_U.PG_MAX_POWER_VALUE;
        PDG_CGEA_1_2_V1_0_DWork.Front_Power = PDG_CGEA_1_2_V1_0_B.Sum *
          PDG_CGEA_1_2_V1_0_U.PG_REAR_AXLE_RATIO * Wheel_RPM /
          PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT;
        PDG_CGEA_1_2_V1_0_DWork.Rear_Power = (real32_T)fabs
          (PDG_CGEA_1_2_V1_0_B.PrplWhlTot_Tq_Actl_filt) * Wheel_RPM /
          PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT;

        /* Transition: '<S4>:17' */
      } else {
        /* Transition: '<S4>:16' */
      }

      /* Transition: '<S4>:18' */
      if ((PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == 0.0F) ||
          (PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == (real32_T)0x4)) {
        /* Transition: '<S4>:19' */
        /* 4x4 High or 4x4 Low Mode */
        /* Transition: '<S4>:27' */
        Rear_Axle_Torque = (real32_T)fabs
          (PDG_CGEA_1_2_V1_0_B.PrplWhlTot_Tq_Actl_filt);
        Wheel_RPM = PDG_CGEA_1_2_V1_0_U.veh_v_actleng *
          PDG_CGEA_1_2_V1_0_U.PG_WHEEL_RPM_CONV_CONSTANT;
        PDG_CGEA_1_2_V1_0_DWork.Max_Power =
          PDG_CGEA_1_2_V1_0_U.PG_MAX_POWER_VALUE;
        PDG_CGEA_1_2_V1_0_DWork.Front_Power = Rear_Axle_Torque * Wheel_RPM /
          PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT;
        PDG_CGEA_1_2_V1_0_DWork.Rear_Power = Rear_Axle_Torque * Wheel_RPM /
          PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT;

        /* Transition: '<S4>:25' */
      } else {
        /* Transition: '<S4>:21' */
      }

      /* Transition: '<S4>:11' */
      guard = TRUE;
    } else {
      /* Transition: '<S4>:14' */
      if (PDG_CGEA_1_2_V1_0_U.AwdRngFalt_D_Stat == 1.0F) {
        /* Transition: '<S4>:31' */
        guard = TRUE;
      } else {
        /* Outport: '<Root>/PG_front_percent_fill' */
        /* Transition: '<S4>:32' */
        PDG_CGEA_1_2_V1_0_Y.PG_front_percent_fill = 0.0F;

        /* Outport: '<Root>/PG_rear_percent_fill' */
        PDG_CGEA_1_2_V1_0_Y.PG_rear_percent_fill = 0.0F;
      }
    }

    if (guard) {
      if ((PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl == (real32_T)0x6) ||
          ((PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl != (real32_T)0x6) &&
           (PDG_CGEA_1_2_V1_0_U.AwdRngFalt_D_Stat == 1.0F))) {
        /* Transition: '<S4>:4' */
        /* 4x2 High Mode */
        /* Transition: '<S4>:3' */
        Wheel_RPM = PDG_CGEA_1_2_V1_0_U.veh_v_actleng *
          PDG_CGEA_1_2_V1_0_U.PG_WHEEL_RPM_CONV_CONSTANT;
        PDG_CGEA_1_2_V1_0_DWork.Max_Power =
          PDG_CGEA_1_2_V1_0_U.PG_MAX_POWER_VALUE;
        PDG_CGEA_1_2_V1_0_DWork.Front_Power = 0.0F * Wheel_RPM /
          PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT;
        PDG_CGEA_1_2_V1_0_DWork.Rear_Power = (real32_T)fabs
          (PDG_CGEA_1_2_V1_0_B.PrplWhlTot_Tq_Actl_filt) * Wheel_RPM /
          PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT;

        /* Transition: '<S4>:28' */
      } else {
        /* Transition: '<S4>:26' */
      }

      /* Transition: '<S4>:6' */
      if (PDG_CGEA_1_2_V1_0_DWork.Rear_Power > PDG_CGEA_1_2_V1_0_DWork.Max_Power)
      {
        /* Transition: '<S4>:2' */
        /* Transition: '<S4>:23' */
        PDG_CGEA_1_2_V1_0_DWork.Rear_Power = PDG_CGEA_1_2_V1_0_DWork.Max_Power;

        /* Transition: '<S4>:7' */
      } else {
        /* Transition: '<S4>:24' */
      }

      /* Transition: '<S4>:22' */
      if (PDG_CGEA_1_2_V1_0_DWork.Front_Power >
          PDG_CGEA_1_2_V1_0_DWork.Rear_Power *
          PDG_CGEA_1_2_V1_0_U.PG_POWER_MULTIPLIER) {
        /* Transition: '<S4>:13' */
        /* Transition: '<S4>:8' */
        PDG_CGEA_1_2_V1_0_DWork.Front_Power = PDG_CGEA_1_2_V1_0_DWork.Rear_Power
          * PDG_CGEA_1_2_V1_0_U.PG_POWER_MULTIPLIER;

        /* Transition: '<S4>:29' */
      } else {
        /* Transition: '<S4>:5' */
      }

      /* Outport: '<Root>/PG_front_percent_fill' incorporates:
       *  Inport: '<Root>/PG_LINEARITY_FACTOR'
       *  Inport: '<Root>/PG_PERCENT_FILL_CONV_CONSTANT'
       *  Inport: '<Root>/PG_POWER_MULTIPLIER'
       */
      /* Transition: '<S4>:20' */
      PDG_CGEA_1_2_V1_0_Y.PG_front_percent_fill = rt_powf_snf
        (PDG_CGEA_1_2_V1_0_DWork.Front_Power /
         (PDG_CGEA_1_2_V1_0_DWork.Max_Power *
          PDG_CGEA_1_2_V1_0_U.PG_PERCENT_FILL_CONV_CONSTANT),
         PDG_CGEA_1_2_V1_0_U.PG_LINEARITY_FACTOR) * 100.0F;

      /* Outport: '<Root>/PG_rear_percent_fill' incorporates:
       *  Inport: '<Root>/PG_LINEARITY_FACTOR'
       *  Inport: '<Root>/PG_PERCENT_FILL_CONV_CONSTANT'
       */
      PDG_CGEA_1_2_V1_0_Y.PG_rear_percent_fill = rt_powf_snf
        (PDG_CGEA_1_2_V1_0_DWork.Rear_Power / (PDG_CGEA_1_2_V1_0_DWork.Max_Power
          * PDG_CGEA_1_2_V1_0_U.PG_PERCENT_FILL_CONV_CONSTANT),
         PDG_CGEA_1_2_V1_0_U.PG_LINEARITY_FACTOR) * 100.0F;

      /* Transition: '<S4>:10' */
    }
  } else {
    /* Outport: '<Root>/PG_front_percent_fill' */
    /* Transition: '<S4>:34' */
    PDG_CGEA_1_2_V1_0_Y.PG_front_percent_fill = 0.0F;

    /* Outport: '<Root>/PG_rear_percent_fill' */
    PDG_CGEA_1_2_V1_0_Y.PG_rear_percent_fill = 0.0F;

    /* Transition: '<S4>:35' */
  }

  /* End of Chart: '<S1>/PDG' */

  /* Update for UnitDelay: '<S5>/Unit Delay' */
  PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE =
    PDG_CGEA_1_2_V1_0_B.PrplWhlTot_Tq_Actl_filt;

  /* Update for UnitDelay: '<S9>/Unit Delay' */
  PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE_e =
    PDG_CGEA_1_2_V1_0_B.PrplWhlTot_Tq_Actl_filt;

  /* Update for UnitDelay: '<S2>/UD' */
  PDG_CGEA_1_2_V1_0_DWork.UD_DSTATE = PDG_CGEA_1_2_V1_0_B.Sum;
}

/* Model initialize function */
void PDG_CGEA_1_2_V1_0_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatus(PDG_CGEA_1_2_V1_0_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &PDG_CGEA_1_2_V1_0_B), 0,
                sizeof(BlockIO_PDG_CGEA_1_2_V1_0));

  {
    PDG_CGEA_1_2_V1_0_B.Switch = 0.0;
    PDG_CGEA_1_2_V1_0_B.Switch2 = 0.0;
    PDG_CGEA_1_2_V1_0_B.pg_decay_rise_fall_switch = 0.0;
    PDG_CGEA_1_2_V1_0_B.pg_torque_in_for_tc_filter_minu = 0.0;
    PDG_CGEA_1_2_V1_0_B.output = 0.0;
    PDG_CGEA_1_2_V1_0_B.pg_decay_output_unit_delay = 0.0F;
    PDG_CGEA_1_2_V1_0_B.Sum1 = 0.0F;
    PDG_CGEA_1_2_V1_0_B.pre_decay_output_unit_delay = 0.0F;
    PDG_CGEA_1_2_V1_0_B.pg_torque_with_delay_times_tc_i = 0.0F;
    PDG_CGEA_1_2_V1_0_B.PrplWhlTot_Tq_Actl_filt = 0.0F;
    PDG_CGEA_1_2_V1_0_B.Yk1 = 0.0F;
    PDG_CGEA_1_2_V1_0_B.Switch_m = 0.0F;
    PDG_CGEA_1_2_V1_0_B.Yk1Uk = 0.0F;
    PDG_CGEA_1_2_V1_0_B.PoleYk1Uk = 0.0F;
    PDG_CGEA_1_2_V1_0_B.Sum = 0.0F;
  }

  /* states (dwork) */
  PDG_CGEA_1_2_V1_0_DWork.Sum1_DWORK1 = 0.0;
  PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE = 0.0F;
  PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE_e = 0.0F;
  PDG_CGEA_1_2_V1_0_DWork.UD_DSTATE = 0.0F;
  PDG_CGEA_1_2_V1_0_DWork.Front_Power = 0.0F;
  PDG_CGEA_1_2_V1_0_DWork.Max_Power = 0.0F;
  PDG_CGEA_1_2_V1_0_DWork.Rear_Power = 0.0F;

  /* external inputs */
  PDG_CGEA_1_2_V1_0_U.prpwhltot_tq_actl = 0.0;
  PDG_CGEA_1_2_V1_0_U.veh_v_actleng = 0.0F;
  PDG_CGEA_1_2_V1_0_U.awdlck_tq_req = 0.0F;
  PDG_CGEA_1_2_V1_0_U.AwdRng_D_Actl = 0.0F;
  PDG_CGEA_1_2_V1_0_U.AwdRngFalt_D_Stat = 0.0F;
  PDG_CGEA_1_2_V1_0_U.GearLvrPos_D_Actl = 0.0;
  PDG_CGEA_1_2_V1_0_U.PG_LINEARITY_FACTOR = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_MAX_POWER_VALUE = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_WHL_TRQ_FILTER = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_PERCENT_FILL_CONV_CONSTANT = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_POWER_CONV_CONSTANT = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_POWER_MULTIPLIER = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_REAR_AXLE_RATIO = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_WHEEL_RPM_CONV_CONSTANT = 0.0F;
  PDG_CGEA_1_2_V1_0_U.PG_DECAY_RISING = 0.0;
  PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_HI_TORQ = 0.0;
  PDG_CGEA_1_2_V1_0_U.PG_PT_TORQUE_MAX = 0.0;
  PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_LO_TORQ = 0.0;
  PDG_CGEA_1_2_V1_0_U.PG_PRPLWHL_TQ_LOW_LIMIT = 0.0;
  PDG_CGEA_1_2_V1_0_U.PG_DECAY_FALLING_SWITCHPOINT = 0.0;

  /* external outputs */
  PDG_CGEA_1_2_V1_0_Y.PG_front_percent_fill = 0.0F;
  PDG_CGEA_1_2_V1_0_Y.PG_rear_percent_fill = 0.0F;

  /* InitializeConditions for UnitDelay: '<S5>/Unit Delay' */
  PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE =
    PDG_CGEA_1_2_V1_0_P.UnitDelay_InitialCondition;

  /* InitializeConditions for Chart: '<S5>/DynamicSwitch' */
  PDG_CGEA_1_2_V1_0_B.output = 0.0;

  /* InitializeConditions for UnitDelay: '<S9>/Unit Delay' */
  PDG_CGEA_1_2_V1_0_DWork.UnitDelay_DSTATE_e =
    PDG_CGEA_1_2_V1_0_P.UnitDelay_InitialCondition_o;

  /* InitializeConditions for UnitDelay: '<S2>/UD' */
  PDG_CGEA_1_2_V1_0_DWork.UD_DSTATE = PDG_CGEA_1_2_V1_0_P.UD_InitialCondition;

  /* InitializeConditions for Chart: '<S3>/DynamicCompare' */
  PDG_CGEA_1_2_V1_0_B.output_o = FALSE;

  /* InitializeConditions for Chart: '<S1>/PDG' */
  PDG_CGEA_1_2_V1_0_DWork.Front_Power = 0.0F;
  PDG_CGEA_1_2_V1_0_DWork.Max_Power = 0.0F;
  PDG_CGEA_1_2_V1_0_DWork.Rear_Power = 0.0F;
}

/* Model terminate function */
void PDG_CGEA_1_2_V1_0_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
