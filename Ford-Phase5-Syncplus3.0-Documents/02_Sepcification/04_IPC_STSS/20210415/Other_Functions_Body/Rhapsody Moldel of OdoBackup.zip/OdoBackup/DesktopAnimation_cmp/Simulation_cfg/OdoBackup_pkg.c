/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: OdoBackup_pkg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdoBackup_pkg.c
*********************************************************************/

/*## auto_generated */
#include "OdoBackup_pkg.h"
/*## file I_NPs */
#include "I_NPs.h"
/*## classInstance itsOdometerBackup */
#include "OdometerBackup.h"
/*## file Stubs */
#include "Stubs.h"
/*## auto_generated */
#include "I_EEPROM_Manager.h"
/*## auto_generated */
#include "I_OdometerBackup.h"
/*#[ ignore */
#define OdoBackup_pkg_OdoBackup_pkg_doExecute_SERIALIZE ARCSA_addAttribute_c(arcsmethod, "me", ARC_ptr2String(me));

#define evIgnitionStatus_SERIALIZE OMADD_SER(ignitionStatus, ARC_int2String((int)me->ignitionStatus))

#define evIgnitionStatus_UNSERIALIZE OMADD_UNSER(int, ignitionStatus, ARC_destructiveString2X_int)

#define evIgnitionStatus_DECLARE_PARAMS ignition_status_T ignitionStatus;

#define evIgnitionStatus_CONSTRUCTOR RiC_Create_evIgnitionStatus(ignitionStatus)

#define evOdoMasterValue_SERIALIZE OMADD_SER(new_odo_value, ARC_unsigned_int2String(me->new_odo_value))

#define evOdoMasterValue_UNSERIALIZE OMADD_UNSER(unsigned int, new_odo_value, ARC_destructiveString2X_unsigned_int)

#define evOdoMasterValue_DECLARE_PARAMS unsigned int new_odo_value;

#define evOdoMasterValue_CONSTRUCTOR RiC_Create_evOdoMasterValue(new_odo_value)

#define evHardReset_SERIALIZE OM_NO_OP

#define evHardReset_UNSERIALIZE OM_NO_OP

#define evHardReset_DECLARE_PARAMS OM_NO_OP

#define evHardReset_CONSTRUCTOR RiC_Create_evHardReset()
/*#]*/

/*## package OdoBackup_pkg */


/*#[ ignore */
static RiCTimedAction ric_timedAction = {
	((void (*)(RhpAddress const))(OdoBackup_pkg_doExecute)),
	(NULL),
	(0U),
	(100U),
	1,
	(TRUE),
	(((RiCOSTimerHandle)0)),
	NULL
	, &(mxfGlobals.mainTask.ric_task)
};
/*#]*/

/*## classInstance itsOdometerBackup */
/* Violation of MISRA Rule 45 (Required): */
/* 'Type casting to or from pointers shall not be used.' */
/* The following cast is justified and is */
/* for Rhapsody auto-generated code use only. */ 
/*LDRA_INSPECTED 99 S */
struct OdometerBackup_t itsOdometerBackup = 
{    /* itsOdometerBackup */
    {0} /* _I_OdometerBackup */, 
    /* ric_reactive */
    { 	
    	(&itsOdometerBackup),	
    	(&(mxfGlobals.mainTask.ric_task)),
    	NULL,
    	(&OdometerBackup_reactiveVtbl),
    	NULL,
    	RiCDefaultStatus,
    	RiCFALSE, 
    	RiCFALSE, 
    	RiCFALSE 
    },
    (void (* const )(void* const,uint32_T))(setOdometerBackUpNODE_NP) /* odoBackupValue_cb */,
    &itsOdometerBackup /* odoBackupValue_trg */,
    0 /* odoBackupValue */,
    0 /* odoMasterValue */,
    FALSE /* tamper_flg */
};

#ifdef _OMINSTRUMENT
static void serializeGlobalVars(ARCSAttributes * arcsAttributes);

static void serializeGlobalItems(ARCSRelations * arcsRelations);

static void RenameGlobalInstances(void);

/*#[ ignore */
static const ARCSerGVtbl OdoBackup_pkg_instrumentVtbl = {
    &serializeGlobalVars,
    &serializeGlobalItems
};
/*#]*/

OM_INSTRUMENT_PACKAGE(OdoBackup_pkg, OdoBackup_pkg, &OdoBackup_pkg_instrumentVtbl)
#endif /* _OMINSTRUMENT */

void OdoBackup_pkg_OMInitializer_Init(void) {
    OdoBackup_pkg_OMEvent_Init();
    OdoBackup_pkg_initRelations();
    (void) OdoBackup_pkg_startBehavior();
}

void OdoBackup_pkg_OMInitializer_Cleanup(void) {
}

/*#[ ignore */
void OdoBackup_pkg_doExecute(void * const me) {
    NOTIFY_FUNCTION(me, &me, OdoBackup_pkg, OdoBackup_pkg_doExecute, OdoBackup_pkg_doExecute(void * const), 1, OdoBackup_pkg_OdoBackup_pkg_doExecute_SERIALIZE);
    {
        RiCTaskEM_beginMyTask(RiCMainTask());
        RiCTaskEM_doExecute(RiCMainTask());
        
        RiCTaskEM_endMyTask(RiCMainTask());
    }
}

void setOdometerBackUpNODE_NP(void * const me, unsigned int p_OdometerBackUpNODE) {
    Set_OdometerBackUpNODE( p_OdometerBackUpNODE );
}
/*#]*/

void OdoBackup_pkg_initRelations(void) {
    RiCTimedAction_init(&ric_timedAction, (void (*)(void * const))OdoBackup_pkg_doExecute, NULL, 0U, 100U, ((RiCOSTimerHandle)0), TRUE, RiCMainTask(), &mxfGlobals);
    OdometerBackup_Init(&(itsOdometerBackup), RiCMainTask());
    I_NPs_initRelations();
    Stubs_initRelations();
    
    #ifdef _OMINSTRUMENT
    RenameGlobalInstances();
    #endif /* _OMINSTRUMENT*/
}

#ifdef _OMINSTRUMENT
void OdoBackup_pkg_OMEvent_Init(void) {
    ARC_INIT_EVENT(evIgnitionStatus);
    ARC_INIT_EVENT(evOdoMasterValue);
    ARC_INIT_EVENT(evHardReset);
}
#endif /* _OMINSTRUMENT */

RiCBoolean OdoBackup_pkg_startBehavior(void) {
    RiCBoolean done = RiCTRUE;
    done &= OdometerBackup_startBehavior(&(itsOdometerBackup));
    return done;
}

#ifdef _OMINSTRUMENT
static void serializeGlobalVars(ARCSAttributes * arcsAttributes) {
}

static void serializeGlobalItems(ARCSRelations * arcsRelations) {
    ARCSRS_addRelation(arcsRelations, "itsOdometerBackup", TRUE, TRUE);
    ARCSRS_addItem(arcsRelations, OdometerBackup, &(itsOdometerBackup));
}

static void RenameGlobalInstances(void) {
    ARCAI_SetName(&(itsOdometerBackup), OdometerBackup, "itsOdometerBackup", ARCNoMultiplicity);
}
#endif /* _OMINSTRUMENT */

/*#[ ignore */
RiCEvent * evIgnitionStatus(ignition_status_T ignitionStatus)
{
	return RiC_Create_evIgnitionStatus(ignitionStatus);
}

#define evIgnitionStatus_POOL_ZIZE 2U
static evIgnitionStatus_ev *evIgnitionStatus_getMemory(void);
static evIgnitionStatus_ev *evIgnitionStatus_getMemory(void)
{
	/* The initialization is done according to the value of: TIMEOUTS_POOL_SIZE (see definition) */
	static evIgnitionStatus_ev evIgnitionStatusPool[evIgnitionStatus_POOL_ZIZE] = {0};
	evIgnitionStatus_ev* res = NULL;
	RhpPositive ind = 0U;
	RhpBoolean flag = RiCFALSE;

	for(; (ind<evIgnitionStatus_POOL_ZIZE) && (flag == RiCFALSE); ind++){
		if(evIgnitionStatusPool[ind].isAllocated == RiCFALSE){
			evIgnitionStatusPool[ind].isAllocated = RiCTRUE;
			flag = RiCTRUE;
			res = &(evIgnitionStatusPool[ind]);
		}
	}

	/*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
	return res;
}

static void evIgnitionStatus_returnMemory(RiCEvent * const me);
static void evIgnitionStatus_returnMemory(RiCEvent * const me)
{
	evIgnitionStatus_ev * ev = evIgnitionStatus_getData(me);
	if (ev != NULL){
		ev->isAllocated = RiCFALSE;
	}
}

evIgnitionStatus_ev *evIgnitionStatus_getData(const RiCEvent * const me)
{
	evIgnitionStatus_ev * ev = NULL;
	if(me != NULL){
		/* 'Type casting to or from pointers shall not be used.' */
		/* The following cast from void* is justified */
		/* and is for Rhapsody auto-generated code use only. */
		/*LDRA_INSPECTED 95 S */ /*LDRA_INSPECTED 203 S */
		ev = (evIgnitionStatus_ev *)(me->userData);
	}
	/*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
	return ev;
}
/*#]*/

OM_INSTRUMENT_EVENT(evIgnitionStatus, OdoBackup_pkg, OdoBackup_pkg, evIgnitionStatus(ignition_status_T), me)

/*#[ ignore */
static void RiC_Destroy_evIgnitionStatus(RiCEvent* const me);
/*#]*/

/*## auto_generated */
static void evIgnitionStatus_Init(RiCEvent* const me, ignition_status_T p_ignitionStatus);

static void evIgnitionStatus_Init(RiCEvent* const me, ignition_status_T p_ignitionStatus) {
    evIgnitionStatus_ev* ev = evIgnitionStatus_getData(me);
    OM_INSTRUMENT_EVENT_INSTANCE(me, evIgnitionStatus)
    RiCEvent_init(me, evIgnitionStatus_OdoBackup_pkg_id);
    if(ev!=NULL)
        {
            ev->ignitionStatus = p_ignitionStatus;
        }
    me->eventDestroyOp = RiC_Destroy_evIgnitionStatus;
}

/*## auto_generated */
static void evIgnitionStatus_Cleanup(RiCEvent* const me);

static void evIgnitionStatus_Cleanup(RiCEvent* const me) {
    RiCEvent_cleanup(me);
}

/*#[ ignore */
RiCEvent * RiC_Create_evIgnitionStatus(ignition_status_T p_ignitionStatus) {
    RiCEvent* me = NULL;
    RiCEvent_lockEventsPoolMutex();
    /*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
    me = RiCEvent_getMemory(&mxfGlobals);
    if(me != NULL){
    	RiCEvent_setData(me, (void *) evIgnitionStatus_getMemory());
    }
    RiCEvent_freeEventsPoolMutex();
    if(me!=NULL)
        {
            evIgnitionStatus_Init(me, p_ignitionStatus);
        }
    return me;
}

static void RiC_Destroy_evIgnitionStatus(RiCEvent* const me) {
    if(me!=NULL)
        {
            evIgnitionStatus_Cleanup(me);
        }
    evIgnitionStatus_returnMemory(me);
    RiCEvent_returnMemory(me);
}
/*#]*/

/*#[ ignore */
RiCEvent * evOdoMasterValue(uint32_T new_odo_value)
{
	return RiC_Create_evOdoMasterValue(new_odo_value);
}

#define evOdoMasterValue_POOL_ZIZE 2U
static evOdoMasterValue_ev *evOdoMasterValue_getMemory(void);
static evOdoMasterValue_ev *evOdoMasterValue_getMemory(void)
{
	/* The initialization is done according to the value of: TIMEOUTS_POOL_SIZE (see definition) */
	static evOdoMasterValue_ev evOdoMasterValuePool[evOdoMasterValue_POOL_ZIZE] = {0};
	evOdoMasterValue_ev* res = NULL;
	RhpPositive ind = 0U;
	RhpBoolean flag = RiCFALSE;

	for(; (ind<evOdoMasterValue_POOL_ZIZE) && (flag == RiCFALSE); ind++){
		if(evOdoMasterValuePool[ind].isAllocated == RiCFALSE){
			evOdoMasterValuePool[ind].isAllocated = RiCTRUE;
			flag = RiCTRUE;
			res = &(evOdoMasterValuePool[ind]);
		}
	}

	/*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
	return res;
}

static void evOdoMasterValue_returnMemory(RiCEvent * const me);
static void evOdoMasterValue_returnMemory(RiCEvent * const me)
{
	evOdoMasterValue_ev * ev = evOdoMasterValue_getData(me);
	if (ev != NULL){
		ev->isAllocated = RiCFALSE;
	}
}

evOdoMasterValue_ev *evOdoMasterValue_getData(const RiCEvent * const me)
{
	evOdoMasterValue_ev * ev = NULL;
	if(me != NULL){
		/* 'Type casting to or from pointers shall not be used.' */
		/* The following cast from void* is justified */
		/* and is for Rhapsody auto-generated code use only. */
		/*LDRA_INSPECTED 95 S */ /*LDRA_INSPECTED 203 S */
		ev = (evOdoMasterValue_ev *)(me->userData);
	}
	/*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
	return ev;
}
/*#]*/

OM_INSTRUMENT_EVENT(evOdoMasterValue, OdoBackup_pkg, OdoBackup_pkg, evOdoMasterValue(uint32_T), me)

/*#[ ignore */
static void RiC_Destroy_evOdoMasterValue(RiCEvent* const me);
/*#]*/

/*## auto_generated */
static void evOdoMasterValue_Init(RiCEvent* const me, uint32_T p_new_odo_value);

static void evOdoMasterValue_Init(RiCEvent* const me, uint32_T p_new_odo_value) {
    evOdoMasterValue_ev* ev = evOdoMasterValue_getData(me);
    OM_INSTRUMENT_EVENT_INSTANCE(me, evOdoMasterValue)
    RiCEvent_init(me, evOdoMasterValue_OdoBackup_pkg_id);
    if(ev!=NULL)
        {
            ev->new_odo_value = p_new_odo_value;
        }
    me->eventDestroyOp = RiC_Destroy_evOdoMasterValue;
}

/*## auto_generated */
static void evOdoMasterValue_Cleanup(RiCEvent* const me);

static void evOdoMasterValue_Cleanup(RiCEvent* const me) {
    RiCEvent_cleanup(me);
}

/*#[ ignore */
RiCEvent * RiC_Create_evOdoMasterValue(uint32_T p_new_odo_value) {
    RiCEvent* me = NULL;
    RiCEvent_lockEventsPoolMutex();
    /*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
    me = RiCEvent_getMemory(&mxfGlobals);
    if(me != NULL){
    	RiCEvent_setData(me, (void *) evOdoMasterValue_getMemory());
    }
    RiCEvent_freeEventsPoolMutex();
    if(me!=NULL)
        {
            evOdoMasterValue_Init(me, p_new_odo_value);
        }
    return me;
}

static void RiC_Destroy_evOdoMasterValue(RiCEvent* const me) {
    if(me!=NULL)
        {
            evOdoMasterValue_Cleanup(me);
        }
    evOdoMasterValue_returnMemory(me);
    RiCEvent_returnMemory(me);
}
/*#]*/

/*#[ ignore */
RiCEvent * evHardReset(void)
{
	return RiC_Create_evHardReset();
}

/*#]*/

OM_INSTRUMENT_EVENT(evHardReset, OdoBackup_pkg, OdoBackup_pkg, evHardReset(), me)

/*#[ ignore */
static void RiC_Destroy_evHardReset(RiCEvent* const me);
/*#]*/

/*## auto_generated */
static void evHardReset_Init(RiCEvent* const me);

static void evHardReset_Init(RiCEvent* const me) {
    OM_INSTRUMENT_EVENT_INSTANCE(me, evHardReset)
    RiCEvent_init(me, evHardReset_OdoBackup_pkg_id);
    me->eventDestroyOp = RiC_Destroy_evHardReset;
}

/*## auto_generated */
static void evHardReset_Cleanup(RiCEvent* const me);

static void evHardReset_Cleanup(RiCEvent* const me) {
    RiCEvent_cleanup(me);
}

/*#[ ignore */
RiCEvent * RiC_Create_evHardReset(void) {
    RiCEvent* me = NULL;
    RiCEvent_lockEventsPoolMutex();
    /*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
    me = RiCEvent_getMemory(&mxfGlobals);
    RiCEvent_freeEventsPoolMutex();
    if(me!=NULL)
        {
            evHardReset_Init(me);
        }
    return me;
}

static void RiC_Destroy_evHardReset(RiCEvent* const me) {
    if(me!=NULL)
        {
            evHardReset_Cleanup(me);
        }
    RiCEvent_returnMemory(me);
}
/*#]*/

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdoBackup_pkg.c
*********************************************************************/
