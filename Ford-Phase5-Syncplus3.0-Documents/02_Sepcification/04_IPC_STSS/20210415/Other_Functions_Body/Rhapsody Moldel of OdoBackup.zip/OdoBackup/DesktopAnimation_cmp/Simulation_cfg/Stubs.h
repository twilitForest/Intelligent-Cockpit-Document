/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Stubs
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Stubs.h
*********************************************************************/

#ifndef Stubs_H
#define Stubs_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "OdoBackup_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## attribute odoBackup_Node_Value */
#include "Types_pkg.h"
/*#[ ignore */
#define OMAnim_OdoBackup_pkg_Stubs_setRead_counter_uint16_T_ARGS_DECLARATION uint16_T p_read_counter;

#define OMAnim_OdoBackup_pkg_Stubs_setWrite_counter_uint16_T_ARGS_DECLARATION uint16_T p_write_counter;
/*#]*/

/*## package OdoBackup_pkg */

/*## class TopLevel::Stubs */
/*#[ ignore */
struct Stubs_t {
    RiCBoolean dummy;
};
/*#]*/

/*## classInstance Stubs.Stubs */
extern struct Stubs_t Stubs;

#ifdef _OMINSTRUMENT
DECLARE_OPERATION_CLASS(OdoBackup_pkg_Stubs_setRead_counter_uint16_T)

DECLARE_OPERATION_CLASS(OdoBackup_pkg_Stubs_setWrite_counter_uint16_T)
#endif /* _OMINSTRUMENT */

/*## attribute odoBackup_Node_Value */
static uint32_T odoBackup_Node_Value = 0;

/*## attribute read_counter */
static uint16_T read_counter = 0;

/*## attribute write_counter */
static uint16_T write_counter = 0;

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void Stubs_Init(void);

/*## auto_generated */
void Stubs_Cleanup(void);

/***    User explicit entries    ***/


/* Operations */

/*## operation stub_ee_read_request() */
uint32_T stub_ee_read_request(void);

/*## operation stub_ee_write_request(uint32_T) */
void stub_ee_write_request(uint32_T value);

/*## auto_generated */
void setOdoBackup_Node_Value(uint32_T p_odoBackup_Node_Value);

/*## auto_generated */
void setRead_counter(uint16_T p_read_counter);

/*## auto_generated */
void setWrite_counter(uint16_T p_write_counter);

/*## auto_generated */
void Stubs_initRelations(void);

/***    User explicit entries    ***/

/***    User implicit entries    ***/


#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Stubs.h
*********************************************************************/
