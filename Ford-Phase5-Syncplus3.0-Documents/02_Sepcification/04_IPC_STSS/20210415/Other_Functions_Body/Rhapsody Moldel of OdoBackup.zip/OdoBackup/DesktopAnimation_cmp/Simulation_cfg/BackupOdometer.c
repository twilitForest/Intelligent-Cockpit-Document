/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: BackupOdometer
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\BackupOdometer.c
*********************************************************************/

/*## auto_generated */
#include "BackupOdometer.h"
/*## link itsOdometerBackup */
#include "OdometerBackup.h"
/*#[ ignore */
#define Simulation_pkg_BackupOdometer_BackupOdometer_SERIALIZE OM_NO_OP
/*#]*/

/*## package Simulation_pkg */

/*## class BackupOdometer */
/*## auto_generated */
static void initStatechart(BackupOdometer* const me);

#ifdef _OMINSTRUMENT
static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes);

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations);

/*## statechart_method */
static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*## statechart_method */
static void rootState_entDef(void * const void_me);

/*## statechart_method */
static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id);

#ifdef _OMINSTRUMENT
/*## statechart_method */
static void backupOdo_serializeStates(const BackupOdometer* const me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*#[ ignore */
const RiCReactive_Vtbl BackupOdometer_reactiveVtbl = {
    rootState_dispatchEvent,
    rootState_entDef,
    ROOT_STATE_SERIALIZE_STATES(rootState_serializeStates),
    NULL
};

static const ARCSerCVtbl Simulation_pkg_BackupOdometer_instrumentVtbl = {
    serializeAttributes,
    serializeRelations
};
/*#]*/

#ifdef _OMINSTRUMENT
OM_INSTRUMENT_OBJECT_TYPE(BackupOdometer, Simulation_pkg, Simulation_pkg, FALSE, &Simulation_pkg_BackupOdometer_instrumentVtbl)
#endif /* _OMINSTRUMENT */

void BackupOdometer_Init(BackupOdometer* const me, RiCTaskEM * p_task) {
    /* Violation of MISRA Rule 45 (Required): */
    /* 'Type casting to or from pointers shall not be used.' */
    /* The following cast into void* is justified */
    /* and is for Rhapsody auto-generated code use only. */
    /*LDRA_INSPECTED 94 S */
    /*LDRA_INSPECTED 95 S */ /*LDRA_INSPECTED 203 S */
    RiCReactive_init(&(me->ric_reactive), (void*)me, p_task, &BackupOdometer_reactiveVtbl, &mxfGlobals);
    NOTIFY_REACTIVE_CONSTRUCTOR(me, &me, NULL, BackupOdometer, BackupOdometer_Init, BackupOdometer_Init(), 0, Simulation_pkg_BackupOdometer_BackupOdometer_SERIALIZE);
    RiCReactive_setActive(&(me->ric_reactive), RiCFALSE);
    initStatechart(me);
    NOTIFY_END_CONSTRUCTOR(me);
}

void BackupOdometer_Cleanup(BackupOdometer* const me) {
    NOTIFY_DESTRUCTOR(me, &me, BackupOdometer, ~BackupOdometer);
    RiCReactive_cleanup(&(me->ric_reactive));
}

void BackupOdometer_setOdometer_Value_Node(BackupOdometer* const me, uint32_T p_Odometer_Value_Node) {
    me->Odometer_Value_Node = p_Odometer_Value_Node;
    NOTIFY_SET_OPERATION(me, BackupOdometer);
}

RiCBoolean BackupOdometer_startBehavior(BackupOdometer* const me) {
    RiCBoolean done = RiCFALSE;
    done = RiCReactive_startBehavior(&(me->ric_reactive), &mxfGlobals);
    return done;
}

static void initStatechart(BackupOdometer* const me) {
    me->rootState_subState = BackupOdometer_RiCNonState;
    me->rootState_active = BackupOdometer_RiCNonState;
}

#ifdef _OMINSTRUMENT
void BackupOdometer_updateRelations(BackupOdometer* const me) {
    NOTIFY_RELATION_ITEM_ADDED(me, BackupOdometer, OdometerBackup, "itsOdometerBackup", me->itsOdometerBackup, FALSE, TRUE);
}

static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes) {
    
    const BackupOdometer * const me = (const BackupOdometer *)void_me;
    ARCSA_addAttribute_c(arcsAttributes, "Odometer_Value_Node", ARC_unsigned_int2String(me->Odometer_Value_Node));
}

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations) {
    
    const BackupOdometer * const me = (const BackupOdometer *)void_me;
    ARCSRS_addRelation(arcsRelations, "itsOdometerBackup", FALSE, TRUE);
    if(me->itsOdometerBackup)
        {
            ARCSRS_addItem(arcsRelations, OdometerBackup, me->itsOdometerBackup);
        }
}

static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState) {
    
    const BackupOdometer * const me = (const BackupOdometer *)void_me;
    ARCSS_addState_OMH(arcsState, "ROOT");
    if(me->rootState_subState == BackupOdometer_backupOdo)
        {
            backupOdo_serializeStates(me, arcsState);
        }
}
#endif /* _OMINSTRUMENT */

static void rootState_entDef(void * const void_me) {
    
    BackupOdometer * const me = (BackupOdometer *)void_me;
    {
        NOTIFY_STATE_ENTERED(me, BackupOdometer, "ROOT");
        NOTIFY_STATE_ENTERED(me, BackupOdometer, "ROOT.backupOdo");
        me->rootState_subState = BackupOdometer_backupOdo;
        me->rootState_active = BackupOdometer_backupOdo;
        RiCTaskEM_schedTm(me->ric_reactive.myTask, 100, BackupOdometer_Timeout_backupOdo_id, &(me->ric_reactive), "ROOT.backupOdo", &mxfGlobals);
    }
}

static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id) {
    
    BackupOdometer * const me = (BackupOdometer *)void_me;
    RiCTakeEventStatus res = eventNotConsumed;
    if(me->rootState_active == BackupOdometer_backupOdo)
        {
            if(id == Timeout_id)
                {
                    if(RiCTimeout_getTimeoutId(me->ric_reactive.current_event) == BackupOdometer_Timeout_backupOdo_id)
                        {
                            NOTIFY_TRANSITION_STARTED(me, BackupOdometer, "0");
                            RiCTaskEM_unschedTm(me->ric_reactive.myTask, BackupOdometer_Timeout_backupOdo_id, &(me->ric_reactive), &mxfGlobals);
                            NOTIFY_STATE_EXITED(me, BackupOdometer, "ROOT.backupOdo");
                            {
                                /*#[ transition 0 */
                                
                                me->Odometer_Value_Node = I_OdometerBackup_get_Odometer_Node(me->itsOdometerBackup);
                                /*#]*/
                            }
                            NOTIFY_STATE_ENTERED(me, BackupOdometer, "ROOT.backupOdo");
                            me->rootState_subState = BackupOdometer_backupOdo;
                            me->rootState_active = BackupOdometer_backupOdo;
                            RiCTaskEM_schedTm(me->ric_reactive.myTask, 100, BackupOdometer_Timeout_backupOdo_id, &(me->ric_reactive), "ROOT.backupOdo", &mxfGlobals);
                            NOTIFY_TRANSITION_TERMINATED(me, BackupOdometer, "0");
                            res = eventConsumed;
                        }
                }
        }
    return res;
}

#ifdef _OMINSTRUMENT
static void backupOdo_serializeStates(const BackupOdometer* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.backupOdo");
}
#endif /* _OMINSTRUMENT */

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\BackupOdometer.c
*********************************************************************/
