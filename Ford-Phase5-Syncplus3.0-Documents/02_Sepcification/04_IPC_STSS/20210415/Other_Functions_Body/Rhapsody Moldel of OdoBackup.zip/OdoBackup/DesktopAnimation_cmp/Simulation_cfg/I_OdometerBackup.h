/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: I_OdometerBackup
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_OdometerBackup.h
*********************************************************************/

#ifndef I_OdometerBackup_H
#define I_OdometerBackup_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "OdoBackup_pkg.h"
/*## operation get_Odometer_Node() */
#include "Types_pkg.h"
/*#[ ignore */
struct I_OdometerBackup_Vtbl {
    size_t I_OdometerBackup_offset;
    uint32_T (*I_OdometerBackup_get_Odometer_Node)(void * const void_me);
    void (*I_OdometerBackup_set_HardReset)(void * const void_me);
    void (*I_OdometerBackup_set_IgnitionStatus)(void * const void_me,ignition_status_T ignition);
    void (*I_OdometerBackup_set_OdometerMasterValue)(void * const void_me,uint32_T new_odoMasterValue);
};
/*#]*/

/*## package OdoBackup_pkg */

/*## class I_OdometerBackup */
typedef struct I_OdometerBackup_t I_OdometerBackup;
struct I_OdometerBackup_t {
    const struct I_OdometerBackup_Vtbl * I_OdometerBackupVtbl;
};

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void I_OdometerBackup_Init(I_OdometerBackup* const me, const struct I_OdometerBackup_Vtbl * vtbl);

/*## auto_generated */
void I_OdometerBackup_Cleanup(I_OdometerBackup* const me);

/***    User explicit entries    ***/


/* Operations */

/*## operation get_Odometer_Node() */
uint32_T I_OdometerBackup_get_Odometer_Node(void * const void_me);

/*## operation set_HardReset() */
void I_OdometerBackup_set_HardReset(void * const void_me);

/*## operation set_IgnitionStatus(ignition_status_T) */
void I_OdometerBackup_set_IgnitionStatus(void * const void_me, ignition_status_T ignition);

/*## operation set_OdometerMasterValue(uint32_T) */
void I_OdometerBackup_set_OdometerMasterValue(void * const void_me, uint32_T new_odoMasterValue);

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_OdometerBackup.h
*********************************************************************/
