/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Stubs
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Stubs.c
*********************************************************************/

/*## auto_generated */
#include "Stubs.h"
/*#[ ignore */
#define OdoBackup_pkg_Stubs_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_stub_ee_read_request_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_stub_ee_write_request_SERIALIZE ARCSA_addAttribute_c(arcsmethod, "value", ARC_unsigned_int2String(value));

#define OMAnim_OdoBackup_pkg_Stubs_setRead_counter_uint16_T_UNSERIALIZE_ARGS OP_UNSER(ARC_destructiveString2X_unsigned_short,p_read_counter)

#define OMAnim_OdoBackup_pkg_Stubs_setRead_counter_uint16_T_SERIALIZE_RET_VAL

#define OMAnim_OdoBackup_pkg_Stubs_setWrite_counter_uint16_T_UNSERIALIZE_ARGS OP_UNSER(ARC_destructiveString2X_unsigned_short,p_write_counter)

#define OMAnim_OdoBackup_pkg_Stubs_setWrite_counter_uint16_T_SERIALIZE_RET_VAL

#define Stubs_REGISTER_OPER_STMT \
     REGISTER_OPERATION(OdoBackup_pkg_Stubs_setRead_counter_uint16_T, "setRead_counter", FALSE, "setRead_counter(uint16_T)", 1) \
     REGISTER_OPERATION(OdoBackup_pkg_Stubs_setWrite_counter_uint16_T, "setWrite_counter", FALSE, "setWrite_counter(uint16_T)", 1)
/*#]*/

/*## package OdoBackup_pkg */

/*## class TopLevel::Stubs */
/*## classInstance Stubs.Stubs */
struct Stubs_t Stubs;

#ifdef _OMINSTRUMENT
static void Stubs_serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes);

/*#[ ignore */
static const ARCSerCVtbl Stubs_instrumentVtbl = {
    Stubs_serializeAttributes,
    NULL
};
/*#]*/

OM_INSTRUMENT_FILE_OBJECT(Stubs, Stubs, OdoBackup_pkg, OdoBackup_pkg, FALSE, &Stubs_instrumentVtbl)

IMPLEMENT_OPERATION_CLASS(OdoBackup_pkg_Stubs_setRead_counter_uint16_T, struct Stubs_t, setRead_counter(me->p_read_counter), NO_OP())

IMPLEMENT_OPERATION_CLASS(OdoBackup_pkg_Stubs_setWrite_counter_uint16_T, struct Stubs_t, setWrite_counter(me->p_write_counter), NO_OP())

IMPLEMENT_REGISTER_OPERATION_CLASSES(Stubs)
#endif /* _OMINSTRUMENT */

void Stubs_Init(void) {
    NOTIFY_CONSTRUCTOR_WITH_OPER_INVOKE(&Stubs, NULL, NULL, Stubs, Stubs_Init, Stubs_Init(), 0, OdoBackup_pkg_Stubs_SERIALIZE);
    NOTIFY_END_CONSTRUCTOR(&Stubs);
}

void Stubs_Cleanup(void) {
    NOTIFY_DESTRUCTOR(&Stubs, NULL, Stubs, ~Stubs);
}

/*## operation stub_ee_read_request() */
uint32_T stub_ee_read_request(void) {
    NOTIFY_OPERATION(&Stubs, NULL, NULL, Stubs, stub_ee_read_request, stub_ee_read_request(), 0, OdoBackup_pkg_stub_ee_read_request_SERIALIZE);
    {
        /*#[ operation stub_ee_read_request() */
        read_counter++; 
        return(odoBackup_Node_Value);
        /*#]*/
    }
}

/*## operation stub_ee_write_request(uint32_T) */
void stub_ee_write_request(uint32_T value) {
    NOTIFY_OPERATION(&Stubs, &value, &value, Stubs, stub_ee_write_request, stub_ee_write_request(), 1, OdoBackup_pkg_stub_ee_write_request_SERIALIZE);
    {
        /*#[ operation stub_ee_write_request(uint32_T) */
        if (value != odoBackup_Node_Value)
        {          
        	/* only write when value is different */
        	write_counter++;
        	odoBackup_Node_Value = value;
        }
        /*#]*/
    }
}

void setOdoBackup_Node_Value(uint32_T p_odoBackup_Node_Value) {
    odoBackup_Node_Value = p_odoBackup_Node_Value;
    NOTIFY_SET_OPERATION(&Stubs, Stubs);
}

void setRead_counter(uint16_T p_read_counter) {
    read_counter = p_read_counter;
    NOTIFY_SET_OPERATION(&Stubs, Stubs);
}

void setWrite_counter(uint16_T p_write_counter) {
    write_counter = p_write_counter;
    NOTIFY_SET_OPERATION(&Stubs, Stubs);
}

void Stubs_initRelations(void) {
    Stubs_Init();
    
    #ifdef _OMINSTRUMENT
    ARCAI_SetName(&(Stubs), Stubs, "Stubs", ARCNoMultiplicity);
    #endif /* _OMINSTRUMENT*/
}

#ifdef _OMINSTRUMENT
static void Stubs_serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes) {
    ARCSA_addAttribute_c(arcsAttributes, "odoBackup_Node_Value", ARC_unsigned_int2String(odoBackup_Node_Value));
    ARCSA_addAttribute_c(arcsAttributes, "read_counter", ARC_unsigned_short2String(read_counter));
    ARCSA_addAttribute_c(arcsAttributes, "write_counter", ARC_unsigned_short2String(write_counter));
}
#endif /* _OMINSTRUMENT */

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Stubs.c
*********************************************************************/
