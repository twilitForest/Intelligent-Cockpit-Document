/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: I_NPs
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_NPs.h
*********************************************************************/

#ifndef I_NPs_H
#define I_NPs_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "OdoBackup_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## operation Set_OdometerBackUpNODE(uint32_T) */
#include "Types_pkg.h"
/*## package OdoBackup_pkg */

/*## class TopLevel::I_NPs */
/*#[ ignore */
struct I_NPs_t {
    RiCBoolean dummy;
};
/*#]*/

/*## classInstance I_NPs.I_NPs */
extern struct I_NPs_t I_NPs;

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void I_NPs_Init(void);

/*## auto_generated */
void I_NPs_Cleanup(void);

/***    User explicit entries    ***/


/* Operations */

/*## operation Set_OdometerBackUpNODE(uint32_T) */
void Set_OdometerBackUpNODE(uint32_T odoBackupValue);

/*## auto_generated */
void I_NPs_initRelations(void);

/***    User implicit entries    ***/


#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_NPs.h
*********************************************************************/
