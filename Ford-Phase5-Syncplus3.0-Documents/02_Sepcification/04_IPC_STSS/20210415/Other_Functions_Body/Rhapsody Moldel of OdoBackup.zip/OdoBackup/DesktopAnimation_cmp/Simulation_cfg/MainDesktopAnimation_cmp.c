/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Simulation_cfg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MainDesktopAnimation_cmp.c
*********************************************************************/

/*## auto_generated */
#include "MainDesktopAnimation_cmp.h"
/*## auto_generated */
#include "OdoBackup_pkg.h"
/*## auto_generated */
#include "Simulation_pkg.h"
/*## auto_generated */
#include "Types_pkg.h"
void DesktopAnimation_cmp_Init(void) {
    OdoBackup_pkg_initRelations();
    Simulation_pkg_initRelations();
    OdoBackup_pkg_OMEvent_Init();
    (void) OdoBackup_pkg_startBehavior();
    Simulation_pkg_OMEvent_Init();
    (void) Simulation_pkg_startBehavior();
}

void DesktopAnimation_cmp_Cleanup(void) {
    OdoBackup_pkg_OMInitializer_Cleanup();
    Simulation_pkg_OMInitializer_Cleanup();
}

RhpInteger main(RhpInteger argc, RhpCharacter* argv[]) {
    RhpInteger status = 0;
    if(RiCOXFInit(argc, argv, 6423, "", 0, 0, RiCTRUE, &mxfGlobals))
        {
            DesktopAnimation_cmp_Init();
            /*#[ configuration DesktopAnimation_cmp::Simulation_cfg */
            /*#]*/
            RiCOXFStart(FALSE);
            DesktopAnimation_cmp_Cleanup();
            status = 0;
        }
    else
        {
            status = 1;
        }
    return status;
}

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MainDesktopAnimation_cmp.c
*********************************************************************/
