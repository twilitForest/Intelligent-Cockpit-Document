/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: IgnitionStatus
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\IgnitionStatus.h
*********************************************************************/

#ifndef IgnitionStatus_H
#define IgnitionStatus_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "Simulation_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## auto_generated */
#include "mxf\RiCReactive.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*## attribute ignitionState */
#include "Types_pkg.h"
/*#[ ignore */
#define IgnitionStatus_Timeout_checkIgnitionStatus_id 1

#define OMAnim_Simulation_pkg_IgnitionStatus_setIgnitionState_ignition_status_T_ARGS_DECLARATION ignition_status_T p_ignitionState;
/*#]*/

/*## link itsOdometerBackup */
struct OdometerBackup_t;

/*## package Simulation_pkg */

/*## class IgnitionStatus */
typedef struct IgnitionStatus_t IgnitionStatus;
struct IgnitionStatus_t {
    RiCReactive ric_reactive;
    struct OdometerBackup_t* const itsOdometerBackup;		/*## link itsOdometerBackup */
    ignition_status_T ignitionState;		/*## attribute ignitionState */
    /*#[ ignore */
    RhpInteger rootState_subState;
    RhpInteger rootState_active;
    /*#]*/
};

/*#[ ignore */
extern const RiCReactive_Vtbl IgnitionStatus_reactiveVtbl;
/*#]*/

#ifdef _OMINSTRUMENT
DECLARE_OPERATION_CLASS(Simulation_pkg_IgnitionStatus_setIgnitionState_ignition_status_T)
#endif /* _OMINSTRUMENT */

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void IgnitionStatus_Init(IgnitionStatus* const me, RiCTaskEM * p_task);

/*## auto_generated */
void IgnitionStatus_Cleanup(IgnitionStatus* const me);

/*## auto_generated */
ignition_status_T IgnitionStatus_getIgnitionState(const IgnitionStatus* const me);

/*## auto_generated */
void IgnitionStatus_setIgnitionState(IgnitionStatus* const me, ignition_status_T p_ignitionState);

/*## auto_generated */
RiCBoolean IgnitionStatus_startBehavior(IgnitionStatus* const me);

/***    Framework entries    ***/

#ifdef _OMINSTRUMENT
void IgnitionStatus_updateRelations(IgnitionStatus* const me);
#endif /* _OMINSTRUMENT */

/* rootState: */
/*## statechart_method */
#define IgnitionStatus_rootState_IN(me)    \
    (1)

/* checkIgnitionStatus: */
/*## statechart_method */
#define IgnitionStatus_checkIgnitionStatus_IN(me)    \
    ((me)->rootState_subState == IgnitionStatus_checkIgnitionStatus)

/***    Framework entries    ***/

/*#[ ignore */
enum IgnitionStatus_Enum {
    IgnitionStatus_RiCNonState = 0,
    IgnitionStatus_checkIgnitionStatus = 1
};
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\IgnitionStatus.h
*********************************************************************/
