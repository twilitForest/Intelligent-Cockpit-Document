#ifndef MXF_CFG_H
#define MXF_CFG_H

/***************************************************************
 ---------------------------------------------------------------
|							  mxf_cfg.h		        |
 --------------------------------------------------------------- 
****************************************************************/

/****************************************************************/
/*                   How to use this Template                   */
/****************************************************************/
/*  Substitution is done for properties in:                      */
/*  1. C_CG:Configuration                                       */
/*  2. C_CG:<Environment>                                       */
/*  Use $<prop-Name>, Example:                                  */
/*                                                              */
/*  #define MY_FLAG $<MyProp>                                   */
/*                                                              */
/*  If the value of 'MyProp' is '100' then the result would be: */
/*  #define MY_FLAG 100                                         */
/****************************************************************/

#ifndef RHPSTRING_TYPEDEF_IN_MXF_CFG
#define RHPSTRING_TYPEDEF_IN_MXF_CFG
#endif

#include "mxf/RiCTypes.h"
//#ifdef _LAPTOP
#include "C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\crt\src\ctype.h"       
//#endif
//#ifndef _LAPTOP
//#include "C:\Program Files\Microsoft Visual Studio 9.0\VC\crt\src\ctype.h"
//#endif

#if (defined(_OMINSTRUMENT) || defined(OMANIMATOR))
#ifndef MICROC_OXF
#define MICROC_OXF
#endif
#ifndef MICROC_OXF_CLEANUP
#define MICROC_OXF_CLEANUP
#endif
#ifndef USE_DELAYS
#define USE_DELAYS
#endif
#ifndef OXF_USE_DYNAMIC_ALLOC
#define OXF_USE_DYNAMIC_ALLOC
#endif
#endif

#ifndef MICROC_OXF_CLEANUP_False
#define MICROC_OXF_CLEANUP_False
#endif

#ifdef MICROC_OXF_CLEANUP_True
#ifndef MICROC_OXF_CLEANUP
#define MICROC_OXF_CLEANUP
#endif
#endif

#define INSTRUMENTATION_TYPE_ANIMATE

#ifndef RiC_DEFAULT_START_SIZE
#define RiC_DEFAULT_START_SIZE 10U
#endif

#ifndef TIMEOUTS_POOL_SIZE
#define TIMEOUTS_POOL_SIZE 10U
#endif

#ifndef HEAP_CONST_SIZE
#define HEAP_CONST_SIZE 10U
#endif

/** collection definitions **/
#ifndef RiC_COLLECTION_STATIC_SIZE
#define RiC_COLLECTION_STATIC_SIZE 20U
#endif

/** Timer Manager definitions **/
#define RICTIMERMANAGER_TIME_CYCLE        1U
#define RICTIMERMANAGER_DEFAULT_TICK_TIME 16UL
#define RICTIMERMANAGER_OVERFLOW_MARK     0x80000000UL

/** Statechart Execution definitions **/
#ifndef OMDEFAULT_MAX_NULL_STEPS
#define OMDEFAULT_MAX_NULL_STEPS 100
#endif

#ifndef EVENTS_POOL_SIZE
#define EVENTS_POOL_SIZE 10U
#endif

#define CAN_USE_ASSERT_True  1
#define CAN_USE_ASSERT_False 0

#define CAN_USE_ASSERT CAN_USE_ASSERT_False
#if (CAN_USE_ASSERT == CAN_USE_ASSERT_True)
#include <assert.h>
#define RiC_ASSERT assert
#define USE_ASSERT 
#endif

/** General definitions **/
#define RunTime     1
#define CompileTime 2
#define ByCategory  3

#define HasNoReactives	1
#define HasReactives	2

#define GEN_INITIALIZATION_MODE CompileTime
#define OXF_INITIALIZATION_MODE CompileTime

#if GEN_INITIALIZATION_MODE == CompileTime
#ifndef OXF_STATIC_INIT
#define OXF_STATIC_INIT
#endif
#endif

#if GEN_INITIALIZATION_MODE == ByCategory
#if OXF_INITIALIZATION_MODE == CompileTime
#ifndef OXF_STATIC_INIT
#define OXF_STATIC_INIT
#endif
#endif 
#endif 

#ifdef OXF_STATIC_INIT
#define OXF_CONST const
#else
#define OXF_CONST
#endif

#define RIC_THE_MAIN_TASK mxfGlobals.mainTask

#define MainTaskHasReactives HasReactives
#if MainTaskHasReactives == HasReactives
#define RIC_MAIN_TASK_HAS_REACTIVES
#endif

#ifndef USE_OVERRIDE_CONSUME_EVENT_
#define USE_OVERRIDE_CONSUME_EVENT_
#endif

#ifdef USE_OVERRIDE_CONSUME_EVENT_True
#ifndef RIC_OVERRIDE_CONSUME_EVENT
#define RIC_OVERRIDE_CONSUME_EVENT
#endif
#endif

#ifndef RIC_NO_RAPID_PORTS
#define RIC_NO_RAPID_PORTS
#endif

#ifndef RiCExcludeRiCMap
#define RiCExcludeRiCMap
#endif

#ifdef RiCIncludeRiCMap
#ifndef RIC_USE_RICMAP
#define RIC_USE_RICMAP
#endif 
#endif

#ifndef RiCExcludeRiCStack
#define RiCExcludeRiCStack
#endif

#ifdef RiCIncludeRiCStack
#ifndef RIC_USE_RICSTACK
#define RIC_USE_RICSTACK
#endif 
#endif

#ifndef RiCExcludeRiCList
#define RiCExcludeRiCList
#endif

#ifdef RiCIncludeRiCList
#ifndef RIC_USE_RICLIST
#define RIC_USE_RICLIST
#endif 
#endif

#ifndef RiCExcludeRiCCollection
#define RiCExcludeRiCCollection
#endif

#ifdef RiCIncludeRiCCollection
#ifndef RIC_USE_RICCOLLECTION
#define RIC_USE_RICCOLLECTION
#endif 
#endif

#ifndef RiCExcludeRiCQueue
#define RiCExcludeRiCQueue
#endif

#ifdef RiCIncludeRiCQueue
#ifndef RIC_USE_RICQUEUE
#define RIC_USE_RICQUEUE
#endif 
#endif

#ifndef RiCExcludeRiCHeap
#define RiCExcludeRiCHeap
#endif

#ifdef RiCIncludeRiCHeap
#ifndef RIC_USE_RICHEAP
#define RIC_USE_RICHEAP
#endif 
#endif

#ifndef RiCExcludeRiCOutput
#define RiCExcludeRiCOutput
#endif

#ifdef RiCIncludeRiCOutput
#ifndef RIC_USE_RICOUTPUT
#define RIC_USE_RICOUTPUT
#endif 
#endif

#ifndef RiCExcludeRiCMemoryManager
#define RiCExcludeRiCMemoryManager
#endif

#ifdef RiCIncludeRiCMemoryManager
#ifndef RIC_USE_MEMORY_MANAGER
#define RIC_USE_MEMORY_MANAGER
#endif 
#endif

#ifdef RIC_USE_MEMORY_MANAGER
#ifndef RIC_TINY_POOL_BLOCKS
#define RIC_TINY_POOL_BLOCKS 16U
#endif
#ifndef RIC_SMALL_POOL_BLOCKS
#define RIC_SMALL_POOL_BLOCKS 0U
#endif
#ifndef RIC_MEDIUM_POOL_BLOCKS
#define RIC_MEDIUM_POOL_BLOCKS 0U
#endif
#ifndef RIC_LARGE_POOL_BLOCKS
#define RIC_LARGE_POOL_BLOCKS 0U
#endif
#ifndef RIC_HUGE_POOL_BLOCKS
#define RIC_HUGE_POOL_BLOCKS 0U
#endif
#endif

#ifndef RiCExcludeRiCString
#define RiCExcludeRiCString
#endif

#ifdef RiCIncludeRiCString
#ifndef RIC_USE_RICSTRING
#define RIC_USE_RICSTRING
#endif 
#endif

#ifndef RiCExcludeMemAlloc
#define RiCExcludeMemAlloc
#endif

#ifdef RiCIncludeMemAlloc
#ifndef RIC_USE_MEMALLOC
#define RIC_USE_MEMALLOC
#endif 
#endif

#ifndef RiCIncludeRiCReactiveStateMacros
#define RiCIncludeRiCReactiveStateMacros
#endif

#ifdef RiCIncludeRiCReactiveStateMacros
#ifndef RIC_USE_RICREACTIVE_STATE_MACROS
#define RIC_USE_RICREACTIVE_STATE_MACROS
#endif 
#endif

#ifndef RiCIncludeRiCReactiveGenMacros
#define RiCIncludeRiCReactiveGenMacros
#endif

#ifdef RiCIncludeRiCReactiveGenMacros
#ifndef RIC_USE_RICREACTIVE_GEN_MACROS
#define RIC_USE_RICREACTIVE_GEN_MACROS
#endif 
#endif

#ifndef RIC_USE_OS_CONTEXT_
#define RIC_USE_OS_CONTEXT_
#endif

#ifdef RIC_USE_OS_CONTEXT_True
#ifndef RIC_USE_OS_CONTEXT
#define RIC_USE_OS_CONTEXT
#endif 
typedef  RiCOSContextType;
#endif

#ifndef RIC_TIMEOUT_AS_TRIGGERED_OP_False
#define RIC_TIMEOUT_AS_TRIGGERED_OP_False
#endif

#ifdef RIC_TIMEOUT_AS_TRIGGERED_OP_True
#ifndef RIC_TIMEOUT_AS_TRIGGERED_OP
#define RIC_TIMEOUT_AS_TRIGGERED_OP
#endif 
#endif

#ifndef _OM_TARGET_MONITORING_Off
#define _OM_TARGET_MONITORING_Off
#endif

#ifdef _OM_TARGET_MONITORING_On

#ifndef _OMINSTRUMENT
#define _OMINSTRUMENT
#endif

#ifndef _OM_TARGET_MON
#define _OM_TARGET_MON
#endif

#ifndef _OM_TARGET_MON_WINDOWS_TCP
#define _OM_TARGET_MON_WINDOWS_TCP
#endif

#else

#ifdef _OMINSTRUMENT

/** Instrumentation - uses Global Task Info, Stack, Map **/

#ifndef RIC_USE_GLOBAL_TASK_LIST
#define RIC_USE_GLOBAL_TASK_LIST
#endif

#ifndef RIC_USE_RICMAP
#define RIC_USE_RICMAP
#endif

#ifndef RIC_USE_RICSTACK
#define RIC_USE_RICSTACK
#endif

#ifndef RIC_USE_RICQUEUE
#define RIC_USE_RICQUEUE
#endif

#ifndef RIC_USE_RICSTRING
#define RIC_USE_RICSTRING
#endif

#ifndef RIC_USE_MXF_GLOBALS
#define RIC_USE_MXF_GLOBALS
#endif

#endif

#endif

#ifdef RIC_USE_GLOBAL_TASK_LIST

/** Global Task Info - needs List **/

#ifndef RIC_USE_RICLIST
#define RIC_USE_RICLIST
#endif

#endif

#ifdef RIC_USE_RICSTACK

/**  Stack - needs List **/

#ifndef RIC_USE_RICLIST
#define RIC_USE_RICLIST
#endif

#endif




#ifdef RHPSTRING_TYPEDEF_IN_MXF_CFG
typedef signed char* RhpString;
#endif

#ifdef USE_OPTIMIZED_STATECHART_MACROS
#ifndef RIC_CONCAT
#define RIC_CONCAT(A, B) A ##B
#endif
#define inState(cS, X)                 (((cS) & RIC_CONCAT(FM_,X)) == RIC_CONCAT(FS_,X))
#define inLeafState(cS, X, stInfoType) ((cS) == (stInfoType)RIC_CONCAT(FS_,X))
#define isInState(sI, X)               (((sI) & RIC_CONCAT(FM_,X)) == RIC_CONCAT(FS_,X))
#define isNotInState(sI, X)            (((sI) & RIC_CONCAT(FM_,X)) != RIC_CONCAT(FS_,X))
#define isNotStayingInState(sS, X)     isNotInState((sS), X)
#define willBeInState(eOrEBits, X)     isInState((eOrEBits), X)
#define willBeInSibState(eOrEBits, X)  ((eOrEBits) & RIC_CONCAT(FM2_,X))
#define wasInState(eOrEBits, X)        isInState((eOrEBits), X)
#define wasInSibState(eOrEBits, X)     ((eOrEBits) & RIC_CONCAT(FM2_,X))
#define RESET_DEEP_HISTORY(X)		   RIC_CONCAT(RESET_DEEP_HISTORY_,X)
#endif

#endif
