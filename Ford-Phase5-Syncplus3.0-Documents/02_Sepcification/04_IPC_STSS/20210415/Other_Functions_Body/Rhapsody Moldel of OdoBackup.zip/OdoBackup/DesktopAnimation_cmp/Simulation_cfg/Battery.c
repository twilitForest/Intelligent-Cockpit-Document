/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Battery
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Battery.c
*********************************************************************/

/*## auto_generated */
#include "Battery.h"
/*## link itsOdometerBackup */
#include "OdometerBackup.h"
/*#[ ignore */
#define Simulation_pkg_Battery_Battery_SERIALIZE OM_NO_OP

#define Simulation_pkg_Battery_checkBattery_SERIALIZE OM_NO_OP

#define Simulation_pkg_Battery_set_HardReset_SERIALIZE OM_NO_OP
/*#]*/

/*## package Simulation_pkg */

/*## class Battery */
/*## operation checkBattery() */
static void checkBattery(Battery* const me);

/*## auto_generated */
static void initStatechart(Battery* const me);

#ifdef _OMINSTRUMENT
static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes);

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations);

/*## statechart_method */
static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*## statechart_method */
static void rootState_entDef(void * const void_me);

/*## statechart_method */
static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id);

#ifdef _OMINSTRUMENT
/*## statechart_method */
static void batt_serializeStates(const Battery* const me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*#[ ignore */
const RiCReactive_Vtbl Battery_reactiveVtbl = {
    rootState_dispatchEvent,
    rootState_entDef,
    ROOT_STATE_SERIALIZE_STATES(rootState_serializeStates),
    NULL
};

static const ARCSerCVtbl Simulation_pkg_Battery_instrumentVtbl = {
    serializeAttributes,
    serializeRelations
};
/*#]*/

#ifdef _OMINSTRUMENT
OM_INSTRUMENT_OBJECT_TYPE(Battery, Simulation_pkg, Simulation_pkg, FALSE, &Simulation_pkg_Battery_instrumentVtbl)
#endif /* _OMINSTRUMENT */

void Battery_Init(Battery* const me, RiCTaskEM * p_task) {
    /* Violation of MISRA Rule 45 (Required): */
    /* 'Type casting to or from pointers shall not be used.' */
    /* The following cast into void* is justified */
    /* and is for Rhapsody auto-generated code use only. */
    /*LDRA_INSPECTED 94 S */
    /*LDRA_INSPECTED 95 S */ /*LDRA_INSPECTED 203 S */
    RiCReactive_init(&(me->ric_reactive), (void*)me, p_task, &Battery_reactiveVtbl, &mxfGlobals);
    NOTIFY_REACTIVE_CONSTRUCTOR(me, &me, NULL, Battery, Battery_Init, Battery_Init(), 0, Simulation_pkg_Battery_Battery_SERIALIZE);
    RiCReactive_setActive(&(me->ric_reactive), RiCFALSE);
    initStatechart(me);
    NOTIFY_END_CONSTRUCTOR(me);
}

void Battery_Cleanup(Battery* const me) {
    NOTIFY_DESTRUCTOR(me, &me, Battery, ~Battery);
    RiCReactive_cleanup(&(me->ric_reactive));
}

/*## operation set_HardReset() */
void Battery_set_HardReset(Battery* const me) {
    NOTIFY_OPERATION(me, &me, NULL, Battery, Battery_set_HardReset, Battery_set_HardReset(), 0, Simulation_pkg_Battery_set_HardReset_SERIALIZE);
    {
        /*#[ operation set_HardReset() */
        me->hardreset = TRUE;
        /*#]*/
    }
}

/*## operation checkBattery() */
static void checkBattery(Battery* const me) {
    NOTIFY_OPERATION(me, &me, NULL, Battery, checkBattery, checkBattery(), 0, Simulation_pkg_Battery_checkBattery_SERIALIZE);
    {
        /*#[ operation checkBattery() */
        if ( me->hardreset == TRUE )
        {
        	I_OdometerBackup_set_HardReset(me->itsOdometerBackup);
        	me->hardreset = FALSE;
        }
        /*#]*/
    }
}

RiCBoolean Battery_startBehavior(Battery* const me) {
    RiCBoolean done = RiCFALSE;
    done = RiCReactive_startBehavior(&(me->ric_reactive), &mxfGlobals);
    return done;
}

static void initStatechart(Battery* const me) {
    me->rootState_subState = Battery_RiCNonState;
    me->rootState_active = Battery_RiCNonState;
}

#ifdef _OMINSTRUMENT
void Battery_updateRelations(Battery* const me) {
    NOTIFY_RELATION_ITEM_ADDED(me, Battery, OdometerBackup, "itsOdometerBackup", me->itsOdometerBackup, FALSE, TRUE);
}

static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes) {
    
    const Battery * const me = (const Battery *)void_me;
    ARCSA_addAttribute_c(arcsAttributes, "hardreset", ARC_RiCBoolean2String(me->hardreset));
}

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations) {
    
    const Battery * const me = (const Battery *)void_me;
    ARCSRS_addRelation(arcsRelations, "itsOdometerBackup", FALSE, TRUE);
    if(me->itsOdometerBackup)
        {
            ARCSRS_addItem(arcsRelations, OdometerBackup, me->itsOdometerBackup);
        }
}

static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState) {
    
    const Battery * const me = (const Battery *)void_me;
    ARCSS_addState_OMH(arcsState, "ROOT");
    if(me->rootState_subState == Battery_batt)
        {
            batt_serializeStates(me, arcsState);
        }
}
#endif /* _OMINSTRUMENT */

static void rootState_entDef(void * const void_me) {
    
    Battery * const me = (Battery *)void_me;
    {
        NOTIFY_STATE_ENTERED(me, Battery, "ROOT");
        NOTIFY_STATE_ENTERED(me, Battery, "ROOT.batt");
        me->rootState_subState = Battery_batt;
        me->rootState_active = Battery_batt;
        RiCTaskEM_schedTm(me->ric_reactive.myTask, 10, Battery_Timeout_batt_id, &(me->ric_reactive), "ROOT.batt", &mxfGlobals);
    }
}

static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id) {
    
    Battery * const me = (Battery *)void_me;
    RiCTakeEventStatus res = eventNotConsumed;
    if(me->rootState_active == Battery_batt)
        {
            if(id == Timeout_id)
                {
                    if(RiCTimeout_getTimeoutId(me->ric_reactive.current_event) == Battery_Timeout_batt_id)
                        {
                            NOTIFY_TRANSITION_STARTED(me, Battery, "0");
                            RiCTaskEM_unschedTm(me->ric_reactive.myTask, Battery_Timeout_batt_id, &(me->ric_reactive), &mxfGlobals);
                            NOTIFY_STATE_EXITED(me, Battery, "ROOT.batt");
                            {
                                /*#[ transition 0 */
                                checkBattery(me);
                                /*#]*/
                            }
                            NOTIFY_STATE_ENTERED(me, Battery, "ROOT.batt");
                            me->rootState_subState = Battery_batt;
                            me->rootState_active = Battery_batt;
                            RiCTaskEM_schedTm(me->ric_reactive.myTask, 10, Battery_Timeout_batt_id, &(me->ric_reactive), "ROOT.batt", &mxfGlobals);
                            NOTIFY_TRANSITION_TERMINATED(me, Battery, "0");
                            res = eventConsumed;
                        }
                }
        }
    return res;
}

#ifdef _OMINSTRUMENT
static void batt_serializeStates(const Battery* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.batt");
}
#endif /* _OMINSTRUMENT */

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Battery.c
*********************************************************************/
