/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: OdometerBackup
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdometerBackup.h
*********************************************************************/

#ifndef OdometerBackup_H
#define OdometerBackup_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "OdoBackup_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## auto_generated */
#include "mxf\RiCReactive.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*## class OdometerBackup */
#include "I_OdometerBackup.h"
/*## operation gen(RiCEvent*,RiCBoolean) */
#include "mxf\RiCTypes.h"
/*## operation get_Odometer_Node() */
#include "Types_pkg.h"
/*## link itsI_EEPROM_Manager */
struct I_EEPROM_Manager_t;

/*## package OdoBackup_pkg */

/*## class OdometerBackup */
typedef struct OdometerBackup_t OdometerBackup;
struct OdometerBackup_t {
    /*#[ ignore */
    struct I_OdometerBackup_t _I_OdometerBackup;
    /*#]*/
    RiCReactive ric_reactive;
    /*#[ ignore */
    void (* const odoBackupValue_cb)(void* const,uint32_T);
    void* const odoBackupValue_trg;
    /*#]*/
    uint32_T odoBackupValue;		/*## attribute odoBackupValue */
    /* Master odometer value. */
    uint32_T odoMasterValue;		/*## attribute odoMasterValue */
    RiCBoolean tamper_flg;		/*## attribute tamper_flg */
    struct I_EEPROM_Manager_t* const itsI_EEPROM_Manager;		/*## link itsI_EEPROM_Manager */
    /*#[ ignore */
    RhpInteger rootState_subState;
    RhpInteger rootState_active;
    RhpInteger ignition_status_subState;
    RhpInteger backup_enabled_subState;
    /*#]*/
};

/*#[ ignore */
extern const RiCReactive_Vtbl OdometerBackup_reactiveVtbl;
/*#]*/

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void OdometerBackup_Init(OdometerBackup* const me, RiCTaskEM * p_task);

/*## auto_generated */
void OdometerBackup_Cleanup(OdometerBackup* const me);

/***    User explicit entries    ***/


/* Operations */

/*## operation Operation_21() */
void OdometerBackup_Operation_21(OdometerBackup* const me);

/*## operation gen(RiCEvent*,RiCBoolean) */
RiCBoolean OdometerBackup_gen(OdometerBackup* const me, RiCEvent* event, RiCBoolean fromISR);

/*## operation get_Odometer_Node() */
uint32_T OdometerBackup_get_Odometer_Node(OdometerBackup* const me);

/*#[ ignore */
void OdometerBackup_setOdoBackupValue(OdometerBackup* const me, unsigned int p_odoBackupValue);
/*#]*/

/*## operation set_HardReset() */
void OdometerBackup_set_HardReset(OdometerBackup* const me);

/*## operation set_IgnitionStatus(ignition_status_T) */
void OdometerBackup_set_IgnitionStatus(OdometerBackup* const me, ignition_status_T ignition);

/*## operation set_OdometerMasterValue(uint32_T) */
void OdometerBackup_set_OdometerMasterValue(OdometerBackup* const me, uint32_T new_odoMasterValue);

/*## auto_generated */
void setOdoMasterValue(OdometerBackup* const me, uint32_T p_odoMasterValue);

/*## auto_generated */
void setTamper_flg(OdometerBackup* const me, RiCBoolean p_tamper_flg);

/*## auto_generated */
RiCBoolean OdometerBackup_startBehavior(OdometerBackup* const me);

/***    Framework entries    ***/

/* rootState: */
/*## statechart_method */
#define OdometerBackup_rootState_IN(me)    \
    (1)

/* initialization: */
/*## statechart_method */
#define OdometerBackup_initialization_IN(me)    \
    ((me)->rootState_subState == OdometerBackup_initialization)

/* ignition_status: */
/*## statechart_method */
#define OdometerBackup_ignition_status_IN(me)    \
    ((me)->rootState_subState == OdometerBackup_ignition_status)

/* pause: */
/*## statechart_method */
#define OdometerBackup_pause_IN(me)    \
    ((me)->ignition_status_subState == OdometerBackup_pause)

/* backup_enabled: */
/*## statechart_method */
#define OdometerBackup_backup_enabled_IN(me)    \
    ((me)->ignition_status_subState == OdometerBackup_backup_enabled)

/*## statechart_method */
RiCTakeEventStatus OdometerBackup_backup_enabled_takeEvent(OdometerBackup* const me, RiCEventId id);

/* backup_odometer: */
/*## statechart_method */
#define OdometerBackup_backup_odometer_IN(me)    \
    ((me)->backup_enabled_subState == OdometerBackup_backup_odometer)

/*## statechart_method */
RiCTakeEventStatus OdometerBackup_backup_odometer_takeEvent(OdometerBackup* const me, RiCEventId id);

/* accessory: */
/*## statechart_method */
#define OdometerBackup_accessory_IN(me)    \
    ((me)->backup_enabled_subState == OdometerBackup_accessory)

/*## statechart_method */
RiCTakeEventStatus OdometerBackup_accessory_takeEvent(OdometerBackup* const me, RiCEventId id);

/***    Framework entries    ***/

/*#[ ignore */
enum OdometerBackup_Enum {
    OdometerBackup_RiCNonState = 0,
    OdometerBackup_initialization = 1,
    OdometerBackup_ignition_status = 2,
    OdometerBackup_pause = 3,
    OdometerBackup_backup_enabled = 4,
    OdometerBackup_backup_odometer = 5,
    OdometerBackup_accessory = 6
};
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdometerBackup.h
*********************************************************************/
