/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: I_EEPROM_Manager
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_EEPROM_Manager.h
*********************************************************************/

#ifndef I_EEPROM_Manager_H
#define I_EEPROM_Manager_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "OdoBackup_pkg.h"
/*## dependency Stubs */
#include "Stubs.h"
/*## operation ee_read_request(EEPROM_DATA_KEY) */
#include "Types_pkg.h"
/*#[ ignore */
struct I_EEPROM_Manager_Vtbl {
    size_t I_EEPROM_Manager_offset;
};
/*#]*/

/*## package OdoBackup_pkg */

/*## class I_EEPROM_Manager */
typedef struct I_EEPROM_Manager_t I_EEPROM_Manager;
struct I_EEPROM_Manager_t {
    const struct I_EEPROM_Manager_Vtbl * I_EEPROM_ManagerVtbl;
};

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void I_EEPROM_Manager_Init(I_EEPROM_Manager* const me, const struct I_EEPROM_Manager_Vtbl * vtbl);

/*## auto_generated */
void I_EEPROM_Manager_Cleanup(I_EEPROM_Manager* const me);

/***    User explicit entries    ***/


/* Operations */

/*## operation ee_read_request(EEPROM_DATA_KEY) */
uint32_T I_EEPROM_Manager_ee_read_request(I_EEPROM_Manager* const me, const EEPROM_DATA_KEY storedValue);

/*## operation ee_write_request(EEPROM_DATA_KEY,uint32_T) */
void I_EEPROM_Manager_ee_write_request(I_EEPROM_Manager* const me, const EEPROM_DATA_KEY key, uint32_T value);

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_EEPROM_Manager.h
*********************************************************************/
