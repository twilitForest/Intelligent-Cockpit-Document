/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: I_OdometerBackup
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_OdometerBackup.c
*********************************************************************/

/*## auto_generated */
#include "I_OdometerBackup.h"
/*## package OdoBackup_pkg */

/*## class I_OdometerBackup */
void I_OdometerBackup_Init(I_OdometerBackup* const me, const struct I_OdometerBackup_Vtbl * vtbl) {
    me->I_OdometerBackupVtbl = vtbl;
}

void I_OdometerBackup_Cleanup(I_OdometerBackup* const me) {
}

/*## operation get_Odometer_Node() */
uint32_T I_OdometerBackup_get_Odometer_Node(void * const void_me) {
    
    I_OdometerBackup * const me = (I_OdometerBackup *)void_me;
    uint32_T res;
    if (me != NULL)
    {
        struct I_OdometerBackup_Vtbl* vtbl = (struct I_OdometerBackup_Vtbl*)(me->I_OdometerBackupVtbl);
        if ((vtbl != NULL) && (vtbl->I_OdometerBackup_get_Odometer_Node != NULL))
        {
            size_t addr = (size_t)me;
            void* realMe = (void*)(addr - vtbl->I_OdometerBackup_offset);
            PRE_VTBL_CALL(void_me)
            res = (*vtbl->I_OdometerBackup_get_Odometer_Node)(realMe);
        }
    }
    return res;
    /*#[ operation get_Odometer_Node() */
    /*#]*/
}

/*## operation set_HardReset() */
void I_OdometerBackup_set_HardReset(void * const void_me) {
    
    I_OdometerBackup * const me = (I_OdometerBackup *)void_me;
    
    if (me != NULL)
    {
        struct I_OdometerBackup_Vtbl* vtbl = (struct I_OdometerBackup_Vtbl*)(me->I_OdometerBackupVtbl);
        if ((vtbl != NULL) && (vtbl->I_OdometerBackup_set_HardReset != NULL))
        {
            size_t addr = (size_t)me;
            void* realMe = (void*)(addr - vtbl->I_OdometerBackup_offset);
            PRE_VTBL_CALL(void_me)
            (*vtbl->I_OdometerBackup_set_HardReset)(realMe);
        }
    }
    
    /*#[ operation set_HardReset() */
    /*#]*/
}

/*## operation set_IgnitionStatus(ignition_status_T) */
void I_OdometerBackup_set_IgnitionStatus(void * const void_me, ignition_status_T ignition) {
    
    I_OdometerBackup * const me = (I_OdometerBackup *)void_me;
    
    if (me != NULL)
    {
        struct I_OdometerBackup_Vtbl* vtbl = (struct I_OdometerBackup_Vtbl*)(me->I_OdometerBackupVtbl);
        if ((vtbl != NULL) && (vtbl->I_OdometerBackup_set_IgnitionStatus != NULL))
        {
            size_t addr = (size_t)me;
            void* realMe = (void*)(addr - vtbl->I_OdometerBackup_offset);
            PRE_VTBL_CALL(ignition)
            (*vtbl->I_OdometerBackup_set_IgnitionStatus)(realMe,ignition);
        }
    }
    
    /*#[ operation set_IgnitionStatus(ignition_status_T) */
    /*#]*/
}

/*## operation set_OdometerMasterValue(uint32_T) */
void I_OdometerBackup_set_OdometerMasterValue(void * const void_me, uint32_T new_odoMasterValue) {
    
    I_OdometerBackup * const me = (I_OdometerBackup *)void_me;
    
    if (me != NULL)
    {
        struct I_OdometerBackup_Vtbl* vtbl = (struct I_OdometerBackup_Vtbl*)(me->I_OdometerBackupVtbl);
        if ((vtbl != NULL) && (vtbl->I_OdometerBackup_set_OdometerMasterValue != NULL))
        {
            size_t addr = (size_t)me;
            void* realMe = (void*)(addr - vtbl->I_OdometerBackup_offset);
            PRE_VTBL_CALL(new_odoMasterValue)
            (*vtbl->I_OdometerBackup_set_OdometerMasterValue)(realMe,new_odoMasterValue);
        }
    }
    
    /*#[ operation set_OdometerMasterValue(uint32_T) */
    /*#]*/
}

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_OdometerBackup.c
*********************************************************************/
