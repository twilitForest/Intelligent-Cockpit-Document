/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Simulation_pkg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_pkg.h
*********************************************************************/

#ifndef Simulation_pkg_H
#define Simulation_pkg_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "mxf\Utils\MemAlloc.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*#[ ignore */
#define evReprogramMasterOdo_Simulation_pkg_id 25801
/*#]*/

/*## auto_generated */
struct BackupOdometer_t;

/*## auto_generated */
struct Battery_t;

/*## auto_generated */
struct IgnitionStatus_t;

/*## auto_generated */
struct MasterOdometer_t;

/*## classInstance Simulation_bldr */
struct Simulation_bldr_t;

/*## package Simulation_pkg */


/*#[ ignore */
struct RiCMxfGlobals_t;
extern struct RiCMxfGlobals_t mxfGlobals;
/*#]*/

/*## classInstance Simulation_bldr */
extern struct Simulation_bldr_t Simulation_bldr;

/*## auto_generated */
void Simulation_pkg_OMInitializer_Init(void);

/*## auto_generated */
void Simulation_pkg_OMInitializer_Cleanup(void);

/*#[ ignore */
void Simulation_pkg_doExecute(void * const me);
/*#]*/

/*## auto_generated */
void Simulation_pkg_initRelations(void);

#ifdef _OMINSTRUMENT
void Simulation_pkg_OMEvent_Init(void);
#endif /* _OMINSTRUMENT */

/*## auto_generated */
RiCBoolean Simulation_pkg_startBehavior(void);

typedef RiCEvent evReprogramMasterOdo_ev;
/*#[ ignore */
RiCEvent * RiC_Create_evReprogramMasterOdo(void);
/*#]*/

/*#[ ignore */
RiCEvent * evReprogramMasterOdo(void);
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_pkg.h
*********************************************************************/
