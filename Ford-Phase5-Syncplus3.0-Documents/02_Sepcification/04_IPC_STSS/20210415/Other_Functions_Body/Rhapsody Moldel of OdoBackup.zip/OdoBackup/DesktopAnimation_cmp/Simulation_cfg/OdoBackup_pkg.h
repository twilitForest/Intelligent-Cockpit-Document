/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: OdoBackup_pkg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdoBackup_pkg.h
*********************************************************************/

#ifndef OdoBackup_pkg_H
#define OdoBackup_pkg_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "mxf\Utils\MemAlloc.h"
/*## event evIgnitionStatus(ignition_status_T) */
#include "Types_pkg.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*#[ ignore */
#define evIgnitionStatus_OdoBackup_pkg_id 22001

#define evOdoMasterValue_OdoBackup_pkg_id 22002

#define evHardReset_OdoBackup_pkg_id 22003
/*#]*/

/*## auto_generated */
struct I_EEPROM_Manager_t;

/*## auto_generated */
struct I_OdometerBackup_t;

/*## classInstance itsOdometerBackup */
struct OdometerBackup_t;

/*## package OdoBackup_pkg */


/*#[ ignore */
struct RiCMxfGlobals_t;
extern struct RiCMxfGlobals_t mxfGlobals;
/*#]*/

/*## classInstance itsOdometerBackup */
extern struct OdometerBackup_t itsOdometerBackup;

/*## auto_generated */
void OdoBackup_pkg_OMInitializer_Init(void);

/*## auto_generated */
void OdoBackup_pkg_OMInitializer_Cleanup(void);

/*#[ ignore */
void OdoBackup_pkg_doExecute(void * const me);

void setOdometerBackUpNODE_NP(void * const me, unsigned int p_OdometerBackUpNODE);
/*#]*/

/*## auto_generated */
void OdoBackup_pkg_initRelations(void);

#ifdef _OMINSTRUMENT
void OdoBackup_pkg_OMEvent_Init(void);
#endif /* _OMINSTRUMENT */

/*## auto_generated */
RiCBoolean OdoBackup_pkg_startBehavior(void);

typedef struct evIgnitionStatus_t evIgnitionStatus_ev;
/*## event evIgnitionStatus(ignition_status_T) */
struct evIgnitionStatus_t {
    ignition_status_T ignitionStatus;		/*## auto_generated */
    /*#[ ignore */
    RiCBoolean isAllocated;
    /*#]*/
};

/*#[ ignore */
RiCEvent * RiC_Create_evIgnitionStatus(ignition_status_T p_ignitionStatus);
/*#]*/

/*#[ ignore */
RiCEvent * evIgnitionStatus(ignition_status_T ignitionStatus);
evIgnitionStatus_ev *evIgnitionStatus_getData(const RiCEvent * const me);
/*#]*/

typedef struct evOdoMasterValue_t evOdoMasterValue_ev;
/*## event evOdoMasterValue(uint32_T) */
struct evOdoMasterValue_t {
    uint32_T new_odo_value;		/*## auto_generated */
    /*#[ ignore */
    RiCBoolean isAllocated;
    /*#]*/
};

/*#[ ignore */
RiCEvent * RiC_Create_evOdoMasterValue(uint32_T p_new_odo_value);
/*#]*/

/*#[ ignore */
RiCEvent * evOdoMasterValue(uint32_T new_odo_value);
evOdoMasterValue_ev *evOdoMasterValue_getData(const RiCEvent * const me);
/*#]*/

typedef RiCEvent evHardReset_ev;
/*#[ ignore */
RiCEvent * RiC_Create_evHardReset(void);
/*#]*/

/*#[ ignore */
RiCEvent * evHardReset(void);
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdoBackup_pkg.h
*********************************************************************/
