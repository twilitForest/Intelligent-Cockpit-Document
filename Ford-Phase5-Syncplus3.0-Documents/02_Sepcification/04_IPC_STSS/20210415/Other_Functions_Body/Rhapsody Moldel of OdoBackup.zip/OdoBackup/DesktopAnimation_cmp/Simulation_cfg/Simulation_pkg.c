/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Simulation_pkg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_pkg.c
*********************************************************************/

/*## auto_generated */
#include "Simulation_pkg.h"
/*## classInstance Simulation_bldr */
#include "Simulation_bldr.h"
/*## auto_generated */
#include "BackupOdometer.h"
/*## auto_generated */
#include "Battery.h"
/*## auto_generated */
#include "IgnitionStatus.h"
/*## auto_generated */
#include "MasterOdometer.h"
/*#[ ignore */
#define Simulation_pkg_Simulation_pkg_doExecute_SERIALIZE ARCSA_addAttribute_c(arcsmethod, "me", ARC_ptr2String(me));

#define evReprogramMasterOdo_SERIALIZE OM_NO_OP

#define evReprogramMasterOdo_UNSERIALIZE OM_NO_OP

#define evReprogramMasterOdo_DECLARE_PARAMS OM_NO_OP

#define evReprogramMasterOdo_CONSTRUCTOR RiC_Create_evReprogramMasterOdo()
/*#]*/

/*## package Simulation_pkg */


/*#[ ignore */
static RiCTimedAction ric_timedAction = {
	((void (*)(RhpAddress const))(Simulation_pkg_doExecute)),
	(NULL),
	(0U),
	(100U),
	1,
	(TRUE),
	(((RiCOSTimerHandle)0)),
	NULL
	, &(mxfGlobals.mainTask.ric_task)
};
/*#]*/

/*## classInstance Simulation_bldr */
struct Simulation_bldr_t Simulation_bldr = 
{    /* Simulation_bldr */
    /* ric_reactive */
    { 	
    	(&Simulation_bldr),	
    	(&(mxfGlobals.mainTask.ric_task)),
    	NULL,
    	(&Simulation_bldr_reactiveVtbl),
    	NULL,
    	RiCDefaultStatus,
    	RiCFALSE, 
    	RiCFALSE, 
    	RiCFALSE 
    }, 
    {    /* itsBackupOdometer */
        /* ric_reactive */
        { 	
        	(&Simulation_bldr.itsBackupOdometer),	
        	(&(mxfGlobals.mainTask.ric_task)),
        	NULL,
        	(&BackupOdometer_reactiveVtbl),
        	NULL,
        	RiCDefaultStatus,
        	RiCFALSE, 
        	RiCFALSE, 
        	RiCFALSE 
        }, 
        &(Simulation_bldr.itsOdometerBackup) /* itsOdometerBackup */
    }, 
    {    /* itsBattery */
        /* ric_reactive */
        { 	
        	(&Simulation_bldr.itsBattery),	
        	(&(mxfGlobals.mainTask.ric_task)),
        	NULL,
        	(&Battery_reactiveVtbl),
        	NULL,
        	RiCDefaultStatus,
        	RiCFALSE, 
        	RiCFALSE, 
        	RiCFALSE 
        }, 
        &(Simulation_bldr.itsOdometerBackup) /* itsOdometerBackup */,
        FALSE /* hardreset */
    }, 
    {    /* itsIgnitionStatus */
        /* ric_reactive */
        { 	
        	(&Simulation_bldr.itsIgnitionStatus),	
        	(&(mxfGlobals.mainTask.ric_task)),
        	NULL,
        	(&IgnitionStatus_reactiveVtbl),
        	NULL,
        	RiCDefaultStatus,
        	RiCFALSE, 
        	RiCFALSE, 
        	RiCFALSE 
        }, 
        &(Simulation_bldr.itsOdometerBackup) /* itsOdometerBackup */
    }, 
    {    /* itsMasterOdometer */
        /* ric_reactive */
        { 	
        	(&Simulation_bldr.itsMasterOdometer),	
        	(&(mxfGlobals.mainTask.ric_task)),
        	NULL,
        	(&MasterOdometer_reactiveVtbl),
        	NULL,
        	RiCDefaultStatus,
        	RiCFALSE, 
        	RiCFALSE, 
        	RiCFALSE 
        }, 
        &(Simulation_bldr.itsIgnitionStatus) /* itsIgnitionStatus */, 
        &(Simulation_bldr.itsOdometerBackup) /* itsOdometerBackup */
    }, 
    {    /* itsOdometerBackup */
        {0} /* _I_OdometerBackup */, 
        /* ric_reactive */
        { 	
        	(&Simulation_bldr.itsOdometerBackup),	
        	(&(mxfGlobals.mainTask.ric_task)),
        	NULL,
        	(&OdometerBackup_reactiveVtbl),
        	NULL,
        	RiCDefaultStatus,
        	RiCFALSE, 
        	RiCFALSE, 
        	RiCFALSE 
        },
        NULL /* odoBackupValue_cb */,
        NULL /* odoBackupValue_trg */,
        0 /* odoBackupValue */,
        0 /* odoMasterValue */,
        FALSE /* tamper_flg */
    }
};

#ifdef _OMINSTRUMENT
static void serializeGlobalVars(ARCSAttributes * arcsAttributes);

static void serializeGlobalItems(ARCSRelations * arcsRelations);

static void RenameGlobalInstances(void);

/*#[ ignore */
static const ARCSerGVtbl Simulation_pkg_instrumentVtbl = {
    &serializeGlobalVars,
    &serializeGlobalItems
};
/*#]*/

OM_INSTRUMENT_PACKAGE(Simulation_pkg, Simulation_pkg, &Simulation_pkg_instrumentVtbl)
#endif /* _OMINSTRUMENT */

void Simulation_pkg_OMInitializer_Init(void) {
    Simulation_pkg_OMEvent_Init();
    Simulation_pkg_initRelations();
    (void) Simulation_pkg_startBehavior();
}

void Simulation_pkg_OMInitializer_Cleanup(void) {
}

/*#[ ignore */
void Simulation_pkg_doExecute(void * const me) {
    NOTIFY_FUNCTION(me, &me, Simulation_pkg, Simulation_pkg_doExecute, Simulation_pkg_doExecute(void * const), 1, Simulation_pkg_Simulation_pkg_doExecute_SERIALIZE);
    {
        RiCTaskEM_beginMyTask(RiCMainTask());
        RiCTaskEM_doExecute(RiCMainTask());
        
        RiCTaskEM_endMyTask(RiCMainTask());
    }
}
/*#]*/

void Simulation_pkg_initRelations(void) {
    RiCTimedAction_init(&ric_timedAction, (void (*)(void * const))Simulation_pkg_doExecute, NULL, 0U, 100U, ((RiCOSTimerHandle)0), TRUE, RiCMainTask(), &mxfGlobals);
    Simulation_bldr_Init(&(Simulation_bldr), RiCMainTask());
    
    #ifdef _OMINSTRUMENT
    RenameGlobalInstances();
    #endif /* _OMINSTRUMENT*/
}

#ifdef _OMINSTRUMENT
void Simulation_pkg_OMEvent_Init(void) {
    ARC_INIT_EVENT(evReprogramMasterOdo);
}
#endif /* _OMINSTRUMENT */

RiCBoolean Simulation_pkg_startBehavior(void) {
    RiCBoolean done = RiCTRUE;
    done &= Simulation_bldr_startBehavior(&(Simulation_bldr));
    return done;
}

#ifdef _OMINSTRUMENT
static void serializeGlobalVars(ARCSAttributes * arcsAttributes) {
}

static void serializeGlobalItems(ARCSRelations * arcsRelations) {
    ARCSRS_addRelation(arcsRelations, "Simulation_bldr", TRUE, TRUE);
    ARCSRS_addItem(arcsRelations, Simulation_bldr, &(Simulation_bldr));
}

static void RenameGlobalInstances(void) {
    ARCAI_SetName(&(Simulation_bldr), Simulation_bldr, "Simulation_bldr", ARCNoMultiplicity);
}
#endif /* _OMINSTRUMENT */

/*#[ ignore */
RiCEvent * evReprogramMasterOdo(void)
{
	return RiC_Create_evReprogramMasterOdo();
}

/*#]*/

OM_INSTRUMENT_EVENT(evReprogramMasterOdo, Simulation_pkg, Simulation_pkg, evReprogramMasterOdo(), me)

/*#[ ignore */
static void RiC_Destroy_evReprogramMasterOdo(RiCEvent* const me);
/*#]*/

/*## auto_generated */
static void evReprogramMasterOdo_Init(RiCEvent* const me);

static void evReprogramMasterOdo_Init(RiCEvent* const me) {
    OM_INSTRUMENT_EVENT_INSTANCE(me, evReprogramMasterOdo)
    RiCEvent_init(me, evReprogramMasterOdo_Simulation_pkg_id);
    me->eventDestroyOp = RiC_Destroy_evReprogramMasterOdo;
}

/*## auto_generated */
static void evReprogramMasterOdo_Cleanup(RiCEvent* const me);

static void evReprogramMasterOdo_Cleanup(RiCEvent* const me) {
    RiCEvent_cleanup(me);
}

/*#[ ignore */
RiCEvent * RiC_Create_evReprogramMasterOdo(void) {
    RiCEvent* me = NULL;
    RiCEvent_lockEventsPoolMutex();
    /*LDRA_INSPECTED 71 S : Pointer is assigned to memory from wider scope */
    me = RiCEvent_getMemory(&mxfGlobals);
    RiCEvent_freeEventsPoolMutex();
    if(me!=NULL)
        {
            evReprogramMasterOdo_Init(me);
        }
    return me;
}

static void RiC_Destroy_evReprogramMasterOdo(RiCEvent* const me) {
    if(me!=NULL)
        {
            evReprogramMasterOdo_Cleanup(me);
        }
    RiCEvent_returnMemory(me);
}
/*#]*/

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_pkg.c
*********************************************************************/
