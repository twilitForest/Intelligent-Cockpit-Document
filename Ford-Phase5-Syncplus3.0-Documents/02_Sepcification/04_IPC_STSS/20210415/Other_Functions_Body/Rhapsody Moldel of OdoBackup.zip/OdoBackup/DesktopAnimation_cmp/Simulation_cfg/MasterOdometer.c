/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: MasterOdometer
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MasterOdometer.c
*********************************************************************/

/*## auto_generated */
#include "MasterOdometer.h"
/*## link itsIgnitionStatus */
#include "IgnitionStatus.h"
/*## link itsOdometerBackup */
#include "OdometerBackup.h"
/*#[ ignore */
#define Simulation_pkg_MasterOdometer_MasterOdometer_SERIALIZE OM_NO_OP

#define Simulation_pkg_MasterOdometer_updateOdo_SERIALIZE OM_NO_OP

#define OMAnim_Simulation_pkg_MasterOdometer_setInc_dec_odo_int_UNSERIALIZE_ARGS OP_UNSER(ARC_destructiveString2X_int,p_inc_dec_odo)

#define OMAnim_Simulation_pkg_MasterOdometer_setInc_dec_odo_int_SERIALIZE_RET_VAL

#define OMAnim_Simulation_pkg_MasterOdometer_setReprogramMasterOdo_uint32_T_UNSERIALIZE_ARGS OP_UNSER(ARC_destructiveString2X_unsigned_int,p_reprogramMasterOdo)

#define OMAnim_Simulation_pkg_MasterOdometer_setReprogramMasterOdo_uint32_T_SERIALIZE_RET_VAL

#define MasterOdometer_REGISTER_OPER_STMT \
     REGISTER_OPERATION(Simulation_pkg_MasterOdometer_setInc_dec_odo_int, "MasterOdometer_setInc_dec_odo", FALSE, "MasterOdometer_setInc_dec_odo(int)", 1) \
     REGISTER_OPERATION(Simulation_pkg_MasterOdometer_setReprogramMasterOdo_uint32_T, "MasterOdometer_setReprogramMasterOdo", FALSE, "MasterOdometer_setReprogramMasterOdo(uint32_T)", 1)
/*#]*/

/*## package Simulation_pkg */

/*## class MasterOdometer */
/*## operation updateOdo() */
static void updateOdo(MasterOdometer* const me);

/*## auto_generated */
static void initStatechart(MasterOdometer* const me);

#ifdef _OMINSTRUMENT
static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes);

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations);

/*## statechart_method */
static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*## statechart_method */
static void rootState_entDef(void * const void_me);

/*## statechart_method */
static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id);

#ifdef _OMINSTRUMENT
/*## statechart_method */
static void SimNewOdo_serializeStates(const MasterOdometer* const me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*#[ ignore */
const RiCReactive_Vtbl MasterOdometer_reactiveVtbl = {
    rootState_dispatchEvent,
    rootState_entDef,
    ROOT_STATE_SERIALIZE_STATES(rootState_serializeStates),
    NULL
};

static const ARCSerCVtbl Simulation_pkg_MasterOdometer_instrumentVtbl = {
    serializeAttributes,
    serializeRelations
};
/*#]*/

#ifdef _OMINSTRUMENT
OM_INSTRUMENT_OBJECT_TYPE(MasterOdometer, Simulation_pkg, Simulation_pkg, FALSE, &Simulation_pkg_MasterOdometer_instrumentVtbl)

IMPLEMENT_OPERATION_CLASS(Simulation_pkg_MasterOdometer_setInc_dec_odo_int, MasterOdometer, MasterOdometer_setInc_dec_odo(realInst, me->p_inc_dec_odo), NO_OP())

IMPLEMENT_OPERATION_CLASS(Simulation_pkg_MasterOdometer_setReprogramMasterOdo_uint32_T, MasterOdometer, MasterOdometer_setReprogramMasterOdo(realInst, me->p_reprogramMasterOdo), NO_OP())

IMPLEMENT_REGISTER_OPERATION_CLASSES(MasterOdometer)
#endif /* _OMINSTRUMENT */

void MasterOdometer_Init(MasterOdometer* const me, RiCTaskEM * p_task) {
    /* Violation of MISRA Rule 45 (Required): */
    /* 'Type casting to or from pointers shall not be used.' */
    /* The following cast into void* is justified */
    /* and is for Rhapsody auto-generated code use only. */
    /*LDRA_INSPECTED 94 S */
    /*LDRA_INSPECTED 95 S */ /*LDRA_INSPECTED 203 S */
    RiCReactive_init(&(me->ric_reactive), (void*)me, p_task, &MasterOdometer_reactiveVtbl, &mxfGlobals);
    NOTIFY_REACTIVE_CONSTRUCTOR_WITH_OPER_INVOKE(me, &me, NULL, MasterOdometer, MasterOdometer_Init, MasterOdometer_Init(), 0, Simulation_pkg_MasterOdometer_MasterOdometer_SERIALIZE);
    RiCReactive_setActive(&(me->ric_reactive), RiCFALSE);
    initStatechart(me);
    NOTIFY_END_CONSTRUCTOR(me);
}

void MasterOdometer_Cleanup(MasterOdometer* const me) {
    NOTIFY_DESTRUCTOR(me, &me, MasterOdometer, ~MasterOdometer);
    RiCReactive_cleanup(&(me->ric_reactive));
}

/*## operation updateOdo() */
static void updateOdo(MasterOdometer* const me) {
    NOTIFY_OPERATION(me, &me, NULL, MasterOdometer, updateOdo, updateOdo(), 0, Simulation_pkg_MasterOdometer_updateOdo_SERIALIZE);
    {
        /*#[ operation updateOdo() */
        me->ignition = IgnitionStatus_getIgnitionState(me->itsIgnitionStatus);    
        //printf("igition: %d\n", me->ignition);
        
        if ( me->ignition == RUN || 
        	 me->ignition == START )
        {
        	me->masterOdo = me->masterOdo + me->inc_dec_odo;
        	I_OdometerBackup_set_OdometerMasterValue(me->itsOdometerBackup,me->masterOdo);
        }
        /*#]*/
    }
}

void MasterOdometer_setInc_dec_odo(MasterOdometer* const me, int p_inc_dec_odo) {
    me->inc_dec_odo = p_inc_dec_odo;
    NOTIFY_SET_OPERATION(me, MasterOdometer);
}

void MasterOdometer_setReprogramMasterOdo(MasterOdometer* const me, uint32_T p_reprogramMasterOdo) {
    me->reprogramMasterOdo = p_reprogramMasterOdo;
    NOTIFY_SET_OPERATION(me, MasterOdometer);
}

RiCBoolean MasterOdometer_startBehavior(MasterOdometer* const me) {
    RiCBoolean done = RiCFALSE;
    done = RiCReactive_startBehavior(&(me->ric_reactive), &mxfGlobals);
    return done;
}

static void initStatechart(MasterOdometer* const me) {
    me->rootState_subState = MasterOdometer_RiCNonState;
    me->rootState_active = MasterOdometer_RiCNonState;
}

#ifdef _OMINSTRUMENT
void MasterOdometer_updateRelations(MasterOdometer* const me) {
    NOTIFY_RELATION_ITEM_ADDED(me, MasterOdometer, OdometerBackup, "itsOdometerBackup", me->itsOdometerBackup, FALSE, TRUE);
    NOTIFY_RELATION_ITEM_ADDED(me, MasterOdometer, IgnitionStatus, "itsIgnitionStatus", me->itsIgnitionStatus, FALSE, TRUE);
}

static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes) {
    
    const MasterOdometer * const me = (const MasterOdometer *)void_me;
    ARCSA_addAttribute_c(arcsAttributes, "masterOdo", ARC_unsigned_int2String(me->masterOdo));
    ARCSA_addAttribute_c(arcsAttributes, "inc_dec_odo", ARC_int2String(me->inc_dec_odo));
    ARCSA_addAttribute_c(arcsAttributes, "ignition", ARC_int2String((int)me->ignition));
    ARCSA_addAttribute_c(arcsAttributes, "reprogramMasterOdo", ARC_unsigned_int2String(me->reprogramMasterOdo));
}

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations) {
    
    const MasterOdometer * const me = (const MasterOdometer *)void_me;
    ARCSRS_addRelation(arcsRelations, "itsOdometerBackup", FALSE, TRUE);
    if(me->itsOdometerBackup)
        {
            ARCSRS_addItem(arcsRelations, OdometerBackup, me->itsOdometerBackup);
        }
    ARCSRS_addRelation(arcsRelations, "itsIgnitionStatus", FALSE, TRUE);
    if(me->itsIgnitionStatus)
        {
            ARCSRS_addItem(arcsRelations, IgnitionStatus, me->itsIgnitionStatus);
        }
}

static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState) {
    
    const MasterOdometer * const me = (const MasterOdometer *)void_me;
    ARCSS_addState_OMH(arcsState, "ROOT");
    if(me->rootState_subState == MasterOdometer_SimNewOdo)
        {
            SimNewOdo_serializeStates(me, arcsState);
        }
}
#endif /* _OMINSTRUMENT */

static void rootState_entDef(void * const void_me) {
    
    MasterOdometer * const me = (MasterOdometer *)void_me;
    {
        NOTIFY_STATE_ENTERED(me, MasterOdometer, "ROOT");
        NOTIFY_STATE_ENTERED(me, MasterOdometer, "ROOT.SimNewOdo");
        me->rootState_subState = MasterOdometer_SimNewOdo;
        me->rootState_active = MasterOdometer_SimNewOdo;
        RiCTaskEM_schedTm(me->ric_reactive.myTask, 100, MasterOdometer_Timeout_SimNewOdo_id, &(me->ric_reactive), "ROOT.SimNewOdo", &mxfGlobals);
    }
}

static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id) {
    
    MasterOdometer * const me = (MasterOdometer *)void_me;
    RiCTakeEventStatus res = eventNotConsumed;
    if(me->rootState_active == MasterOdometer_SimNewOdo)
        {
            switch (id) {
                case evReprogramMasterOdo_Simulation_pkg_id:
                {
                    NOTIFY_TRANSITION_STARTED(me, MasterOdometer, "1");
                    RiCTaskEM_unschedTm(me->ric_reactive.myTask, MasterOdometer_Timeout_SimNewOdo_id, &(me->ric_reactive), &mxfGlobals);
                    NOTIFY_STATE_EXITED(me, MasterOdometer, "ROOT.SimNewOdo");
                    {
                        /*#[ transition 1 */
                        
                        me->masterOdo = me->reprogramMasterOdo;
                        I_OdometerBackup_set_OdometerMasterValue(me->itsOdometerBackup,me->reprogramMasterOdo);
                        /*#]*/
                    }
                    NOTIFY_STATE_ENTERED(me, MasterOdometer, "ROOT.SimNewOdo");
                    me->rootState_subState = MasterOdometer_SimNewOdo;
                    me->rootState_active = MasterOdometer_SimNewOdo;
                    RiCTaskEM_schedTm(me->ric_reactive.myTask, 100, MasterOdometer_Timeout_SimNewOdo_id, &(me->ric_reactive), "ROOT.SimNewOdo", &mxfGlobals);
                    NOTIFY_TRANSITION_TERMINATED(me, MasterOdometer, "1");
                    res = eventConsumed;
                }
                break;
                case Timeout_id:
                {
                    if(RiCTimeout_getTimeoutId(me->ric_reactive.current_event) == MasterOdometer_Timeout_SimNewOdo_id)
                        {
                            NOTIFY_TRANSITION_STARTED(me, MasterOdometer, "0");
                            RiCTaskEM_unschedTm(me->ric_reactive.myTask, MasterOdometer_Timeout_SimNewOdo_id, &(me->ric_reactive), &mxfGlobals);
                            NOTIFY_STATE_EXITED(me, MasterOdometer, "ROOT.SimNewOdo");
                            {
                                /*#[ transition 0 */
                                updateOdo(me);
                                /*#]*/
                            }
                            NOTIFY_STATE_ENTERED(me, MasterOdometer, "ROOT.SimNewOdo");
                            me->rootState_subState = MasterOdometer_SimNewOdo;
                            me->rootState_active = MasterOdometer_SimNewOdo;
                            RiCTaskEM_schedTm(me->ric_reactive.myTask, 100, MasterOdometer_Timeout_SimNewOdo_id, &(me->ric_reactive), "ROOT.SimNewOdo", &mxfGlobals);
                            NOTIFY_TRANSITION_TERMINATED(me, MasterOdometer, "0");
                            res = eventConsumed;
                        }
                }
                break;
                default:
                    break;
            }
        }
    return res;
}

#ifdef _OMINSTRUMENT
static void SimNewOdo_serializeStates(const MasterOdometer* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.SimNewOdo");
}
#endif /* _OMINSTRUMENT */

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MasterOdometer.c
*********************************************************************/
