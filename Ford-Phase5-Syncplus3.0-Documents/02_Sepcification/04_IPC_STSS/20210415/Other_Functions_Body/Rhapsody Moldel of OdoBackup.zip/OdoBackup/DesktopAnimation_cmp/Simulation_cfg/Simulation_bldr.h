/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Simulation_bldr
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_bldr.h
*********************************************************************/

#ifndef Simulation_bldr_H
#define Simulation_bldr_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "Simulation_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## auto_generated */
#include "mxf\RiCReactive.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*## classInstance itsBackupOdometer */
#include "BackupOdometer.h"
/*## classInstance itsBattery */
#include "Battery.h"
/*## classInstance itsIgnitionStatus */
#include "IgnitionStatus.h"
/*## classInstance itsMasterOdometer */
#include "MasterOdometer.h"
/*## classInstance itsOdometerBackup */
#include "OdometerBackup.h"
/*## package Simulation_pkg */

/*## class TopLevel::Simulation_bldr */
struct Simulation_bldr_t {
    RiCReactive ric_reactive;
    struct BackupOdometer_t itsBackupOdometer;		/*## classInstance itsBackupOdometer */
    struct Battery_t itsBattery;		/*## classInstance itsBattery */
    struct IgnitionStatus_t itsIgnitionStatus;		/*## classInstance itsIgnitionStatus */
    struct MasterOdometer_t itsMasterOdometer;		/*## classInstance itsMasterOdometer */
    struct OdometerBackup_t itsOdometerBackup;		/*## classInstance itsOdometerBackup */
};

/*#[ ignore */
extern const RiCReactive_Vtbl Simulation_bldr_reactiveVtbl;
/*#]*/

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void Simulation_bldr_Init(struct Simulation_bldr_t* const me, RiCTaskEM * p_task);

/*## auto_generated */
void Simulation_bldr_Cleanup(struct Simulation_bldr_t* const me);

/*## auto_generated */
struct BackupOdometer_t* Simulation_bldr_getItsBackupOdometer(const struct Simulation_bldr_t* const me);

/*## auto_generated */
struct Battery_t* Simulation_bldr_getItsBattery(const struct Simulation_bldr_t* const me);

/*## auto_generated */
struct IgnitionStatus_t* Simulation_bldr_getItsIgnitionStatus(const struct Simulation_bldr_t* const me);

/*## auto_generated */
struct MasterOdometer_t* Simulation_bldr_getItsMasterOdometer(const struct Simulation_bldr_t* const me);

/*## auto_generated */
struct OdometerBackup_t* Simulation_bldr_getItsOdometerBackup(const struct Simulation_bldr_t* const me);

/*## auto_generated */
RiCBoolean Simulation_bldr_startBehavior(struct Simulation_bldr_t* const me);

/***    Framework entries    ***/


#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_bldr.h
*********************************************************************/
