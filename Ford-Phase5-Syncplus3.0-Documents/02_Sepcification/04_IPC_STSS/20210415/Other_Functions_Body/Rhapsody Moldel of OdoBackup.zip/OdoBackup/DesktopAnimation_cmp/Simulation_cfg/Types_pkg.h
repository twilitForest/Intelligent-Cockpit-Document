/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Types_pkg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Types_pkg.h
*********************************************************************/

#ifndef Types_pkg_H
#define Types_pkg_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## package Types_pkg */


/*## type uint32_T */
typedef unsigned int uint32_T;

/*## type EEPROM_DATA_KEY */
typedef enum EEPROM_DATA_KEY_t {
    EE_ODO_VALUE_NODE
} EEPROM_DATA_KEY;

/*## type ignition_status_T */
typedef enum ignition_status_T_t {
    UNKNOWN = 0x0,
    OFF = 0x1,
    ACCESSORY = 0x2,
    RUN = 0x4,
    START = 0x8,
    INVALID = 0xF
} ignition_status_T;

/*## type uint8_T */
typedef unsigned char uint8_T;

/*## type uint16_T */
typedef unsigned short uint16_T;

/*#[ ignore */
#define WAIT_FOR_MILEAGE	1000U  /* 1000 km */
#define MASTER_ODO_LT_THRESH 1U
#define MASTER_ODO_GT_THRESH 1000U
#define DO_NOTHING_VALUE 0U
struct RiCMxfGlobals_t;
extern struct RiCMxfGlobals_t mxfGlobals;
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Types_pkg.h
*********************************************************************/
