/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Battery
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Battery.h
*********************************************************************/

#ifndef Battery_H
#define Battery_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "Simulation_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## auto_generated */
#include "mxf\RiCReactive.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*#[ ignore */
#define Battery_Timeout_batt_id 1
/*#]*/

/*## link itsOdometerBackup */
struct OdometerBackup_t;

/*## package Simulation_pkg */

/*## class Battery */
typedef struct Battery_t Battery;
struct Battery_t {
    RiCReactive ric_reactive;
    struct OdometerBackup_t* const itsOdometerBackup;		/*## link itsOdometerBackup */
    RiCBoolean hardreset;		/*## attribute hardreset */
    /*#[ ignore */
    RhpInteger rootState_subState;
    RhpInteger rootState_active;
    /*#]*/
};

/*#[ ignore */
extern const RiCReactive_Vtbl Battery_reactiveVtbl;
/*#]*/

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void Battery_Init(Battery* const me, RiCTaskEM * p_task);

/*## auto_generated */
void Battery_Cleanup(Battery* const me);

/***    User explicit entries    ***/


/* Operations */

/*## operation set_HardReset() */
void Battery_set_HardReset(Battery* const me);

/*## auto_generated */
RiCBoolean Battery_startBehavior(Battery* const me);

/***    Framework entries    ***/

#ifdef _OMINSTRUMENT
void Battery_updateRelations(Battery* const me);
#endif /* _OMINSTRUMENT */

/* rootState: */
/*## statechart_method */
#define Battery_rootState_IN(me)    \
    (1)

/* batt: */
/*## statechart_method */
#define Battery_batt_IN(me)    \
    ((me)->rootState_subState == Battery_batt)

/***    Framework entries    ***/

/*#[ ignore */
enum Battery_Enum {
    Battery_RiCNonState = 0,
    Battery_batt = 1
};
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Battery.h
*********************************************************************/
