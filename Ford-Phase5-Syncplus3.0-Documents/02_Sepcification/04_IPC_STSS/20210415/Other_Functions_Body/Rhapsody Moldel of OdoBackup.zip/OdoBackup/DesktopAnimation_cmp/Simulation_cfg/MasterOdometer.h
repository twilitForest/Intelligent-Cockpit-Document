/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: MasterOdometer
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MasterOdometer.h
*********************************************************************/

#ifndef MasterOdometer_H
#define MasterOdometer_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "Simulation_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## auto_generated */
#include "mxf\RiCReactive.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*## attribute ignition */
#include "Types_pkg.h"
/*#[ ignore */
#define MasterOdometer_Timeout_SimNewOdo_id 1

#define OMAnim_Simulation_pkg_MasterOdometer_setInc_dec_odo_int_ARGS_DECLARATION int p_inc_dec_odo;

#define OMAnim_Simulation_pkg_MasterOdometer_setReprogramMasterOdo_uint32_T_ARGS_DECLARATION uint32_T p_reprogramMasterOdo;
/*#]*/

/*## link itsIgnitionStatus */
struct IgnitionStatus_t;

/*## link itsOdometerBackup */
struct OdometerBackup_t;

/*## package Simulation_pkg */

/*## class MasterOdometer */
typedef struct MasterOdometer_t MasterOdometer;
struct MasterOdometer_t {
    RiCReactive ric_reactive;
    struct IgnitionStatus_t* const itsIgnitionStatus;		/*## link itsIgnitionStatus */
    struct OdometerBackup_t* const itsOdometerBackup;		/*## link itsOdometerBackup */
    ignition_status_T ignition;		/*## attribute ignition */
    int inc_dec_odo;		/*## attribute inc_dec_odo */
    uint32_T masterOdo;		/*## attribute masterOdo */
    uint32_T reprogramMasterOdo;		/*## attribute reprogramMasterOdo */
    /*#[ ignore */
    RhpInteger rootState_subState;
    RhpInteger rootState_active;
    /*#]*/
};

/*#[ ignore */
extern const RiCReactive_Vtbl MasterOdometer_reactiveVtbl;
/*#]*/

#ifdef _OMINSTRUMENT
DECLARE_OPERATION_CLASS(Simulation_pkg_MasterOdometer_setInc_dec_odo_int)

DECLARE_OPERATION_CLASS(Simulation_pkg_MasterOdometer_setReprogramMasterOdo_uint32_T)
#endif /* _OMINSTRUMENT */

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void MasterOdometer_Init(MasterOdometer* const me, RiCTaskEM * p_task);

/*## auto_generated */
void MasterOdometer_Cleanup(MasterOdometer* const me);

/*## auto_generated */
void MasterOdometer_setInc_dec_odo(MasterOdometer* const me, int p_inc_dec_odo);

/*## auto_generated */
void MasterOdometer_setReprogramMasterOdo(MasterOdometer* const me, uint32_T p_reprogramMasterOdo);

/*## auto_generated */
RiCBoolean MasterOdometer_startBehavior(MasterOdometer* const me);

/***    Framework entries    ***/

#ifdef _OMINSTRUMENT
void MasterOdometer_updateRelations(MasterOdometer* const me);
#endif /* _OMINSTRUMENT */

/* rootState: */
/*## statechart_method */
#define MasterOdometer_rootState_IN(me)    \
    (1)

/* SimNewOdo: */
/*## statechart_method */
#define MasterOdometer_SimNewOdo_IN(me)    \
    ((me)->rootState_subState == MasterOdometer_SimNewOdo)

/***    Framework entries    ***/

/*#[ ignore */
enum MasterOdometer_Enum {
    MasterOdometer_RiCNonState = 0,
    MasterOdometer_SimNewOdo = 1
};
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MasterOdometer.h
*********************************************************************/
