/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: BackupOdometer
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\BackupOdometer.h
*********************************************************************/

#ifndef BackupOdometer_H
#define BackupOdometer_H

/*## auto_generated */
#include "mxf\Ric.h"
/*## auto_generated */
#include "Simulation_pkg.h"
/*## auto_generated */
#include "mxf\RiCTaskEM.h"
/*## auto_generated */
#include "mxf\RiCReactive.h"
/*## auto_generated */
#include "mxf\RiCEvent.h"
/*## attribute Odometer_Value_Node */
#include "Types_pkg.h"
/*#[ ignore */
#define BackupOdometer_Timeout_backupOdo_id 1
/*#]*/

/*## link itsOdometerBackup */
struct OdometerBackup_t;

/*## package Simulation_pkg */

/*## class BackupOdometer */
typedef struct BackupOdometer_t BackupOdometer;
struct BackupOdometer_t {
    RiCReactive ric_reactive;
    struct OdometerBackup_t* const itsOdometerBackup;		/*## link itsOdometerBackup */
    uint32_T Odometer_Value_Node;		/*## attribute Odometer_Value_Node */
    /*#[ ignore */
    RhpInteger rootState_subState;
    RhpInteger rootState_active;
    /*#]*/
};

/*#[ ignore */
extern const RiCReactive_Vtbl BackupOdometer_reactiveVtbl;
/*#]*/

/***    User implicit entries    ***/


/* Constructors and destructors:*/

/*## auto_generated */
void BackupOdometer_Init(BackupOdometer* const me, RiCTaskEM * p_task);

/*## auto_generated */
void BackupOdometer_Cleanup(BackupOdometer* const me);

/*## auto_generated */
void BackupOdometer_setOdometer_Value_Node(BackupOdometer* const me, uint32_T p_Odometer_Value_Node);

/*## auto_generated */
RiCBoolean BackupOdometer_startBehavior(BackupOdometer* const me);

/***    Framework entries    ***/

#ifdef _OMINSTRUMENT
void BackupOdometer_updateRelations(BackupOdometer* const me);
#endif /* _OMINSTRUMENT */

/* rootState: */
/*## statechart_method */
#define BackupOdometer_rootState_IN(me)    \
    (1)

/* backupOdo: */
/*## statechart_method */
#define BackupOdometer_backupOdo_IN(me)    \
    ((me)->rootState_subState == BackupOdometer_backupOdo)

/***    Framework entries    ***/

/*#[ ignore */
enum BackupOdometer_Enum {
    BackupOdometer_RiCNonState = 0,
    BackupOdometer_backupOdo = 1
};
/*#]*/

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\BackupOdometer.h
*********************************************************************/
