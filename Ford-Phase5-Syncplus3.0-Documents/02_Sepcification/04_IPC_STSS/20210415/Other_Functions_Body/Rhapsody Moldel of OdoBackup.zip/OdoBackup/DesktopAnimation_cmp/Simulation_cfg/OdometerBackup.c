/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: OdometerBackup
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdometerBackup.c
*********************************************************************/

/*## auto_generated */
#include "OdometerBackup.h"
/*## link itsI_EEPROM_Manager */
#include "I_EEPROM_Manager.h"
/*#[ ignore */
#define OdoBackup_pkg_OdometerBackup_OdometerBackup_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_OdometerBackup_Operation_21_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_OdometerBackup_checkForTamper_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_OdometerBackup_checkInitialMileage_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_OdometerBackup_get_Odometer_Node_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_OdometerBackup_set_HardReset_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_OdometerBackup_set_IgnitionStatus_SERIALIZE ARCSA_addAttribute_c(arcsmethod, "ignition", ARC_int2String((int)ignition));

#define OdoBackup_pkg_OdometerBackup_set_OdometerMasterValue_SERIALIZE ARCSA_addAttribute_c(arcsmethod, "new_odoMasterValue", ARC_unsigned_int2String(new_odoMasterValue));
/*#]*/

/*## package OdoBackup_pkg */

/*## class OdometerBackup */
/*## statechart_method */
static void checkForTamper(OdometerBackup* const me);

/*## statechart_method */
static void checkInitialMileage(OdometerBackup* const me);

/*## auto_generated */
static void initStatechart(OdometerBackup* const me);

#ifdef _OMINSTRUMENT
static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes);

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations);

/*## statechart_method */
static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*## statechart_method */
static void rootState_entDef(void * const void_me);

/*## statechart_method */
static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id);

#ifdef _OMINSTRUMENT
/*## statechart_method */
static void initialization_serializeStates(const OdometerBackup* const me, ARCSState * arcsState);

/*## statechart_method */
static void ignition_status_serializeStates(const OdometerBackup* const me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*## statechart_method */
static void ignition_status_entDef(OdometerBackup* const me);

#ifdef _OMINSTRUMENT
/*## statechart_method */
static void pause_serializeStates(const OdometerBackup* const me, ARCSState * arcsState);

/*## statechart_method */
static void backup_enabled_serializeStates(const OdometerBackup* const me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*## statechart_method */
static void backup_enabled_entDef(OdometerBackup* const me);

#ifdef _OMINSTRUMENT
/*## statechart_method */
static void backup_odometer_serializeStates(const OdometerBackup* const me, ARCSState * arcsState);

/*## statechart_method */
static void accessory_serializeStates(const OdometerBackup* const me, ARCSState * arcsState);
#endif /* _OMINSTRUMENT */

/*#[ ignore */
const RiCReactive_Vtbl OdometerBackup_reactiveVtbl = {
    rootState_dispatchEvent,
    rootState_entDef,
    ROOT_STATE_SERIALIZE_STATES(rootState_serializeStates),
    NULL
};

static const ARCSerCVtbl OdoBackup_pkg_OdometerBackup_instrumentVtbl = {
    serializeAttributes,
    serializeRelations
};
/*#]*/

#ifdef _OMINSTRUMENT
OM_INSTRUMENT_OBJECT_TYPE(OdometerBackup, OdoBackup_pkg, OdoBackup_pkg, FALSE, &OdoBackup_pkg_OdometerBackup_instrumentVtbl)
#endif /* _OMINSTRUMENT */

void OdometerBackup_Init(OdometerBackup* const me, RiCTaskEM * p_task) {
    /* Virtual tables Initialization */
    static const struct I_OdometerBackup_Vtbl OdometerBackup_I_OdometerBackup_Vtbl_Values = {
        offsetof(OdometerBackup, _I_OdometerBackup),
        (uint32_T (*)(void * const void_me))OdometerBackup_get_Odometer_Node,
        (void (*)(void * const void_me))OdometerBackup_set_HardReset,
        (void (*)(void * const void_me,ignition_status_T ignition))OdometerBackup_set_IgnitionStatus,
        (void (*)(void * const void_me,uint32_T new_odoMasterValue))OdometerBackup_set_OdometerMasterValue
    };
    I_OdometerBackup_Init(&me->_I_OdometerBackup, &OdometerBackup_I_OdometerBackup_Vtbl_Values);
    /* Violation of MISRA Rule 45 (Required): */
    /* 'Type casting to or from pointers shall not be used.' */
    /* The following cast into void* is justified */
    /* and is for Rhapsody auto-generated code use only. */
    /*LDRA_INSPECTED 94 S */
    /*LDRA_INSPECTED 95 S */ /*LDRA_INSPECTED 203 S */
    RiCReactive_init(&(me->ric_reactive), (void*)me, p_task, &OdometerBackup_reactiveVtbl, &mxfGlobals);
    NOTIFY_REACTIVE_CONSTRUCTOR(me, &me, NULL, OdometerBackup, OdometerBackup_Init, OdometerBackup_Init(), 0, OdoBackup_pkg_OdometerBackup_OdometerBackup_SERIALIZE);
    RiCReactive_setActive(&(me->ric_reactive), RiCFALSE);
    initStatechart(me);
    NOTIFY_END_CONSTRUCTOR(me);
}

void OdometerBackup_Cleanup(OdometerBackup* const me) {
    NOTIFY_DESTRUCTOR(me, &me, OdometerBackup, ~OdometerBackup);
    RiCReactive_cleanup(&(me->ric_reactive));
}

/*## operation Operation_21() */
void OdometerBackup_Operation_21(OdometerBackup* const me) {
    NOTIFY_OPERATION(me, &me, NULL, OdometerBackup, OdometerBackup_Operation_21, OdometerBackup_Operation_21(), 0, OdoBackup_pkg_OdometerBackup_Operation_21_SERIALIZE);
    /*#[ operation Operation_21() */
    /*#]*/
}

/*## operation gen(RiCEvent*,RiCBoolean) */
RiCBoolean OdometerBackup_gen(OdometerBackup* const me, RiCEvent* event, RiCBoolean fromISR) {
    /*#[ operation gen(RiCEvent*,RiCBoolean) */
    return RiCReactive_gen(&(me->ric_reactive), event, fromISR);
    /*#]*/
}

/*## operation get_Odometer_Node() */
uint32_T OdometerBackup_get_Odometer_Node(OdometerBackup* const me) {
    NOTIFY_OPERATION(me, &me, NULL, OdometerBackup, OdometerBackup_get_Odometer_Node, OdometerBackup_get_Odometer_Node(), 0, OdoBackup_pkg_OdometerBackup_get_Odometer_Node_SERIALIZE);
    {
        /*#[ operation get_Odometer_Node() */
        return ( me->odoBackupValue );
        /*#]*/
    }
}

/*#[ ignore */
void OdometerBackup_setOdoBackupValue(OdometerBackup* const me, unsigned int p_odoBackupValue) {
    if(me != NULL) {
        if(me->odoBackupValue != p_odoBackupValue) {
            me->odoBackupValue = p_odoBackupValue;
            if((me->odoBackupValue_trg != NULL) && (me->odoBackupValue_cb != NULL)) {
                DIRECT_FLOW_DATA_SEND(me, odoBackupValue, p_odoBackupValue, (*me->odoBackupValue_cb), me->odoBackupValue_trg, OdometerBackup, ARC_unsigned_int2String)
            }
        }
    }
}
/*#]*/

/*## operation set_HardReset() */
void OdometerBackup_set_HardReset(OdometerBackup* const me) {
    NOTIFY_OPERATION(me, &me, NULL, OdometerBackup, OdometerBackup_set_HardReset, OdometerBackup_set_HardReset(), 0, OdoBackup_pkg_OdometerBackup_set_HardReset_SERIALIZE);
    {
        /*#[ operation set_HardReset() */
        RiCGEN(me,evHardReset());
        /*#]*/
    }
}

/*## operation set_IgnitionStatus(ignition_status_T) */
void OdometerBackup_set_IgnitionStatus(OdometerBackup* const me, ignition_status_T ignition) {
    NOTIFY_OPERATION(me, &me, &ignition, OdometerBackup, OdometerBackup_set_IgnitionStatus, OdometerBackup_set_IgnitionStatus(ignition_status_T), 1, OdoBackup_pkg_OdometerBackup_set_IgnitionStatus_SERIALIZE);
    {
        /*#[ operation set_IgnitionStatus(ignition_status_T) */
        RiCGEN(me,evIgnitionStatus(ignition));
        /*#]*/
    }
}

/*## operation set_OdometerMasterValue(uint32_T) */
void OdometerBackup_set_OdometerMasterValue(OdometerBackup* const me, uint32_T new_odoMasterValue) {
    NOTIFY_OPERATION(me, &me, &new_odoMasterValue, OdometerBackup, OdometerBackup_set_OdometerMasterValue, OdometerBackup_set_OdometerMasterValue(uint32_T), 1, OdoBackup_pkg_OdometerBackup_set_OdometerMasterValue_SERIALIZE);
    {
        /*#[ operation set_OdometerMasterValue(uint32_T) */
        static uint32_T previous_odo;
        if ( new_odoMasterValue != previous_odo )
        {                           
        	previous_odo = new_odoMasterValue;
          	me->odoMasterValue = new_odoMasterValue;    
        	RiCGEN(me,evOdoMasterValue(new_odoMasterValue));
        }
        
        
        
    
        /*#]*/
    }
}

static void checkForTamper(OdometerBackup* const me) {
    NOTIFY_OPERATION(me, &me, NULL, OdometerBackup, checkForTamper, checkForTamper(), 0, OdoBackup_pkg_OdometerBackup_checkForTamper_SERIALIZE);
    {
        {
            /*#[ transition checkForTamper().5 */
            /*#]*/
            if ( !(me->odoMasterValue == DO_NOTHING_VALUE) )
            {
                /*#[ transition checkForTamper().1 */
                /*#]*/
                if ( me->odoMasterValue < ( me->odoBackupValue - MASTER_ODO_LT_THRESH ) ||
                me->odoMasterValue > ( me->odoBackupValue + MASTER_ODO_GT_THRESH )  )
                {
                        /*#[ state checkForTamper().ROOT.action_9.(Entry) */
                        me->tamper_flg = TRUE;
                        
                        /*#]*/
                }
                else
                {
                            /*#[ state checkForTamper().ROOT.action_4.(Entry) */
                            me->odoBackupValue = me->odoMasterValue;
                            
                            /*#]*/
                }
            }
            return;
        }
    
    }
}

static void checkInitialMileage(OdometerBackup* const me) {
    NOTIFY_OPERATION(me, &me, NULL, OdometerBackup, checkInitialMileage, checkInitialMileage(), 0, OdoBackup_pkg_OdometerBackup_checkInitialMileage_SERIALIZE);
    {
        {
            /*#[ transition checkInitialMileage().2 */
            /*#]*/
            if ( !(me->odoBackupValue > WAIT_FOR_MILEAGE) )
            {
                /*#[ transition checkInitialMileage().0 */
                /*#]*/
                if ( me->odoMasterValue > WAIT_FOR_MILEAGE )
                {
                        /*#[ state checkInitialMileage().ROOT.action_0.(Entry) */
                        me->odoBackupValue = me->odoMasterValue;
                        
                        I_EEPROM_Manager_ee_write_request
                          (me->itsI_EEPROM_Manager,EE_ODO_VALUE_NODE,me->odoBackupValue);
                        /*#]*/
                }
            }
            return;
        }
    
    }
}

void setOdoMasterValue(OdometerBackup* const me, uint32_T p_odoMasterValue) {
    me->odoMasterValue = p_odoMasterValue;
    NOTIFY_SET_OPERATION(me, OdometerBackup);
}

void setTamper_flg(OdometerBackup* const me, RiCBoolean p_tamper_flg) {
    me->tamper_flg = p_tamper_flg;
    NOTIFY_SET_OPERATION(me, OdometerBackup);
}

RiCBoolean OdometerBackup_startBehavior(OdometerBackup* const me) {
    RiCBoolean done = RiCFALSE;
    done = RiCReactive_startBehavior(&(me->ric_reactive), &mxfGlobals);
    return done;
}

static void initStatechart(OdometerBackup* const me) {
    me->rootState_subState = OdometerBackup_RiCNonState;
    me->rootState_active = OdometerBackup_RiCNonState;
    me->ignition_status_subState = OdometerBackup_RiCNonState;
    me->backup_enabled_subState = OdometerBackup_RiCNonState;
}

RiCTakeEventStatus OdometerBackup_backup_enabled_takeEvent(OdometerBackup* const me, RiCEventId id) {
    RiCTakeEventStatus res = eventNotConsumed;
    if(id == evIgnitionStatus_OdoBackup_pkg_id)
        {
            evIgnitionStatus_ev* params = evIgnitionStatus_getData((me)->ric_reactive.current_event);
            /*## transition 8 */
            if(params->ignitionStatus == OFF)
                {
                    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "7");
                    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "8");
                    switch (me->backup_enabled_subState) {
                        case OdometerBackup_backup_odometer:
                        {
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                        }
                        break;
                        case OdometerBackup_accessory:
                        {
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                        }
                        break;
                        default:
                            break;
                    }
                    me->backup_enabled_subState = OdometerBackup_RiCNonState;
                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled");
                    {
                        /*#[ transition 8 */
                        
                        I_EEPROM_Manager_ee_write_request
                            (me->itsI_EEPROM_Manager,EE_ODO_VALUE_NODE,me->odoBackupValue);
                        /*#]*/
                    }
                    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.pause");
                    me->ignition_status_subState = OdometerBackup_pause;
                    me->rootState_active = OdometerBackup_pause;
                    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "8");
                    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "7");
                    res = eventConsumed;
                }
            else
                {
                    /*## transition 9 */
                    if(params->ignitionStatus == UNKNOWN || params->ignitionStatus == INVALID)
                        {
                            NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "7");
                            NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "9");
                            switch (me->backup_enabled_subState) {
                                case OdometerBackup_backup_odometer:
                                {
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                                }
                                break;
                                case OdometerBackup_accessory:
                                {
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                                }
                                break;
                                default:
                                    break;
                            }
                            me->backup_enabled_subState = OdometerBackup_RiCNonState;
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled");
                            backup_enabled_entDef(me);
                            NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "9");
                            NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "7");
                            res = eventConsumed;
                        }
                }
        }
    if(res == eventNotConsumed)
        {
            switch (id) {
                case evHardReset_OdoBackup_pkg_id:
                {
                    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "6");
                    RiCReactive_popNullConfig(&(me->ric_reactive));
                    switch (me->ignition_status_subState) {
                        case OdometerBackup_pause:
                        {
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.pause");
                        }
                        break;
                        case OdometerBackup_backup_enabled:
                        {
                            switch (me->backup_enabled_subState) {
                                case OdometerBackup_backup_odometer:
                                {
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                                }
                                break;
                                case OdometerBackup_accessory:
                                {
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                                }
                                break;
                                default:
                                    break;
                            }
                            me->backup_enabled_subState = OdometerBackup_RiCNonState;
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled");
                        }
                        break;
                        default:
                            break;
                    }
                    me->ignition_status_subState = OdometerBackup_RiCNonState;
                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status");
                    {
                        /*#[ transition 6 */
                        
                        I_EEPROM_Manager_ee_write_request(me->itsI_EEPROM_Manager,
                        EE_ODO_VALUE_NODE,me->odoBackupValue);
                        /*#]*/
                    }
                    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.initialization");
                    RiCReactive_pushNullConfig(&(me->ric_reactive));
                    me->rootState_subState = OdometerBackup_initialization;
                    me->rootState_active = OdometerBackup_initialization;
                    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "6");
                    res = eventConsumed;
                }
                break;
                case Null_id:
                {
                    /*## transition 4 */
                    if(me->tamper_flg == TRUE)
                        {
                            NOTIFY_NULL_TRANSITION_STARTED(me, OdometerBackup, "4");
                            RiCReactive_popNullConfig(&(me->ric_reactive));
                            switch (me->ignition_status_subState) {
                                case OdometerBackup_pause:
                                {
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.pause");
                                }
                                break;
                                case OdometerBackup_backup_enabled:
                                {
                                    switch (me->backup_enabled_subState) {
                                        case OdometerBackup_backup_odometer:
                                        {
                                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                                        }
                                        break;
                                        case OdometerBackup_accessory:
                                        {
                                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                                        }
                                        break;
                                        default:
                                            break;
                                    }
                                    me->backup_enabled_subState = OdometerBackup_RiCNonState;
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled");
                                }
                                break;
                                default:
                                    break;
                            }
                            me->ignition_status_subState = OdometerBackup_RiCNonState;
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status");
                            {
                                /*#[ transition 4 */
                                
                                I_EEPROM_Manager_ee_write_request(me->itsI_EEPROM_Manager,EE_ODO_VALUE_NODE,me->odoBackupValue);
                                /*#]*/
                            }
                            NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status");
                            RiCReactive_pushNullConfig(&(me->ric_reactive));
                            me->rootState_subState = OdometerBackup_ignition_status;
                            NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.pause");
                            me->ignition_status_subState = OdometerBackup_pause;
                            me->rootState_active = OdometerBackup_pause;
                            NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "4");
                            res = eventConsumed;
                        }
                }
                break;
                default:
                    break;
            }
        }
    return res;
}

RiCTakeEventStatus OdometerBackup_backup_odometer_takeEvent(OdometerBackup* const me, RiCEventId id) {
    RiCTakeEventStatus res = eventNotConsumed;
    switch (id) {
        case evIgnitionStatus_OdoBackup_pkg_id:
        {
            evIgnitionStatus_ev* params = evIgnitionStatus_getData((me)->ric_reactive.current_event);
            /*## transition ROOT.ignition_status.backup_enabled.1 */
            if(params->ignitionStatus==ACCESSORY )
                {
                    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.1");
                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                    me->backup_enabled_subState = OdometerBackup_accessory;
                    me->rootState_active = OdometerBackup_accessory;
                    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.1");
                    res = eventConsumed;
                }
        }
        break;
        case evOdoMasterValue_OdoBackup_pkg_id:
        {
            evOdoMasterValue_ev* params = evOdoMasterValue_getData((me)->ric_reactive.current_event);
            NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.0");
            {
                /*#[ transition ROOT.ignition_status.backup_enabled.0 */
                checkForTamper(me);
                /*#]*/
            }
            NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.0");
            res = eventConsumed;
        }
        break;
        default:
            break;
    }
    if(res == eventNotConsumed)
        {
            res = OdometerBackup_backup_enabled_takeEvent(me, id);
        }
    return res;
}

RiCTakeEventStatus OdometerBackup_accessory_takeEvent(OdometerBackup* const me, RiCEventId id) {
    RiCTakeEventStatus res = eventNotConsumed;
    if(id == evIgnitionStatus_OdoBackup_pkg_id)
        {
            evIgnitionStatus_ev* params = evIgnitionStatus_getData((me)->ric_reactive.current_event);
            /*## transition ROOT.ignition_status.backup_enabled.2 */
            if(params->ignitionStatus == RUN || params->ignitionStatus == START )
                {
                    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.2");
                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                    me->backup_enabled_subState = OdometerBackup_backup_odometer;
                    me->rootState_active = OdometerBackup_backup_odometer;
                    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.2");
                    res = eventConsumed;
                }
        }
    if(res == eventNotConsumed)
        {
            res = OdometerBackup_backup_enabled_takeEvent(me, id);
        }
    return res;
}

#ifdef _OMINSTRUMENT
static void serializeAttributes(const void * const void_me, ARCSAttributes * arcsAttributes) {
    
    const OdometerBackup * const me = (const OdometerBackup *)void_me;
    ARCSA_addAttribute_c(arcsAttributes, "tamper_flg", ARC_RiCBoolean2String(me->tamper_flg));
    ARCSA_addAttribute_c(arcsAttributes, "odoMasterValue", ARC_unsigned_int2String(me->odoMasterValue));
    ARCSA_addAttribute_c(arcsAttributes, "odoBackupValue", ARC_unsigned_int2String(me->odoBackupValue));
    ARCSA_addAttribute_c(arcsAttributes, "odoBackupValue_trg", ARC_ptr2String(me->odoBackupValue_trg));
    ARCSA_addAttribute_c(arcsAttributes, "odoBackupValue_cb", ARC_UNKNOWN2STRING(me->odoBackupValue_cb));
}

static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations) {
}

static void rootState_serializeStates(const void * const void_me, ARCSState * arcsState) {
    
    const OdometerBackup * const me = (const OdometerBackup *)void_me;
    ARCSS_addState_OMH(arcsState, "ROOT");
    switch (me->rootState_subState) {
        case OdometerBackup_initialization:
        {
            initialization_serializeStates(me, arcsState);
        }
        break;
        case OdometerBackup_ignition_status:
        {
            ignition_status_serializeStates(me, arcsState);
        }
        break;
        default:
            break;
    }
}
#endif /* _OMINSTRUMENT */

static void rootState_entDef(void * const void_me) {
    
    OdometerBackup * const me = (OdometerBackup *)void_me;
    {
        NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT");
        NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "0");
        NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.initialization");
        RiCReactive_pushNullConfig(&(me->ric_reactive));
        me->rootState_subState = OdometerBackup_initialization;
        me->rootState_active = OdometerBackup_initialization;
        NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "0");
    }
}

static RiCTakeEventStatus rootState_dispatchEvent(void * const void_me, RiCEventId id) {
    
    OdometerBackup * const me = (OdometerBackup *)void_me;
    RiCTakeEventStatus res = eventNotConsumed;
    switch (me->rootState_active) {
        /* Wait until WAIT_FOR_MILEAGE before performing backup logic. */
        case OdometerBackup_initialization:
        {
            switch (id) {
                case Null_id:
                {
                    /*## transition 1 */
                    if(me->odoBackupValue > WAIT_FOR_MILEAGE)
                        {
                            NOTIFY_NULL_TRANSITION_STARTED(me, OdometerBackup, "1");
                            RiCReactive_popNullConfig(&(me->ric_reactive));
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.initialization");
                            ignition_status_entDef(me);
                            NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "1");
                            res = eventConsumed;
                        }
                }
                break;
                case evOdoMasterValue_OdoBackup_pkg_id:
                {
                    evOdoMasterValue_ev* params = evOdoMasterValue_getData((me)->ric_reactive.current_event);
                    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "5");
                    {
                        /*#[ transition 5 */
                        checkInitialMileage(me); /* internal transition */
                        /*#]*/
                    }
                    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "5");
                    res = eventConsumed;
                }
                break;
                default:
                    break;
            }
        }
        break;
        case OdometerBackup_pause:
        {
            if(id == evOdoMasterValue_OdoBackup_pkg_id)
                {
                    evOdoMasterValue_ev* params = evOdoMasterValue_getData((me)->ric_reactive.current_event);
                    /*## transition 3 */
                    if(me->tamper_flg == FALSE)
                        {
                            NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "3");
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.pause");
                            {
                                /*#[ transition 3 */
                                
                                me->odoMasterValue = params->new_odo_value; 
                                me->odoBackupValue = 
                                    I_EEPROM_Manager_ee_read_request(me->itsI_EEPROM_Manager,EE_ODO_VALUE_NODE);
                                /*#]*/
                            }
                            backup_enabled_entDef(me);
                            NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "3");
                            res = eventConsumed;
                        }
                }
            if(res == eventNotConsumed)
                {
                    switch (id) {
                        case evHardReset_OdoBackup_pkg_id:
                        {
                            NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "6");
                            RiCReactive_popNullConfig(&(me->ric_reactive));
                            switch (me->ignition_status_subState) {
                                case OdometerBackup_pause:
                                {
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.pause");
                                }
                                break;
                                case OdometerBackup_backup_enabled:
                                {
                                    switch (me->backup_enabled_subState) {
                                        case OdometerBackup_backup_odometer:
                                        {
                                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                                        }
                                        break;
                                        case OdometerBackup_accessory:
                                        {
                                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                                        }
                                        break;
                                        default:
                                            break;
                                    }
                                    me->backup_enabled_subState = OdometerBackup_RiCNonState;
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled");
                                }
                                break;
                                default:
                                    break;
                            }
                            me->ignition_status_subState = OdometerBackup_RiCNonState;
                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status");
                            {
                                /*#[ transition 6 */
                                
                                I_EEPROM_Manager_ee_write_request(me->itsI_EEPROM_Manager,
                                EE_ODO_VALUE_NODE,me->odoBackupValue);
                                /*#]*/
                            }
                            NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.initialization");
                            RiCReactive_pushNullConfig(&(me->ric_reactive));
                            me->rootState_subState = OdometerBackup_initialization;
                            me->rootState_active = OdometerBackup_initialization;
                            NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "6");
                            res = eventConsumed;
                        }
                        break;
                        case Null_id:
                        {
                            /*## transition 4 */
                            if(me->tamper_flg == TRUE)
                                {
                                    NOTIFY_NULL_TRANSITION_STARTED(me, OdometerBackup, "4");
                                    RiCReactive_popNullConfig(&(me->ric_reactive));
                                    switch (me->ignition_status_subState) {
                                        case OdometerBackup_pause:
                                        {
                                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.pause");
                                        }
                                        break;
                                        case OdometerBackup_backup_enabled:
                                        {
                                            switch (me->backup_enabled_subState) {
                                                case OdometerBackup_backup_odometer:
                                                {
                                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
                                                }
                                                break;
                                                case OdometerBackup_accessory:
                                                {
                                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
                                                }
                                                break;
                                                default:
                                                    break;
                                            }
                                            me->backup_enabled_subState = OdometerBackup_RiCNonState;
                                            NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled");
                                        }
                                        break;
                                        default:
                                            break;
                                    }
                                    me->ignition_status_subState = OdometerBackup_RiCNonState;
                                    NOTIFY_STATE_EXITED(me, OdometerBackup, "ROOT.ignition_status");
                                    {
                                        /*#[ transition 4 */
                                        
                                        I_EEPROM_Manager_ee_write_request(me->itsI_EEPROM_Manager,EE_ODO_VALUE_NODE,me->odoBackupValue);
                                        /*#]*/
                                    }
                                    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status");
                                    RiCReactive_pushNullConfig(&(me->ric_reactive));
                                    me->rootState_subState = OdometerBackup_ignition_status;
                                    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.pause");
                                    me->ignition_status_subState = OdometerBackup_pause;
                                    me->rootState_active = OdometerBackup_pause;
                                    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "4");
                                    res = eventConsumed;
                                }
                        }
                        break;
                        default:
                            break;
                    }
                }
        }
        break;
        case OdometerBackup_backup_odometer:
        {
            res = OdometerBackup_backup_odometer_takeEvent(me, id);
        }
        break;
        case OdometerBackup_accessory:
        {
            res = OdometerBackup_accessory_takeEvent(me, id);
        }
        break;
        default:
            break;
    }
    return res;
}

#ifdef _OMINSTRUMENT
static void initialization_serializeStates(const OdometerBackup* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.initialization");
}

static void ignition_status_serializeStates(const OdometerBackup* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.ignition_status");
    switch (me->ignition_status_subState) {
        case OdometerBackup_pause:
        {
            pause_serializeStates(me, arcsState);
        }
        break;
        case OdometerBackup_backup_enabled:
        {
            backup_enabled_serializeStates(me, arcsState);
        }
        break;
        default:
            break;
    }
}
#endif /* _OMINSTRUMENT */

static void ignition_status_entDef(OdometerBackup* const me) {
    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status");
    RiCReactive_pushNullConfig(&(me->ric_reactive));
    me->rootState_subState = OdometerBackup_ignition_status;
    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "2");
    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.pause");
    me->ignition_status_subState = OdometerBackup_pause;
    me->rootState_active = OdometerBackup_pause;
    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "2");
}

#ifdef _OMINSTRUMENT
static void pause_serializeStates(const OdometerBackup* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.ignition_status.pause");
}

static void backup_enabled_serializeStates(const OdometerBackup* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.ignition_status.backup_enabled");
    switch (me->backup_enabled_subState) {
        case OdometerBackup_backup_odometer:
        {
            backup_odometer_serializeStates(me, arcsState);
        }
        break;
        case OdometerBackup_accessory:
        {
            accessory_serializeStates(me, arcsState);
        }
        break;
        default:
            break;
    }
}
#endif /* _OMINSTRUMENT */

static void backup_enabled_entDef(OdometerBackup* const me) {
    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled");
    me->ignition_status_subState = OdometerBackup_backup_enabled;
    NOTIFY_TRANSITION_STARTED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.3");
    NOTIFY_STATE_ENTERED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
    me->backup_enabled_subState = OdometerBackup_backup_odometer;
    me->rootState_active = OdometerBackup_backup_odometer;
    NOTIFY_TRANSITION_TERMINATED(me, OdometerBackup, "ROOT.ignition_status.backup_enabled.3");
}

#ifdef _OMINSTRUMENT
static void backup_odometer_serializeStates(const OdometerBackup* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.backup_odometer");
}

static void accessory_serializeStates(const OdometerBackup* const me, ARCSState * arcsState) {
    ARCSS_addState_OMH(arcsState, "ROOT.ignition_status.backup_enabled.ROOT.backup_enabled.accessory");
}
#endif /* _OMINSTRUMENT */

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\OdometerBackup.c
*********************************************************************/
