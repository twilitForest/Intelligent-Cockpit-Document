/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Simulation_cfg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MainDesktopAnimation_cmp.h
*********************************************************************/

#ifndef MainDesktopAnimation_cmp_H
#define MainDesktopAnimation_cmp_H

/*## auto_generated */
#include "mxf\Ric.h"
void DesktopAnimation_cmp_Init(void);

void DesktopAnimation_cmp_Cleanup(void);

#endif
/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\MainDesktopAnimation_cmp.h
*********************************************************************/
