/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Types_pkg
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Types_pkg.c
*********************************************************************/

/*## auto_generated */
#include "Types_pkg.h"
/*## package Types_pkg */


#ifdef _OMINSTRUMENT
/*#[ ignore */
static const ARCSerGVtbl Types_pkg_instrumentVtbl = {
    NULL,
    NULL
};
/*#]*/

OM_INSTRUMENT_PACKAGE(Types_pkg, Types_pkg, &Types_pkg_instrumentVtbl)
#endif /* _OMINSTRUMENT */

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Types_pkg.c
*********************************************************************/
