/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: I_NPs
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_NPs.c
*********************************************************************/

/*## auto_generated */
#include "I_NPs.h"
/*#[ ignore */
#define OdoBackup_pkg_I_NPs_SERIALIZE OM_NO_OP

#define OdoBackup_pkg_Set_OdometerBackUpNODE_SERIALIZE ARCSA_addAttribute_c(arcsmethod, "odoBackupValue", ARC_UNKNOWN2STRING(odoBackupValue));
/*#]*/

/*## package OdoBackup_pkg */

/*## class TopLevel::I_NPs */
/*## classInstance I_NPs.I_NPs */
struct I_NPs_t I_NPs;

#ifdef _OMINSTRUMENT
/*#[ ignore */
static const ARCSerCVtbl I_NPs_instrumentVtbl = {
    NULL,
    NULL
};
/*#]*/

OM_INSTRUMENT_FILE_OBJECT(I_NPs, I_NPs, OdoBackup_pkg, OdoBackup_pkg, FALSE, &I_NPs_instrumentVtbl)
#endif /* _OMINSTRUMENT */

void I_NPs_Init(void) {
    NOTIFY_CONSTRUCTOR(&I_NPs, NULL, NULL, I_NPs, I_NPs_Init, I_NPs_Init(), 0, OdoBackup_pkg_I_NPs_SERIALIZE);
    NOTIFY_END_CONSTRUCTOR(&I_NPs);
}

void I_NPs_Cleanup(void) {
    NOTIFY_DESTRUCTOR(&I_NPs, NULL, I_NPs, ~I_NPs);
}

/*## operation Set_OdometerBackUpNODE(uint32_T) */
void Set_OdometerBackUpNODE(uint32_T odoBackupValue) {
    NOTIFY_OPERATION(&I_NPs, &odoBackupValue, &odoBackupValue, I_NPs, Set_OdometerBackUpNODE, Set_OdometerBackUpNODE(), 1, OdoBackup_pkg_Set_OdometerBackUpNODE_SERIALIZE);
    /*#[ operation Set_OdometerBackUpNODE(uint32_T) */
    /*#]*/
}

void I_NPs_initRelations(void) {
    I_NPs_Init();
    
    #ifdef _OMINSTRUMENT
    ARCAI_SetName(&(I_NPs), I_NPs, "I_NPs", ARCNoMultiplicity);
    #endif /* _OMINSTRUMENT*/
}

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\I_NPs.c
*********************************************************************/
