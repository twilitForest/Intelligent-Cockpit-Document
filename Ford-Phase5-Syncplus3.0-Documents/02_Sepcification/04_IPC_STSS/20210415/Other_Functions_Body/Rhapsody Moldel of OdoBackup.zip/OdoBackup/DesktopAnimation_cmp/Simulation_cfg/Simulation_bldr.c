/*********************************************************************
	Rhapsody in C	: 8.0 
	Login		: JMILOSER
	Component	: DesktopAnimation_cmp 
	Configuration 	: Simulation_cfg
	Model Element	: Simulation_bldr
//!	Generated Date	: Mon, 18, Feb 2013  
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_bldr.c
*********************************************************************/

/*## auto_generated */
#include "Simulation_bldr.h"
/*#[ ignore */
#define Simulation_pkg_Simulation_bldr_Simulation_bldr_SERIALIZE OM_NO_OP
/*#]*/

/*## package Simulation_pkg */

/*## class TopLevel::Simulation_bldr */
/*## auto_generated */
static void initRelations(struct Simulation_bldr_t* const me);

/*## auto_generated */
static void cleanUpRelations(struct Simulation_bldr_t* const me);

#ifdef _OMINSTRUMENT
static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations);
#endif /* _OMINSTRUMENT */

/*#[ ignore */
const RiCReactive_Vtbl Simulation_bldr_reactiveVtbl = {
    NULL,
    NULL,
    NULL,
    NULL
};

static const ARCSerCVtbl Simulation_bldr_instrumentVtbl = {
    NULL,
    serializeRelations
};
/*#]*/

#ifdef _OMINSTRUMENT
OM_INSTRUMENT_OBJECT(Simulation_bldr, Simulation_pkg, Simulation_pkg, FALSE, &Simulation_bldr_instrumentVtbl)
#endif /* _OMINSTRUMENT */

void Simulation_bldr_Init(struct Simulation_bldr_t* const me, RiCTaskEM * p_task) {
    /* Violation of MISRA Rule 45 (Required): */
    /* 'Type casting to or from pointers shall not be used.' */
    /* The following cast into void* is justified */
    /* and is for Rhapsody auto-generated code use only. */
    /*LDRA_INSPECTED 94 S */
    /*LDRA_INSPECTED 95 S */ /*LDRA_INSPECTED 203 S */
    RiCReactive_init(&(me->ric_reactive), (void*)me, p_task, &Simulation_bldr_reactiveVtbl, &mxfGlobals);
    NOTIFY_REACTIVE_CONSTRUCTOR(me, &me, NULL, Simulation_bldr, Simulation_bldr_Init, Simulation_bldr_Init(), 0, Simulation_pkg_Simulation_bldr_Simulation_bldr_SERIALIZE);
    RiCReactive_setActive(&(me->ric_reactive), RiCFALSE);
    initRelations(me);
    NOTIFY_END_CONSTRUCTOR(me);
}

void Simulation_bldr_Cleanup(struct Simulation_bldr_t* const me) {
    NOTIFY_DESTRUCTOR(me, &me, Simulation_bldr, ~Simulation_bldr);
    RiCReactive_cleanup(&(me->ric_reactive));
    cleanUpRelations(me);
}

struct BackupOdometer_t* Simulation_bldr_getItsBackupOdometer(const struct Simulation_bldr_t* const me) {
    return (struct BackupOdometer_t*)&(me->itsBackupOdometer);
}

struct Battery_t* Simulation_bldr_getItsBattery(const struct Simulation_bldr_t* const me) {
    return (struct Battery_t*)&(me->itsBattery);
}

struct IgnitionStatus_t* Simulation_bldr_getItsIgnitionStatus(const struct Simulation_bldr_t* const me) {
    return (struct IgnitionStatus_t*)&(me->itsIgnitionStatus);
}

struct MasterOdometer_t* Simulation_bldr_getItsMasterOdometer(const struct Simulation_bldr_t* const me) {
    return (struct MasterOdometer_t*)&(me->itsMasterOdometer);
}

struct OdometerBackup_t* Simulation_bldr_getItsOdometerBackup(const struct Simulation_bldr_t* const me) {
    return (struct OdometerBackup_t*)&(me->itsOdometerBackup);
}

RiCBoolean Simulation_bldr_startBehavior(struct Simulation_bldr_t* const me) {
    RiCBoolean done = RiCTRUE;
    done &= BackupOdometer_startBehavior(&(me->itsBackupOdometer));
    done &= Battery_startBehavior(&(me->itsBattery));
    done &= IgnitionStatus_startBehavior(&(me->itsIgnitionStatus));
    done &= MasterOdometer_startBehavior(&(me->itsMasterOdometer));
    done &= OdometerBackup_startBehavior(&(me->itsOdometerBackup));
    done = RiCReactive_startBehavior(&(me->ric_reactive), &mxfGlobals);
    return done;
}

static void initRelations(struct Simulation_bldr_t* const me) {
    BackupOdometer_Init(&(me->itsBackupOdometer), me->ric_reactive.myTask);
    Battery_Init(&(me->itsBattery), me->ric_reactive.myTask);
    IgnitionStatus_Init(&(me->itsIgnitionStatus), me->ric_reactive.myTask);
    MasterOdometer_Init(&(me->itsMasterOdometer), me->ric_reactive.myTask);
    OdometerBackup_Init(&(me->itsOdometerBackup), me->ric_reactive.myTask);
    #ifdef _OMINSTRUMENT
    MasterOdometer_updateRelations(&(me->itsMasterOdometer));
    IgnitionStatus_updateRelations(&(me->itsIgnitionStatus));
    Battery_updateRelations(&(me->itsBattery));
    BackupOdometer_updateRelations(&(me->itsBackupOdometer));
    #endif
}

static void cleanUpRelations(struct Simulation_bldr_t* const me) {
    OdometerBackup_Cleanup(&(me->itsOdometerBackup));
    MasterOdometer_Cleanup(&(me->itsMasterOdometer));
    IgnitionStatus_Cleanup(&(me->itsIgnitionStatus));
    Battery_Cleanup(&(me->itsBattery));
    BackupOdometer_Cleanup(&(me->itsBackupOdometer));
}

#ifdef _OMINSTRUMENT
static void serializeRelations(const void * const void_me, ARCSRelations * arcsRelations) {
    
    const struct Simulation_bldr_t * const me = (const struct Simulation_bldr_t *)void_me;
    ARCSRS_addRelation(arcsRelations, "itsOdometerBackup", TRUE, TRUE);
    ARCSRS_addItem(arcsRelations, OdometerBackup, &(me->itsOdometerBackup));
    ARCSRS_addRelation(arcsRelations, "itsMasterOdometer", TRUE, TRUE);
    ARCSRS_addItem(arcsRelations, MasterOdometer, &(me->itsMasterOdometer));
    ARCSRS_addRelation(arcsRelations, "itsIgnitionStatus", TRUE, TRUE);
    ARCSRS_addItem(arcsRelations, IgnitionStatus, &(me->itsIgnitionStatus));
    ARCSRS_addRelation(arcsRelations, "itsBattery", TRUE, TRUE);
    ARCSRS_addItem(arcsRelations, Battery, &(me->itsBattery));
    ARCSRS_addRelation(arcsRelations, "itsBackupOdometer", TRUE, TRUE);
    ARCSRS_addItem(arcsRelations, BackupOdometer, &(me->itsBackupOdometer));
}
#endif /* _OMINSTRUMENT */

/*********************************************************************
	File Path	: DesktopAnimation_cmp\Simulation_cfg\Simulation_bldr.c
*********************************************************************/
