package com.example.android.xxxservicedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;

import com.ford.sync.voicecontrolbridge.tts.ITtsListener;
import com.ford.sync.voicecontrolbridge.tts.TtsClientManager;
import com.ford.sync.voicecontrolbridge.tts.TtsOption;
import com.ford.sync.voicecontrolbridge.vts.IVtsListener;
import com.ford.sync.voicecontrolbridge.vts.VtsClientManager;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private TtsClientManager mTtsClientManager;
    private VtsClientManager mVtsClientManager;
    //private VcbNotificationManager mVcbNotificationManager;

    private IVtsListener.Stub vtsListener = new IVtsListener.Stub() {
        @Override
        public void onBack() {
            Log.d(TAG, "onBack: ");
        }

        @Override
        public void onBuyMember() {
            Log.d(TAG, "onBuyMember: ");
        }

        @Override
        public void onCancel() {
            Log.d(TAG, "onCancel: ");
        }

        @Override
        public void onChangeSelect(String select) {
            Log.d(TAG, "onChangeSelect: ");
        }

        @Override
        public void onCheckOrder(String type) {
            Log.d(TAG, "onCheckOrder: ");
        }

        @Override
        public void onClearCache() {
            Log.d(TAG, "onClearCache: ");
        }

        @Override
        public void onConfirm() {
            Log.d(TAG, "onConfirm: ");
        }

        @Override
        public void onDefault() {
            Log.d(TAG, "onDefault: ");
        }

        @Override
        public void onDelete(int index, String name) {
            Log.d(TAG, "onDelete: ");
        }

        @Override
        public void onExpand() {
            Log.d(TAG, "onExpand: ");
        }

        @Override
        public void onFavorite(String type, int index, String name) {
            Log.d(TAG, "onFavorite: ");
        }

        @Override
        public void onFilter(String content) {
            Log.d(TAG, "onFilter: ");
        }

        @Override
        public void onInput(String content, String type, String time) {
            Log.d(TAG, "onInput: ");
        }

        @Override
        public void onLogin() {
            Log.d(TAG, "onLogin: ");
        }

        @Override
        public void onNavigation(String content, int index) {
            Log.d(TAG, "onNavigation: ");
        }

        @Override
        public void onPager(String event, int value) {
            Log.d(TAG, "onPager: ");
        }

        @Override
        public void onPay() {
            Log.d(TAG, "onPay: ");
        }

        @Override
        public void onPhoneCall(int index, String name) {
            Log.d(TAG, "onPhoneCall: ");
        }

        @Override
        public void onRanker(String type, String range) {
            Log.d(TAG, "onRanker: ");
        }

        @Override
        public void onScroll(String direction, String event, int value) {
            Log.d(TAG, "onScroll: ");
        }

        @Override
        public void onSearch(String content) {
            Log.d(TAG, "onSearch: ");
        }

        @Override
        public void onSelect(String name, int index) throws RemoteException {
            Log.d(TAG, "onSelect: name = " + name + " index = " + index);
        }

        @Override
        public void onTabSelect(String name, int index) {
            Log.d(TAG, "onTabSelect: ");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.startService(new Intent(this, XxxService.class));
        mTtsClientManager = new TtsClientManager(this);
        mVtsClientManager = new VtsClientManager(this);
        //mVcbNotificationManager = new VcbNotificationManager(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //删除VTS监听器，防止别人注册的VTS能力触发后发送给自己消息
        mVtsClientManager.deleteVtsListener(vtsListener);
        //关闭VTS能力
        mVtsClientManager.disableVtsCapability();
    }

    public void startTTS(View view) {
        Log.d(TAG, "startTts: ");
        TtsOption ttsOption = new TtsOption();
        ttsOption.setBackground(false);
        mTtsClientManager.startTts("今天天气不错,挺风和日丽的", ttsOption /*,new ITtsListener.Stub() {
            @Override
            public void onSpeechStart() throws RemoteException {
                Log.d(TAG, "onSpeechStart: ");
            }

            @Override
            public void onSpeechFinished() throws RemoteException {
                Log.d(TAG, "onSpeechFinished: ");
            }

            @Override
            public void onSpeechInterrupted() throws RemoteException {
                Log.d(TAG, "onSpeechInterrupted: ");
            }

            @Override
            public void onSpeechError(int errorCode) throws RemoteException {
                Log.d(TAG, "onSpeechError: ");
            }
        }*/);
    }

    public void stopTTS(View view) {
        Log.d(TAG, "stopTts: ");
        mTtsClientManager.stopTts();
    }

    public void testVTS(View view) {
        Log.d(TAG, "testVTS: ");
        //注册VTS能力
        mVtsClientManager.registerSelect("确定", 1);
        mVtsClientManager.registerSelect("取消", 2);
        mVtsClientManager.registerSelect("返回", 3);
        //增加回调监听
        mVtsClientManager.addVtsListener(vtsListener);
        //VTS使能,使能之后，唤醒语音助手，喊注册的词，从监听器中接收回调
        mVtsClientManager.enableVtsCapability();
    }


}