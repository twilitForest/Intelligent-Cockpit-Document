package com.example.android.xxxservicedemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import com.ford.sync.voicecontrolbridge.vcb.IBridge;
import com.ford.sync.voicecontrolbridge.vcb.IBridgeListener;
import com.ford.sync.voicecontrolbridge.vcb.VcbNotificationManager;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class XxxService extends Service {
    private static final String TAG = "XxxService";

    //vcbNotificationManager 用于主动通知VCS事件
    private VcbNotificationManager mVcbNotificationManager;

    //mBridgeListeners 用于保存客户端注册的监听器，用于异步返回给客户端操作结果
    private final Set<IBridgeListener> mBridgeListeners = new HashSet<>();

    // 实现aidl stub
    private final IBridge.Stub mBind = new IBridge.Stub() {
        @Override
        public String sendRequest(String uuid, String msg) throws RemoteException {
            //接收VCS发来的json指令。
            // 可以同步返回结果: 组装成json返回；
            // 不能同步处理结果: 返回null, 然后通过listener通知处理结果；
            xxxFunction(uuid);
            return null;
        }

        @Override
        public void registerBridgeListener(IBridgeListener bridgeListener) throws RemoteException {
            mBridgeListeners.add(bridgeListener);
        }
    };

    private void xxxFunction(final String uuid) throws RemoteException {
        //处理数据，调用接口，返回结果或通过listener回调给VCS
        String callbackMsg = "";

        for (IBridgeListener listener : mBridgeListeners) {
            if (null != listener) {
                // 操作成功调用 onResponse
                listener.onResponse(uuid, callbackMsg);
            }
        }
        // 这里如果需要播报TTS，或其他事件通知到VCS，调用下面方法
        String notifyUuid = UUID.randomUUID().toString();
        String notifyEvent = ""; //组装好的json字符串，格式待定义
        if (null != mVcbNotificationManager) {
            mVcbNotificationManager.notifyEvent(notifyUuid, notifyEvent);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mVcbNotificationManager = new VcbNotificationManager(this);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBind;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}