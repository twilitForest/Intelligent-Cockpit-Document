package com.example.android.xxxservicedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.ford.sync.voicecontrolbridge.notification.VcbNotificationManager;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private VcbNotificationManager mVcbNotificationManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mVcbNotificationManager = new VcbNotificationManager(this);
    }

    /**
     * notify message to vcs.
     *
     * @param view view
     */
    public void notify(View view) {
        Log.d(TAG, "notify: ");
        String uuid = UUID.randomUUID().toString();
        String event = "test service notification event";
        mVcbNotificationManager.notifyEvent(uuid, event);
    }

}