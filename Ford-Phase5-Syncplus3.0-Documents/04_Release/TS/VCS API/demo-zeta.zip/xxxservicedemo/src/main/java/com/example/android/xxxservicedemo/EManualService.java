package com.example.android.xxxservicedemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.ford.sync.voicecontrolbridge.vcb.IBridge;
import com.ford.sync.voicecontrolbridge.vcb.IBridgeListener;

import java.util.HashSet;
import java.util.Set;

public class EManualService extends Service {
    private static final String TAG = "EManualService";

    //mBridgeListeners 用于保存客户端注册的监听器，用于异步返回给客户端操作结果
    private final Set<IBridgeListener> mBridgeListeners = new HashSet<>();

    // 实现aidl stub
    private final IBridge.Stub mBind = new IBridge.Stub() {
        @Override
        public String sendRequest(String uuid, String msg) throws RemoteException {
            Log.d(TAG, "sendRequest: uuid = " + uuid + " msg = " + msg);
            return null;
        }

        @Override
        public void registerBridgeListener(IBridgeListener bridgeListener) throws RemoteException {
            Log.d(TAG, "registerBridgeListener: bridgeListener = " + bridgeListener);
            mBridgeListeners.add(bridgeListener);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBind;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
