package com.example.android.xxxservicedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;

import com.ford.sync.voicecontrolbridge.tts.ITtsListener;
import com.ford.sync.voicecontrolbridge.tts.TtsClientManager;
import com.ford.sync.voicecontrolbridge.tts.TtsOption;
import com.ford.sync.voicecontrolbridge.vts.IVtsListener;
import com.ford.sync.voicecontrolbridge.vts.VtsClientManager;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private TtsClientManager mTtsClientManager;
    private VtsClientManager mVtsClientManager;
    //private VcbNotificationManager mVcbNotificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.startService(new Intent(this, XxxService.class));
        mTtsClientManager = new TtsClientManager(this);
        mVtsClientManager = new VtsClientManager(this);
        //mVcbNotificationManager = new VcbNotificationManager(this);
    }


    public void testTTS(View view) {
        Log.d(TAG, "testTTS: ");
        TtsOption ttsOption = new TtsOption();
        ttsOption.setBackground(false);
        mTtsClientManager.startTts("今天天气不错", ttsOption /*,new ITtsListener.Stub() {
            @Override
            public void onSpeechStart() throws RemoteException {
                Log.d(TAG, "onSpeechStart: ");
            }

            @Override
            public void onSpeechFinished() throws RemoteException {
                Log.d(TAG, "onSpeechFinished: ");
            }

            @Override
            public void onSpeechInterrupted() throws RemoteException {
                Log.d(TAG, "onSpeechInterrupted: ");
            }

            @Override
            public void onSpeechError(int errorCode) throws RemoteException {
                Log.d(TAG, "onSpeechError: ");
            }
        }*/);
    }

    public void testVTS(View view) {
        Log.d(TAG, "testVTS: ");
        mVtsClientManager.addVtsListener(new IVtsListener.Stub() {
            @Override
            public void onBack() throws RemoteException {

            }

            @Override
            public void onBuyMember() throws RemoteException {

            }

            @Override
            public void onCancel() throws RemoteException {

            }

            @Override
            public void onChangeSelect(String select) throws RemoteException {

            }

            @Override
            public void onCheckOrder(String type) throws RemoteException {

            }

            @Override
            public void onClearCache() throws RemoteException {

            }

            @Override
            public void onConfirm() throws RemoteException {

            }

            @Override
            public void onDefault() throws RemoteException {

            }

            @Override
            public void onDelete(int index, String name) throws RemoteException {

            }

            @Override
            public void onExpand() throws RemoteException {

            }

            @Override
            public void onFavorite(String type, int index, String name) throws RemoteException {

            }

            @Override
            public void onFilter(String content) throws RemoteException {

            }

            @Override
            public void onInput(String content, String type, String time) throws RemoteException {

            }

            @Override
            public void onLogin() throws RemoteException {

            }

            @Override
            public void onNavigation(String content, int index) throws RemoteException {

            }

            @Override
            public void onPager(String event, int value) throws RemoteException {

            }

            @Override
            public void onPay() throws RemoteException {

            }

            @Override
            public void onPhoneCall(int index, String name) throws RemoteException {

            }

            @Override
            public void onRanker(String type, String range) throws RemoteException {

            }

            @Override
            public void onScroll(String direction, String event, int value) throws RemoteException {

            }

            @Override
            public void onSearch(String content) throws RemoteException {

            }

            @Override
            public void onSelect(String name, int index) throws RemoteException {

            }

            @Override
            public void onTabSelect(String name, int index) throws RemoteException {

            }
        });
        mVtsClientManager.registerSelect("确认", 1);
        mVtsClientManager.registerSelect("取消", 2);
        mVtsClientManager.registerSelect("返回", 3);
        mVtsClientManager.enableVtsCapability();
    }

}