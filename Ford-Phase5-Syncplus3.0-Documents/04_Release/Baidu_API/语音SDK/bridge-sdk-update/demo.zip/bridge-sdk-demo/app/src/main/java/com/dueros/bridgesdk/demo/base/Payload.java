/*
 * Copyright (C) 2019 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.base;

import java.io.Serializable;

public class Payload implements Serializable {
}
