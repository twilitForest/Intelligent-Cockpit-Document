/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.SeekDirection;
import com.baidu.che.voice.control.vts.param.VtsConstParam;

public class VtsVideoPlayerFragment extends VtsCommonFragment {

    protected String getDesc() {
        return "播放/继续播放/暂停/暂停播放/上一个/下一个/从某时刻开始播放/快进/快退/快进[number]秒/快退[number]秒/重新播放";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
//        builder.registerMediaPlayer(VtsConstParam.MEDIA_TYPE_VIDEO);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

//    /**
//     * 快进快退[seconds]秒
//     *
//     * @param direction
//     * @param seconds
//     */
//    @Override
//    public void onMediaSeekBy(@SeekDirection String direction, int seconds) {
//        updateContent("onMediaSeekBy direction:" + direction + " seconds:" + seconds);
//    }

//    /**
//     * 从某时刻播放
//     */
//    @Override
//    public void onMediaSeekTo(int seconds) {
//        updateContent("onMediaSeekTo seconds:" + seconds);
//    }

//    /**
//     * 暂停
//     */
//    @Override
//    public void onMediaPause() {
//        updateContent("onMediaPause");
//    }

//    /**
//     * 继续播放
//     */
//    @Override
//    public void onMediaContinue() {
//        updateContent("onMediaContinue");
//    }

//    /**
//     * 上一个
//     */
//    @Override
//    public void onMediaPrevious() {
//        updateContent("onMediaPrevious");
//    }
//
//    /**
//     * 下一个
//     */
//    @Override
//    public void onMediaNext() {
//        updateContent("onMediaNext");
//    }
}
