/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.MediaFavoriteAction;
import com.baidu.che.voice.control.vts.param.PlayMode;
import com.baidu.che.voice.control.vts.param.VtsConstParam;

public class VtsAudioPlayerFragment extends VtsVideoPlayerFragment {

    @Override
    protected String getDesc() {
        return "继续/播放/继续播放/暂停/暂停播放/上一个/下一个/从某时刻开始播放/快进快退n秒/收藏/取消收藏/播放收藏"
                + "/播放历史/随机播放/单曲循环/顺序播放/退出";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
//        builder.registerMediaPlayer(VtsConstParam.MEDIA_TYPE_AUDIO);
        BridgeManager.getInstance().setVtsCapability(builder);
    }
//
//    /**
//     * 收藏or取消收藏
//     *
//     * @param action
//     */
//    @Override
//    public void onMediaFavorite(@MediaFavoriteAction String action) {
//        updateContent("onMediaFavorite action:" + action);
//    }
//
//    /**
//     * 播放收藏
//     */
//    @Override
//    public void onMediaPlayFavorite() {
//        updateContent("onMediaPlayFavorite");
//    }
//
//    /**
//     * 播放历史
//     */
//    @Override
//    public void onMediaPlayHistory() {
//        updateContent("onMediaPlayHistory");
//    }
//
//    /**
//     * 播放模式:随机播放/单曲循环/顺序播放
//     *
//     * @param playMode
//     */
//    @Override
//    public void onMediaPlayMode(@PlayMode String playMode) {
//        updateContent("onMediaPlayMode playMode:" + playMode);
//    }
//
//    /**
//     * 退出
//     */
//    @Override
//    public void onMediaExit() {
//        updateContent("onMediaExit");
//    }

}
