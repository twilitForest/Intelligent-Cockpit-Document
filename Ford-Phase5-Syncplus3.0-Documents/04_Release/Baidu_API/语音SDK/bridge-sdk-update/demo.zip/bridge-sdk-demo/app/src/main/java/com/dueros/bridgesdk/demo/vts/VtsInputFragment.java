/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.VtsConstParam;

/**
 * TODO
 */
public class VtsInputFragment extends VtsCommonFragment {

    @Override
    protected String getDesc() {
        return "时间输入今天下午两点半";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerInput(VtsConstParam.TYPE_INPUT_TIME);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onInput(String content, String type, String time) {
        showInToast("输入类型：" + type + ",输入内容为： " + content);
    }
}
