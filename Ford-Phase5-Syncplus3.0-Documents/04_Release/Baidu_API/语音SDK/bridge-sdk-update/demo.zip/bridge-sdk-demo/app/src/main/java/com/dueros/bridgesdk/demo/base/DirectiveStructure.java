/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.base;

import java.util.List;

public class DirectiveStructure {
    public DirectiveStructure() {
    }

    public DirectiveStructure(String namespace) {
        this.namespace = namespace;
    }

    public String namespace;
    public List<String> nameList;

    @Override
    public String toString() {
        return "DirectiveStructure{" +
                "namespace='" + namespace + '\'' +
                ", nameList=" + nameList +
                '}';
    }
}
