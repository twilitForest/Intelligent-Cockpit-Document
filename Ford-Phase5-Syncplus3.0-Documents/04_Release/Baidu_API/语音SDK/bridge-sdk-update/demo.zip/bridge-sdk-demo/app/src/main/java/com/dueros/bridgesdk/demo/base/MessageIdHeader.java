/*
 * Copyright (C) 2019 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.base;

import java.io.Serializable;
import java.util.UUID;

public class MessageIdHeader extends Header implements Serializable {
    public String messageId;
    public MessageIdHeader(){
        super();
    }
    public MessageIdHeader(String nameSpace, String name) {
        super(nameSpace, name);
        this.messageId = UUID.randomUUID().toString();
    }

    public final void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public final String getMessageId() {
        return this.messageId;
    }

    public String toString() {
        return String.format("%1$s id:%2$s", super.toString(), this.messageId);
    }
}