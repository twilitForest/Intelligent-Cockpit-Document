package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.VtsConstParam;

public class VtsRankerFragment extends VtsCommonFragment {


    @Override
    protected String getDesc() {
        return "按[销量/价格/面积/距离/评价/评分]排序 按[销量/价格/面积/距离/评价/评分][从低到高排/从小到大/从近到远]排序";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerRanker(VtsConstParam.TYPE_RANKER_PRICE);
        builder.registerRanker(VtsConstParam.TYPE_RANKER_AREA);
        builder.registerRanker(VtsConstParam.TYPE_RANKER_DISTANCE);
        builder.registerRanker(VtsConstParam.TYPE_RANKER_SCORE);
        builder.registerRanker(VtsConstParam.TYPE_RANKER_COMMENT);
        builder.registerRanker(VtsConstParam.TYPE_RANKER_SALES);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onRanker(String type, String range) {
        showInToast("按照" + type + "从" + range + "排序");
    }
}
