/*
 * Copyright (C) 2019 Baidu, Inc. All Rights Reserved.
 * @author geyongliang
 * @date 2020/04/16
 */
package com.dueros.bridgesdk.demo;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.IDirectReceiver;
import com.dueros.bridgesdk.demo.base.Directive;
import com.dueros.bridgesdk.demo.base.DirectiveStructure;
import com.dueros.bridgesdk.demo.base.MessageIdHeader;
import com.dueros.bridgesdk.demo.base.RegisterStatePayload;
import com.google.gson.Gson;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MainApplication extends Application implements IDirectReceiver {
    private final String TAG = MainApplication.class.getSimpleName();
    private boolean mIsConnected = false;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
        initRegisterStatePayload();
        BridgeManager.getInstance().init(this);
        BridgeManager.getInstance().registerDirectReceiver(this);
    }

    @Override
    public void onTerminate() {
        Log.d(TAG, "onTerminate");
        if (mIsConnected) {
            unregisterDirective();
        }
        super.onTerminate();
    }

    @Override
    public void onReceive(String pkgName, String type, String data) {
        Log.d(TAG, "onReceive data：" + data);
        JSONObject directive = JSON.parseObject(data);
        if (directive == null || !directive.containsKey("header")) {
            return;
        }
        JSONObject header = directive.getJSONObject("header");
        String name = header.getString("name");
        String namespace = header.getString("namespace");
        String payloadStr = directive.getString("payload");
        Log.d(TAG,
                "onReceive name:" + name + " namespace:" + namespace + " payloadStr:" + payloadStr);
        if ("RegisterState".equals(name) &&
                "local.ai.dueros.device_interface.directive_register"
                        .equals(namespace)) {
            RegisterStatePayload payload = JSONObject.parseObject(payloadStr,
                    RegisterStatePayload.class);
            Log.d(TAG, "onReceive " + payload.eventList.size());
        }
        if ("local.ai.dueros.device_interface.extensions.face_id_control".equals(namespace)) {
            return;
        }
    }

    @Override
    public void onConnectionStateChanged(boolean connected) {
        Log.d(TAG, "onConnectionStateChanged connected：" + connected);
        mIsConnected = connected;
        if (connected) {
            // 如果中间断开，再次连接成功，需要再次注册，已经注册的指令不会出现重复注册的问题
            // When the connection with dueros is broken and reconnected successfully,
            // this method will be called again; then you need to call
            // registerDirective() again.
            registerDirective();
        }
    }

    private RegisterStatePayload payload = new RegisterStatePayload();

    /**
     * 初始化注册接收指令相关的payload
     */
    private void initRegisterStatePayload() {
        payload.eventList = new ArrayList<>();
        // 监听DuerOS下发的关于TTS播放相关的指令
        // Register to receive directives related to TTS playback
        DirectiveStructure directiveStructure =
                new DirectiveStructure("local.ai.dueros.device_interface.voice_output");
        payload.eventList.add(directiveStructure);

        // 监听DuerOS下发的关于对话流显示状态相关的指令
        // Register to receive directives related to dialog flow display status
        directiveStructure =
                new DirectiveStructure("local.ai.dueros.device_interface.dialog_control");
        payload.eventList.add(directiveStructure);

        // 注册接收车控相关指令
        // Register to receive directives related to car control
        directiveStructure =
                new DirectiveStructure("ai.dueros.device_interface.extensions.iov_car_control");
        payload.eventList.add(directiveStructure);

        // 注册接收语音触摸屏相关指令
        // Register to receive directives related to voice touch screen
        directiveStructure =
                new DirectiveStructure("ai.dueros.device_interface.extensions.custom_user_interaction");
        payload.eventList.add(directiveStructure);
    }

    // 指令注册请求；务必在onConnectionStateChanged的isConnected=true之后请求，否则不生效
    // Directive request to register; it must be requested when OnConnectionStateChanged is
    // called and the param isConnected is true , otherwise it will not take effect
    private void registerDirective() {
        Log.d(TAG, "registerDirective");
        MessageIdHeader header =
                new MessageIdHeader("local.ai.dueros.device_interface.directive_register",
                        "Register");
        Directive directive = new Directive(header, payload);
        String data = new Gson().toJson(directive);
        BridgeManager.getInstance().send(BridgeManager.DcsType.Event, data);
    }

    // 指令注销请求；务必在onConnectionStateChanged的isConnected=true之后请求，否则不生效
    // Directive request to unregister; it must be requested when OnConnectionStateChanged is
    // called and the param isConnected is true , otherwise it will not take effect
    private void unregisterDirective() {
        MessageIdHeader header =
                new MessageIdHeader("local.ai.dueros.device_interface.directive_register",
                        "Unregister");
        Directive directive = new Directive(header, payload);
        BridgeManager.getInstance().send(BridgeManager.DcsType.Event, new Gson().toJson(directive));
    }

}
