package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsPayFragment extends VtsCommonFragment {

    /**
     * 话术：去支付
     */

    @Override
    protected String getDesc() {
        return "去支付";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerPay("去支付");
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onPay() {
        showInToast("去支付");
    }
}
