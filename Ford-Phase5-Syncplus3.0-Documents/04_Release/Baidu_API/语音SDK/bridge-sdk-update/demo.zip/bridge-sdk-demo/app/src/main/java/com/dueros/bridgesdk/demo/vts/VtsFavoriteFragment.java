package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.VtsConstParam;
import com.dueros.bridgesdk.demo.R;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


public class VtsFavoriteFragment extends VtsBaseFragment {

    /**
     * 话术：收藏第几项，收藏三国演义
     */
    private Button mFavorite,mCancelFavorite;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vts_favorite, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mFavorite = view.findViewById(R.id.fragment_vts_favoritee);
        mCancelFavorite = view.findViewById(R.id.fragment_vts_cancel_favorite);
    }
    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerFavorite(mFavorite.getText().toString(),1,null);
        builder.registerFavorite(mCancelFavorite.getText().toString(),2,null);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onFavorite(String type, int index, String name) {
        if (type.equals(VtsConstParam.FAVORITE_TYPE_ADD)){
            if (TextUtils.isEmpty(name)){
                showInToast("收藏第" + index + "项");
            } else {
                showInToast("收藏" + name);
            }
        } else {
            if (TextUtils.isEmpty(name)){
                showInToast("取消收藏第" + index + "项");
            } else {
                showInToast("取消收藏" + name);
            }
        }


    }
}
