/*
 * Copyright (C) 2019 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo;

import com.dueros.bridgesdk.demo.vts.VtsActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openVoiceControlActivity(View view) {
        Intent intent = new Intent(this, VoiceControlActivity.class);
        startActivity(intent);
    }

    public void openVtsActivity(View view) {
        Intent intent = new Intent(this, VtsActivity.class);
        startActivity(intent);
    }

}
