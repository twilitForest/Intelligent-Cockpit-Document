/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.dueros.bridgesdk.demo.R;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public abstract class VtsCommonFragment extends VtsBaseFragment {
    protected TextView mTvDesc, mTvContent;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vts_common, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mTvDesc = view.findViewById(R.id.fragment_vts_common_tv_desc);
        mTvContent = view.findViewById(R.id.fragment_vts_common_tv_content);
        mTvDesc.setText("请唤醒小度后说：" + getDesc());
        initContent();
    }

    protected abstract String getDesc();

    protected void initContent() {
    }

    protected void updateContent(String content) {
        updateTextView(mTvContent, content);
    }
}
