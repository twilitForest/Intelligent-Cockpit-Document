package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsBackFragment extends VtsCommonFragment {

    @Override
    protected String getDesc() {
        return "返回";
    }

    @Override
    public void onBack() {
        showInToast("点击了返回控件");
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerBack("返回",null);
        BridgeManager.getInstance().setVtsCapability(builder);
    }
}
