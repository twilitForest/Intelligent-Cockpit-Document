package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsListCtrlFragment extends VtsCommonFragment {

    /**
     * 话术：上一个、下一个、换一个
     */

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerChangeSelect(" ",null);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onChangeSelect(String select) {
        updateContent("执行" + select);
    }

    @Override
    protected String getDesc() {
        return "上一个/下一个/换一个";
    }
}
