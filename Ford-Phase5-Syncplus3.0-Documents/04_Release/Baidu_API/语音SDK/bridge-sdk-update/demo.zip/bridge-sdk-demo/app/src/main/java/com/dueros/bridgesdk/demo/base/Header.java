/*
 * Copyright (C) 2019 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.base;

import java.io.Serializable;

public class Header implements Serializable {
    public String namespace;
    public String name;

    @Override
    public String toString() {
        return "Header{" +
                "namespace='" + namespace + '\'' +
                ", name='" + name + '\'' +
                '}';
    }

    public Header() {

    }

    public Header(String namespace, String name) {
        this.namespace = namespace;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getNamespace() {
        return namespace;
    }

}