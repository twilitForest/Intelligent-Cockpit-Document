package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

import android.text.TextUtils;

public class VtsDeleteFragment extends VtsCommonFragment {

    /**
     * 话术：删除抖音，删除第一个
     */

    String[] mDeleteDYUtterance = {"抖音"};
    String[] mDeleteKSUtterance = {"快手"};
    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerDelete("抖音",mDeleteDYUtterance,1);
        builder.registerDelete("快手",mDeleteKSUtterance,2);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onDelete(int index, String name) {
        if (TextUtils.isEmpty(name)) {
            showInToast("删除第" + index + "项");
        } else {
            showInToast("删除" + name);
        }
    }

    @Override
    protected String getDesc() {
        return "删除快手/删除抖音/删除第x个/删除西瓜视频";
    }
}
