/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsPlayFragment extends VtsCommonFragment {
    String[] musicList = new String[] {"左手指月",  "青春", "天蓝如海"};
    String[] videoList =
            new String[] {"我不是药神", "千与千寻", "少年的你", "绿皮书",
                    "泰坦尼克号"};

    @Override
    protected String getDesc() {
        return "播放[name]";
    }

    @Override
    protected void initContent() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("音乐列表：\n");
        stringBuilder.append("-------------------\n");
        for (String music : musicList) {
            stringBuilder.append(music).append("\n");
        }
        stringBuilder.append("电影列表：\n");
        stringBuilder.append("-------------------\n");
        for (String video : videoList) {
            stringBuilder.append(video).append("\n");
        }
        updateContent(stringBuilder.toString());
    }

//    /**
//     * 语音控件回调事件
//     *
//     * @param name
//     * @param index
//     */
//    @Override
//    public void onMusicPlay(final String name, final int index) {
//        String content = "onMusicPlay name：" + name + " index:" + index;
//        showInToast(content);
//    }
//
//    @Override
//    public void onVideoPlay(String name, int index) {
//        String content = "onVideoPlay name：" + name + " index:" + index;
//        showInToast(content);
//    }

    @Override
    protected void setVtsCapability() {
        int index = 1;
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        for (String music : musicList) {
//            builder.registerMusicPlay(music, index++);
        }
        // 由于话术是一样的(播放xxx)，所以index不能相同
        for (String video : videoList) {
//            builder.registerVideoPlay(video, index++);
        }
        BridgeManager.getInstance().setVtsCapability(builder);
    }

}
