package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.dueros.bridgesdk.demo.R;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class VtsPhoneCallFragment extends VtsBaseFragment {

    /**
     * 话术：打电话给张三
     */
    private Button mPhoneCall1;
    private Button mPhoneCall2;
    private Button mPhoneCall3;
    private String[] phoneUtterance1 = {"张三"};
    private String[] phoneUtterance2 = {"李四"};
    private String[] phoneUtterance3 = {"王五"};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vts_phone_call, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mPhoneCall1 = view.findViewById(R.id.fragment_vts_phone_call1);
        mPhoneCall2 = view.findViewById(R.id.fragment_vts_phone_call2);
        mPhoneCall3 = view.findViewById(R.id.fragment_vts_phone_call3);

    }
    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerPhone(mPhoneCall1.getText().toString(),phoneUtterance1,1);
        builder.registerPhone(mPhoneCall2.getText().toString(),phoneUtterance2,2);
        builder.registerPhone(mPhoneCall3.getText().toString(),phoneUtterance3,3);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onPhoneCall(int index, String name) {
        showInToast("打电话给" + name);
    }
}
