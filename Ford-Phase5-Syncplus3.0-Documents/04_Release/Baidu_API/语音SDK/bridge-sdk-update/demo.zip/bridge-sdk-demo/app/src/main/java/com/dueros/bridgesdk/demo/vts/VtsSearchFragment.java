package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.dueros.bridgesdk.demo.R;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class VtsSearchFragment extends VtsBaseFragment {
    EditText mSearchContent;
    Button mSearchButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vts_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mSearchButton = view.findViewById(R.id.fragment_vts_search);
        mSearchContent = view.findViewById(R.id.fragment_vts_search_content);
    }
    @Override
    public void onSearch(String content) {
        mSearchContent.setText(content);
        showInToast("执行Search操作");
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerSearch(mSearchButton.getText().toString());
        BridgeManager.getInstance().setVtsCapability(builder);
    }
}
