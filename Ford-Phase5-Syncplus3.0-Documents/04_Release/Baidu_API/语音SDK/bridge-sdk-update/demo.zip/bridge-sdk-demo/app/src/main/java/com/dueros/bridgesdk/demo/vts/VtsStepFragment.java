/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.MotionEvent;

/**
 * 相关话术，(下一步)
 */
public class VtsStepFragment extends VtsCommonFragment {
    @Override
    protected String getDesc() {
        return "上一步/下一步/第一步/最后一步";
    }

//    /**
//     * @param event
//     * @param value 第一步event=to,value=1；最后一步event=to,value=-1
//     */
//    @Override
//    public void onStep(@MotionEvent String event, int value) {
//        updateContent("onStep event:" + event + " value:" + value);
//    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
//        builder.registerStep();
        BridgeManager.getInstance().setVtsCapability(builder);
    }
}
