/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo;

import java.util.UUID;

import com.baidu.che.voice.control.BridgeManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class VoiceControlActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice_ctrl);
    }

    public void openDialog(View view) {
        String content = "{'header':{'messageId':'" + UUID.randomUUID().toString() + "',"
                + "'name':'OpenDialog',"
                + "'namespace':'local.ai.dueros.device_interface.dialog_control'},"
                + "'payload':{'content':'最近流行音乐','renderType':'RECOMMEND'}}";
        content = content.replace("'", "\"");
        BridgeManager.getInstance().send(BridgeManager.DcsType.Event, content);
    }

    public void closeDialog(View view) {
        String content = "{'header':{'messageId':'" + UUID.randomUUID().toString() + "',"
                + "'name':'CloseDialog',"
                + "'namespace':'local.ai.dueros.device_interface.dialog_control'},"
                + "'payload':{}}";
        content = content.replace("'", "\"");
        BridgeManager.getInstance().send(BridgeManager.DcsType.Event, content);
    }

    public void startPlayTts(View view) {
        String content = "{'header':{'messageId':'" + UUID.randomUUID().toString() + "',"
                + "'name':'SpeakTts',"
                + "'namespace':'local.ai.dueros.device_interface.voice_output'},"
                + "'payload':{'audio':{'loop':'','name':'SpeakTts'},"
                + "'mode':'offline','state':'',"
                + "'text':{'content':'保持清醒，注意安全'},'type':'text'}}";
        content = content.replace("'", "\"");
        BridgeManager.getInstance().send(BridgeManager.DcsType.Event, content);
    }

    public void stopPlayTts(View view) {
        String content = "{'header':{'messageId':'" + UUID.randomUUID().toString() + "',"
                + "'name':'SpeakStopRequest',"
                + "'namespace':'local.ai.dueros.device_interface.voice_output'},"
                + "'payload':{}}";
        content = content.replace("'", "\"");
        BridgeManager.getInstance().send(BridgeManager.DcsType.Event, content);
    }

    @Override
    public void onReceive(String pkg, String type, String data) {
        super.onReceive(pkg, type, data);
        // 对收到的指令data，先解析header中的name与namespace，然后再根据这两个字段再解析payload；
        // 请参考MainApplication中此方法的处理流程
        // When received the directive data, please first parse the name and namespace in the
        // header,
        // then parse the payload according to these two fields。
        // Please refer to the parse process in MainApplication.java
    }
}

