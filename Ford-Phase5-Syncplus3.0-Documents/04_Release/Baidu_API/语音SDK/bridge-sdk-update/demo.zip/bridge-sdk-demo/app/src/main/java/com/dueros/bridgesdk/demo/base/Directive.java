/*
 * Copyright (C) 2019 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.base;

import java.io.Serializable;

public class Directive implements Serializable {
    public MessageIdHeader header;
    public Payload payload;
    public String rawPayload;

    public Directive() {
    }

    public Directive(MessageIdHeader header, Payload payload) {
        this.header = header;
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "Directive{" +
                "header=" + header +
                ", payload=" + payload +
                '}';
    }
}
