package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsExpandFragment extends VtsCommonFragment {
    /**
     * 话术：查看更多
     */

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerExpand("查看更多");
        BridgeManager.getInstance().setVtsCapability(builder);

    }

    @Override
    public void onExpand() {
        updateContent("执行查看更多");
    }

    @Override
    protected String getDesc() {
        return "查看更多";
    }
}
