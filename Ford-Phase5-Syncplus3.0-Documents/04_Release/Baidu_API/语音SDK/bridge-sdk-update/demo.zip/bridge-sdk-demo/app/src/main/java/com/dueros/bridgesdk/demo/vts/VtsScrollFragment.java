/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.MotionDirection;

/**
 * 相关话术，(向下滚动到底/向下滚动[number])；
 */
public class VtsScrollFragment extends VtsCommonFragment {
    @Override
    protected String getDesc() {
        return "向下/上/左/右 滑动，滑到最右";
    }


    @Override
    public void onScroll(@MotionDirection String direction, String event, int value) {
        /**
         * 当说滑到最 X 边时，value=-1
         */
        updateTextView(mTvContent,
                "onScroll direction:" + direction + " event:" + event + " value:" + value);
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerScroll();
        BridgeManager.getInstance().setVtsCapability(builder);
    }
}
