/*
 * Copyright (C) 2019 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.alibaba.fastjson.JSON;
import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.IDirectReceiver;
import com.dueros.bridgesdk.demo.base.Directive;

import android.content.res.Configuration;
import android.util.Log;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity implements IDirectReceiver {
    protected String TAG = BaseActivity.class.getSimpleName();
    private SimpleDateFormat mLogDateFormat = new SimpleDateFormat("HH:mm:ss", Locale.CHINA);
    private Runnable mCurrentScrollDownRunnable;
    TextView mLogScreenVew;
    ScrollView mLogScrollView;

    @Override
    protected void onResume() {
        super.onResume();
        BridgeManager.getInstance().registerDirectReceiver(this);
        if (mLogScreenVew == null) {
            mLogScreenVew = findViewById(R.id.base_text_view);
        }
        if (mLogScrollView == null) {
            mLogScrollView = findViewById(R.id.base_scroll_view);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        BridgeManager.getInstance().unregisterDirectReceiver(this);
    }

    int count = 0;
    final int MAX_COUNT = 300;

    @Override
    public void onReceive(String pkg, String type, String data) {
        Log.d(TAG, "onReceive pkg:" + pkg + " type:" + type + " data:" + data);
        logToScreen(data);
    }

    private void logToScreen(final CharSequence msg) {
        if (mLogScreenVew == null) {
            return;
        }
        count++;
        mLogScreenVew.post(new Runnable() {
            @Override
            public void run() {
                if (count > MAX_COUNT) {
                    mLogScreenVew.setText(msg);
                } else {
                    mLogScreenVew.append(String
                            .format("[%s] %s\n", mLogDateFormat.format(new Date()), msg));
                }

                if (mCurrentScrollDownRunnable != null) {
                    mLogScrollView.removeCallbacks(mCurrentScrollDownRunnable);
                }
                mCurrentScrollDownRunnable = new Runnable() {
                    @Override
                    public void run() {
                        mLogScrollView.fullScroll(View.FOCUS_DOWN);
                    }
                };
                mLogScrollView.postDelayed(mCurrentScrollDownRunnable, 100);
            }
        });

    }

    @Override
    public void onConnectionStateChanged(boolean isConnected) {
        Log.d(TAG, "onConnected");
        logToScreen("BridgeManager onConnectStateChanged:" + isConnected);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
