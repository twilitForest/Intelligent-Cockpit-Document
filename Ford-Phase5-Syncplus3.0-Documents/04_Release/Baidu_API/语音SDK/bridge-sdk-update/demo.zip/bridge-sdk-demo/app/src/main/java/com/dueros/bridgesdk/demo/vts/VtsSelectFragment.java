/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;


public class VtsSelectFragment extends VtsCommonFragment {

    @Override
    protected String getDesc() {
        return "点击[name]，选择[name]，选择第[index]个";
    }

    @Override
    protected void initContent() {
        updateContent("确认\n取消\n返回");
    }

    /**
     * 语音控件回调事件
     *
     * @param name
     * @param index
     */
    @Override
    public void onSelect(final String name, final int index) {
        showInToast("onSelect onSelect:" + name + " index:" + index);
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerSelect("确认", 1);
        builder.registerSelect("取消", 2);
        builder.registerSelect("返回", 3);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

}
