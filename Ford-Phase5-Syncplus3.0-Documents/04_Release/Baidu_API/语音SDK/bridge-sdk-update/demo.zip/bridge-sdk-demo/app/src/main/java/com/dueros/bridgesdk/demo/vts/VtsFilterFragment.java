package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsFilterFragment extends VtsCommonFragment {
    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerFilter();
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onFilter(String content) {
        showInToast(content);
    }

    @Override
    protected String getDesc() {
        return "只看xxx";
    }
}
