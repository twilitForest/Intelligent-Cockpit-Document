package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsClearCacheFragment extends VtsCommonFragment {

    /**
     * 话术：清除缓存
     */

    @Override
    protected String getDesc() {
        return "清除缓存";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerClearCache("清除缓存");
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onClearCache() {
        showInToast("执行清除缓存");
    }
}
