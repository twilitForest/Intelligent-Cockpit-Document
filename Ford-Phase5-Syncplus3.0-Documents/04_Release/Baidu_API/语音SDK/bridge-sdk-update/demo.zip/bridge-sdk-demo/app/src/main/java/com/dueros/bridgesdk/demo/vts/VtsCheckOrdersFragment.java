package com.dueros.bridgesdk.demo.vts;

import android.text.TextUtils;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsCheckOrdersFragment extends VtsCommonFragment {

    /**
     * 话术：打开我的订单，打开未支付订单，打开待发货订单
     */

    @Override
    protected String getDesc() {
        return "打开我的订单/打开未支付订单/打开待发货订单/打开xx订单";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerCheckOrder("查看订单");
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onCheckOrder(String type) {
        if (!TextUtils.isEmpty(type)) {
            showInToast("查看" + type + "订单");
        } else {
            showInToast("查看订单");
        }

    }
}
