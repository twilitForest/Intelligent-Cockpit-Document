/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.dueros.bridgesdk.demo.R;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class VtsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vts);
        getSupportFragmentManager().beginTransaction().add(R.id.activity_vts_frame_container,
                new VtsMainFragment(), "main").commit();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    protected void onDestroy() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }

    public void openVtsClick(View view) {
        addFragment(new VtsSelectFragment(), "click");
    }

    public void openVtsTab(View view) {
        addFragment(new VtsTabFragment(), "tab");
    }

    public void openVtsPlay(View view) {
        addFragment(new VtsPlayFragment(), "play");
    }

    public void openVtsMessage(View view) {
        addFragment(new VtsMessageFragment(), "message");
    }

    public void openVtsViewPhoto(View view) {
        addFragment(new VtsViewPhotoFragment(), "viewPhoto");
    }

    public void openVideoPlayer(View view) {
        addFragment(new VtsVideoPlayerFragment(), "videoPlayer");
    }

    public void openAudioPlayer(View view) {
        addFragment(new VtsAudioPlayerFragment(), "audioPlayer");
    }

    public void openScroll(View view) {
        addFragment(new VtsScrollFragment(), "scroll");
    }

    public void openPager(View view) {
        addFragment(new VtsPagerFragment(), "pager");
    }

    public void openStep(View view) {
        addFragment(new VtsStepFragment(), "step");
    }

    /**
     * TODO 使用IOV_INPUT控件，待完善
     *
     * @param view
     */
    public void openVtsInput(View view) {
        addFragment(new VtsInputFragment(), "input");
    }

    public void openVtsBack(View view){
        addFragment(new VtsBackFragment(),"iov_back");
    }

    public void openVtsSearch(View view){
        addFragment(new VtsSearchFragment(),"iov_search");
    }

    public void openVtsRanker(View view){
        addFragment(new VtsRankerFragment(),"iov_ranker");
    }

    public void openVtsFavorite(View view){
        addFragment(new VtsFavoriteFragment(),"iov_favorite");
    }

    public void openVtsNavigation(View view){
        addFragment(new VtsNaviFragment(),"iov_navi");
    }

    public void openVtsPhoneCall(View view){
        addFragment(new VtsPhoneCallFragment(),"iov_phone_call");
    }

    public void openVtsExpand(View view){
        addFragment(new VtsExpandFragment(),"iov_expand");
    }

    public void openVtsDelete(View view){
        addFragment(new VtsDeleteFragment(),"iov_delete");
    }

    public void openVtsPay(View view){
        addFragment(new VtsPayFragment(),"iov_pay");
    }

    public void openVtsLogin(View view){
        addFragment(new VtsLoginFragment(),"iov_login");
    }

    public void openVtsBuyMembership(View view){
        addFragment(new VtsBuyMembershipFragment(),"iov_buy_membership");
    }

    public void openVtsCheckOrderStatus(View view){
        addFragment(new VtsCheckOrdersFragment(),"iov_check_orders");
    }

    public void openVtsClearCache(View view){
        addFragment(new VtsClearCacheFragment(),"iov_clear_cache");
    }

    public void openVtsListCtrl(View view){
        addFragment(new VtsListCtrlFragment(),"iov_list_ctrl");
    }

    public void openVtsConfirmCancel(View view){
        addFragment(new VtsConfirmCancelFragment(),"iov_confirm");
    }

    public void openVtsFilter(View view){
        addFragment(new VtsFilterFragment(),"iov_filter");
    }


    private void addFragment(Fragment fragment, String tag) {
        Fragment main = getSupportFragmentManager().findFragmentByTag("main");
        getSupportFragmentManager().beginTransaction()
                .add(R.id.activity_vts_frame_container, fragment, tag)
                .addToBackStack(tag).hide(main).commit();
    }

}
