/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

/**
 * 相关话术，(切换到[TabName]，选择[TabName]，点击[TabName])
 */
public class VtsTabFragment extends VtsCommonFragment {
    String[] names = new String[]{"电影", "电视剧", "音乐", "相声", "添加电话", "最近通话", "联系人", "收藏夹", "键盘", "电话"};

    @Override
    protected String getDesc() {
        return "切换到[TabName]，选择[TabName]，点击[TabName]";
    }

    @Override
    protected void initContent() {
        StringBuilder stringBuilder = new StringBuilder();
        for (String name : names) {
            stringBuilder.append(name).append("\n");
        }
        updateContent(stringBuilder.toString());
    }

    @Override
    protected void setVtsCapability() {
        int size = names.length;
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        for (int index = 0; index < size; index++) {
            builder.registerTab(names[index], index + 1, new String[]{names[index]});
        }
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onTabSelect(String name, int index) {
        showInToast("onTabSelect name:" + name + " index:" + index);
    }
}
