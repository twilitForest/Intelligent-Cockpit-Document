/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.base;

import java.util.List;

public class RegisterStatePayload extends Payload {
    public List<DirectiveStructure> eventList;

}
