/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;
import com.baidu.che.voice.control.vts.param.MotionEvent;

public class VtsPagerFragment extends VtsCommonFragment {
    @Override
    protected String getDesc() {
        return "相关话术->打开上一页/打开下一页/打开第X页/打开首页/打开最后一页";
    }

    @Override
    public void onPager(@MotionEvent String event, int value) {
        updateContent("onPager event:" + event + " value:" + value);
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerPager();
        BridgeManager.getInstance().setVtsCapability(builder);
    }
}
