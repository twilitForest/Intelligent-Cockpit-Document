package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsConfirmCancelFragment extends VtsCommonFragment {
    /**
     * 话术：确认/取消/点击确认/点击取消/
     */

    @Override
    protected String getDesc() {
        return "确认/取消/点击确认/点击取消/";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerConfirm("确认");
        builder.registerCancel("取消");
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onConfirm() {
        showInToast("执行确认操作");
    }

    @Override
    public void onCancel() {
        showInToast("执行取消操作");
    }
}
