/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

/**
 * 阅读第[index]条留言暂不可用
 */
public class VtsMessageFragment extends VtsCommonFragment {
    String[] personList = new String[] {"张三", "李四", "王二", "麻子"};

    @Override
    protected String getDesc() {
        return "发消息给第[index]个人/阅读第[index]条留言";
    }

//    @Override
//    public void onReadMessage(int index) {
//        updateContent("读取:" + index);
//    }
//
//    @Override
//    public void onSendMessage(int index) {
//        updateContent("发送:" + index);
//    }

    @Override
    protected void setVtsCapability() {
        int index = 1;
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
//        for (String person : personList) {
//            builder.registerSendMessage(index);
//            builder.registerReadMessage(index++);
//        }
        BridgeManager.getInstance().setVtsCapability(builder);
    }

}
