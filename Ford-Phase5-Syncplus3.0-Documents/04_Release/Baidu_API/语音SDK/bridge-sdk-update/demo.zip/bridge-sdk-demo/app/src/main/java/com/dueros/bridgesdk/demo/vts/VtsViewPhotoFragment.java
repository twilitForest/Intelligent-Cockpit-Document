/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsViewPhotoFragment extends VtsCommonFragment {

    @Override
    protected String getDesc() {
        return "控件对应话术->查看第[index]张照片";
    }

//    @Override
//    public void onViewPhoto(int index) {
//        updateContent("onViewPhoto index:" + index);
//    }

    @Override
    protected void setVtsCapability() {
        int size = 10;
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        for (int index = 1; index <= size; index++) {
//            builder.registerViewPhoto(index);
        }
        BridgeManager.getInstance().setVtsCapability(builder);
    }

}
