package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

import android.text.TextUtils;

public class VtsNaviFragment extends VtsCommonFragment {

    /**
     * 话术：导航过去/导航去这里/开始导航/导航到xxx/导航第x个
     */

    private String[] mNaviUtterance = {"世界之窗","海洋馆","动物园"};

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerNavigation("导航",mNaviUtterance,1);
        builder.registerNavigation("导航",mNaviUtterance,2);
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onNavigation(String content, int index) {
        if (TextUtils.isEmpty(content)) {
            showInToast("导航过去" + "导航第" + index  + "个");
        } else {
            showInToast("导航到" + content);
        }
    }

    @Override
    protected String getDesc() {
        return "导航过去/导航去这里/开始导航/导航到xxx/导航第x个";
    }
}
