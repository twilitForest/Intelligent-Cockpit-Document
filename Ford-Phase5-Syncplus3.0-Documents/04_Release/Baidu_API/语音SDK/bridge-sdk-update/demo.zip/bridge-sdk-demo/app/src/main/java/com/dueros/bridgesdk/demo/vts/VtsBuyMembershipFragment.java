package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;


public class VtsBuyMembershipFragment extends VtsCommonFragment {

    /**
     * 话术：购买会员
     */
    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerBuyMembership("购买会员");
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onBuyMember() {
        showInToast("执行购买会员");
    }

    @Override
    protected String getDesc() {
        return "购买会员";
    }
}
