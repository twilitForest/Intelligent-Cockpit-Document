package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsCapabilityBuilder;

public class VtsLoginFragment extends VtsCommonFragment {

    /**
     * 话术：登录账号
     */

    @Override
    protected String getDesc() {
        return "去登录/登录/登录xxx";
    }

    @Override
    protected void setVtsCapability() {
        VtsCapabilityBuilder builder = new VtsCapabilityBuilder();
        builder.registerLogin("登录");
        BridgeManager.getInstance().setVtsCapability(builder);
    }

    @Override
    public void onLogin() {
        showInToast("执行登录操作");
    }
}
