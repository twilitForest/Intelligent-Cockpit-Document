/*
 * Copyright (C) 2020 Baidu, Inc. All Rights Reserved.
 */
package com.dueros.bridgesdk.demo.vts;

import com.baidu.che.voice.control.BridgeManager;
import com.baidu.che.voice.control.vts.VtsDirectiveListener;

import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public abstract class VtsBaseFragment extends Fragment implements VtsDirectiveListener {

    @Override
    public void onResume() {
        super.onResume();
        BridgeManager.getInstance().addVtsDirectiveListener(this);
        setVtsCapability();
    }

    /**
     * 设置语音触摸屏能力
     */
    protected abstract void setVtsCapability();

    @Override
    public void onPause() {
        super.onPause();
        BridgeManager.getInstance().removeVtsDirectiveListener(this);
        BridgeManager.getInstance().deleteVtsCapability();
    }

    protected void showInToast(final String content) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getContext(), content, Toast.LENGTH_LONG).show();
            }
        });
    }

    protected void updateTextView(final TextView textView, final String content) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textView.setText(content);
            }
        });
    }
}