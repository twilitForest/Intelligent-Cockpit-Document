### 前置条件

首先要注册需要接收DuerOS消息的协议族（不同的协议族通过namespace来区分）。

### 指令注册

  如前置条件所述，使用此协议前必须注册接收此协议族，否则收不到相关指令，注册示例的data字段如下

  ```json
  {
    "header":{
      "namespace":"local.ai.dueros.device_interface.directive_register",
      "name":"Register",
      "messageId":"{{STRING}}",
      "dialogRequestId":"{{STRING}}"
    }
    "payload":{
      "eventList":[
        {"namespace":"local.ai.dueros.device_interface.voice_output"}
      ]
    }
  }
  ```

  参数说明：

  - messageId 建议使用java.util.UUID.randomUUID().toString()生成，DuerOS在返回此次请求结果时会带上同样的messageId；
  - (optional) dialogRequestId  扩展字段(默认不使用)。
  - eventList 可以注册多类指令，此处以TTS播放功能为例。

注册成功后，通过IDirectReceiver.onReceive收到的data数据如下

  ```json
  "directive":{
      "header":{
      "namespace": "local.ai.dueros.device_interface.directive_register",
      "name": "RegisterState",
      "messageId": "{{STRING}}",
      "dialogRequestId": "{{STRING}}"
    }
    "payload":{
      "eventList":[
      	{"namespace":"local.ai.dueros.device_interface.voice_output"}
      ]
    }
  }
  ```


### 使用示例

注册成功后，就可以正常使用TTS播放相关的功能了。

- 发送TTS请求的data示例如下：

  ```json
  {
    "header": {
      "namespace": "local.ai.dueros.device_interface.voice_output",
      "name": "SpeakTts",
      "messageId": "{{STRING}}",
      "dialogRequestId": "{{STRING}}"
    },
    "payload": {
      "type":"text",
      "mode":"offline",
      "text":{
         "content":"小度，你好"
       }
    }
  }
  ```

  - 参数说明

    具体内容请参考附件中的**DuerOS_语音播报协议.pdf**

- TTS状态通知

  通过IDirectReceiver.onReceive收到的data字段如下：

  ```json
  "directive": {
    "header": {
      "namespace": "local.ai.dueros.device_interface.voice_output",
      "name": "SpeakState",
      "messageId": "{{STRING}}",
      "dialogRequestId": "{{STRING}}"
    },
    "payload": {
      "state":"PLAYING"
    }
  }
  ```

- 参数说明

  具体内容请参考附件中的**DuerOS_语音播报协议.pdf**

### 指令注销

当注册过TTS指令后，即使不是自己发出的TTS请求也会收到相关的TTS状态通知；所以如果不需要再关注TTS状态，那么就可以注销掉相关的TTS指令接收，示例如下：

```json
{
    "header":{
    "namespace": "local.ai.dueros.device_interface.directive_register",
    "name": "Unregister",
    "messageId": "{{STRING}}",
    "dialogRequestId": "{{STRING}}"
  }
  "payload":{
    "eventList":[
  		{"namespace":"local.ai.dueros.device_interface.voice_output"}
		]
  }
}
```

- 参数说明

  具体内容请参考附件中的**DuerOS_指令注册协议.pdf**