package com.yfve.test

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.yfve.testaar.AarActivity

class MainActivity : AppCompatActivity(), View.OnClickListener {
    lateinit var changeThemeBtn: Button
    lateinit var startAarActivityBtn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        changeThemeBtn = findViewById(R.id.btn_change_theme)
        startAarActivityBtn = findViewById(R.id.btn_start_aar_activity)

        changeThemeBtn.setOnClickListener(this)
        startAarActivityBtn.setOnClickListener(this)

    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btn_change_theme -> {
                Toast.makeText(this, "功能待实现", Toast.LENGTH_SHORT).show()
            }
            R.id.btn_start_aar_activity -> {
                val intent = Intent(this, AarActivity::class.java)
                startActivity(intent)

            }
        }
    }
}