/*
 * File: PDG_CGEA_1_2_V2_1.c
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V2_1'.
 *
 * Model version                  : 1.1177
 * Simulink Coder version         : 8.4 (R2013a) 13-Feb-2013
 * TLC version                    : 8.4 (Jan 19 2013)
 * C/C++ source code generated on : Tue Jul 08 13:12:02 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (8), Warnings (2), Error (0)
 */

#include "PDG_CGEA_1_2_V2_1.h"
#include "PDG_CGEA_1_2_V2_1_private.h"

/* Block signals and states (auto storage) */
D_Work_PDG_CGEA_1_2_V2_1 PDG_CGEA_1_2_V2_1_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_PDG_CGEA_1_2_V2_ PDG_CGEA_1_2_V2_1_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_PDG_CGEA_1_2_V2 PDG_CGEA_1_2_V2_1_Y;
void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                  *ptrOutBitsLo)
{
  uint32_T absIn;
  uint32_T absIn_0;
  uint32_T in0Lo;
  uint32_T in0Hi;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn = (uint32_T)((in0 < 0) ? (-in0) : in0);
  absIn_0 = (uint32_T)((in1 < 0) ? (-in1) : in1);
  in0Hi = (absIn >> 16U);
  in0Lo = absIn & 65535U;
  in1Hi = (absIn_0 >> 16U);
  absIn = absIn_0 & 65535U;
  productHiLo = in0Hi * absIn;
  productLoHi = in0Lo * in1Hi;
  absIn *= in0Lo;
  absIn_0 = 0U;
  in0Lo = (productLoHi << 16U) + absIn;
  if (in0Lo < absIn) {
    absIn_0 = 1U;
  }

  absIn = in0Lo;
  in0Lo += (productHiLo << 16U);
  if (in0Lo < absIn) {
    absIn_0++;
  }

  absIn = (((productLoHi >> 16U) + (productHiLo >> 16U)) + (in0Hi * in1Hi)) +
    absIn_0;
  if (!((in0 == 0) || ((in1 == 0) || ((in0 > 0) == (in1 > 0))))) {
    absIn = ~absIn;
    in0Lo = ~in0Lo;
    in0Lo++;
    if (in0Lo == 0U) {
      absIn++;
    }
  }

  *ptrOutBitsHi = absIn;
  *ptrOutBitsLo = in0Lo;
}

int32_T mul_s32_s32_s32_sr9(int32_T a, int32_T b)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  u32_clo = (u32_chi << 23U) | (u32_clo >> 9U);
  return (int32_T)u32_clo;
}

int32_T div_nzp_repeat_s32(int32_T numerator, int32_T denominator, uint32_T
  nRepeatSub)
{
  uint32_T tempAbsQuotient;
  uint32_T quotientNeedsNegation;
  quotientNeedsNegation = (uint32_T)((numerator < 0) != (denominator < 0));
  tempAbsQuotient = div_nzp_repeat_u32((uint32_T)((numerator >= 0) ? numerator :
                                        (-numerator)), (uint32_T)((denominator >=
    0) ? denominator : (-denominator)), nRepeatSub);
  return quotientNeedsNegation ? (-((int32_T)tempAbsQuotient)) : ((int32_T)
    tempAbsQuotient);
}

uint32_T div_nzp_repeat_u32(uint32_T numerator, uint32_T denominator, uint32_T
  nRepeatSub)
{
  uint32_T quotient;
  uint32_T iRepeatSub;
  uint8_T numeratorExtraBit;
  quotient = numerator / denominator;
  numerator %= denominator;
  for (iRepeatSub = (uint32_T)0; iRepeatSub < nRepeatSub; iRepeatSub++) {
    numeratorExtraBit = (uint8_T)(numerator >= 2147483648U);
    numerator <<= 1;
    quotient <<= 1;
    if (numeratorExtraBit || (numerator >= denominator)) {
      quotient++;
      numerator -= denominator;
    }
  }

  return quotient;
}

/* Output and update for function-call system: '<S4>/Multiply' */
void PDG_CGEA_1_2_V2_1_Multiply(int32_T rtu_input1, int32_T rtu_input2,
  rtDW_Multiply_PDG_CGEA_1_2_V2_1 *localDW)
{
  /* Product: '<S9>/Multiply' */
  localDW->Multiply = mul_s32_s32_s32_sr9(rtu_input1, rtu_input2);
}

/* Output and update for function-call system: '<S4>/Absolute' */
void PDG_CGEA_1_2_V2_1_Absolute(uint32_T rtu_input,
  rtDW_Absolute_PDG_CGEA_1_2_V2_1 *localDW)
{
  /* Abs: '<S7>/Abs' */
  localDW->Abs = (int32_T)rtu_input;
}

/* Output and update for function-call system: '<S4>/Divide' */
void PDG_CGEA_1_2_V2_1_Divide(int32_T rtu_dividend, int32_T rtu_divisor,
  rtDW_Divide_PDG_CGEA_1_2_V2_1 *localDW)
{
  /* Product: '<S8>/Divide' */
  localDW->Divide = div_nzp_repeat_s32(rtu_dividend, rtu_divisor, 9U);
}

/* Model step function */
void PDG_CGEA_1_2_V2_1_step(void)
{
  int32_T Front_Axle_Torque;
  int32_T Wheel_RPM;
  boolean_T guard = FALSE;
  int32_T rtb_Front_Percent_Fill;
  int32_T rtb_Rear_Percent_Fill;
  int32_T rtb_Switch2;
  int32_T rtb_PrplWhlTot_Tq_Actl_filt;
  int32_T rtb_DynamicPoleSum;

  /* Switch: '<S11>/Switch2' incorporates:
   *  Inport: '<Root>/PG_PT_TORQUE_MAX'
   *  Inport: '<Root>/prpwhltot_tq_actl'
   *  RelationalOperator: '<S11>/LowerRelop1'
   *  RelationalOperator: '<S11>/UpperRelop'
   *  Switch: '<S11>/Switch'
   */
  if (PDG_CGEA_1_2_V2_1_U.prpwhltot_tq_actl >
      PDG_CGEA_1_2_V2_1_U.PG_PT_TORQUE_MAX) {
    rtb_Switch2 = PDG_CGEA_1_2_V2_1_U.PG_PT_TORQUE_MAX;
  } else if (PDG_CGEA_1_2_V2_1_U.prpwhltot_tq_actl < 0) {
    /* Switch: '<S11>/Switch' incorporates:
     *  Constant: '<S5>/PGTorqueDecayConstant'
     */
    rtb_Switch2 = 0;
  } else {
    rtb_Switch2 = PDG_CGEA_1_2_V2_1_U.prpwhltot_tq_actl;
  }

  /* End of Switch: '<S11>/Switch2' */

  /* Chart: '<S5>/DynamicSwitch' incorporates:
   *  Inport: '<Root>/PG_DECAY_FALLING_HI_TORQ'
   *  Inport: '<Root>/PG_DECAY_FALLING_LO_TORQ'
   *  Inport: '<Root>/PG_DECAY_FALLING_SWITCHPOINT'
   */
  /* Gateway: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* During: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* Entry Internal: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* Transition: '<S10>:12' */
  if (rtb_Switch2 >= PDG_CGEA_1_2_V2_1_U.PG_DECAY_FALLING_SWITCHPOINT) {
    /* Transition: '<S10>:15' */
    /* Transition: '<S10>:20' */
    PDG_CGEA_1_2_V2_1_DWork.output =
      PDG_CGEA_1_2_V2_1_U.PG_DECAY_FALLING_HI_TORQ;

    /* Transition: '<S10>:24' */
  } else {
    if (rtb_Switch2 < PDG_CGEA_1_2_V2_1_U.PG_DECAY_FALLING_SWITCHPOINT) {
      /* Transition: '<S10>:16' */
      /* Transition: '<S10>:19' */
      PDG_CGEA_1_2_V2_1_DWork.output =
        PDG_CGEA_1_2_V2_1_U.PG_DECAY_FALLING_LO_TORQ;

      /* Transition: '<S10>:22' */
    }
  }

  /* End of Chart: '<S5>/DynamicSwitch' */

  /* Switch: '<S5>/rising_or_falling' incorporates:
   *  Inport: '<Root>/PG_DECAY_RISING'
   *  Sum: '<S5>/PGTorqueDecaySum1'
   *  UnitDelay: '<S5>/PGTorqueDecayUnit Delay'
   */
  if ((rtb_Switch2 - PDG_CGEA_1_2_V2_1_DWork.PGTorqueDecayUnitDelay_DSTATE) >= 0)
  {
    Front_Axle_Torque = PDG_CGEA_1_2_V2_1_U.PG_DECAY_RISING;
  } else {
    Front_Axle_Torque = PDG_CGEA_1_2_V2_1_DWork.output;
  }

  /* End of Switch: '<S5>/rising_or_falling' */

  /* Sum: '<S12>/TcFilterSubtract' incorporates:
   *  Product: '<S12>/TcFilterProduct1'
   *  Sum: '<S12>/TcFilterSubtract1'
   *  UnitDelay: '<S12>/TcFilterUnit Delay'
   */
  rtb_PrplWhlTot_Tq_Actl_filt = PDG_CGEA_1_2_V2_1_DWork.TcFilterUnitDelay_DSTATE
    - mul_s32_s32_s32_sr9(Front_Axle_Torque,
    PDG_CGEA_1_2_V2_1_DWork.TcFilterUnitDelay_DSTATE - rtb_Switch2);

  /* Chart: '<S3>/DynamicCompare' incorporates:
   *  Inport: '<Root>/PG_PRPLWHL_TQ_LOW_LIMIT'
   *  Inport: '<Root>/prpwhltot_tq_actl'
   */
  /* Gateway: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* During: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* Entry Internal: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* Transition: '<S6>:2' */
  if (PDG_CGEA_1_2_V2_1_U.prpwhltot_tq_actl <=
      PDG_CGEA_1_2_V2_1_U.PG_PRPLWHL_TQ_LOW_LIMIT) {
    /* Transition: '<S6>:5' */
    /* Transition: '<S6>:13' */
    PDG_CGEA_1_2_V2_1_DWork.output_h = TRUE;

    /* Transition: '<S6>:12' */
  } else {
    if (PDG_CGEA_1_2_V2_1_U.prpwhltot_tq_actl >
        PDG_CGEA_1_2_V2_1_U.PG_PRPLWHL_TQ_LOW_LIMIT) {
      /* Transition: '<S6>:6' */
      /* Transition: '<S6>:10' */
      PDG_CGEA_1_2_V2_1_DWork.output_h = FALSE;

      /* Transition: '<S6>:11' */
    }
  }

  /* End of Chart: '<S3>/DynamicCompare' */

  /* Switch: '<S3>/EngineBreakLogicSwitch' incorporates:
   *  Constant: '<S3>/EngineBreakLogicConstant'
   *  Inport: '<Root>/awdlck_tq_req'
   */
  if (PDG_CGEA_1_2_V2_1_DWork.output_h) {
    rtb_Switch2 = 0;
  } else {
    rtb_Switch2 = PDG_CGEA_1_2_V2_1_U.awdlck_tq_req;
  }

  /* End of Switch: '<S3>/EngineBreakLogicSwitch' */

  /* Sum: '<S2>/DynamicPoleSum' incorporates:
   *  Inport: '<Root>/PG_WHL_TRQ_FILTER'
   *  Product: '<S2>/DynamicPoleProduct'
   *  Sum: '<S2>/DynamicPoleDiff'
   *  UnitDelay: '<S2>/DynamicPoleUD'
   */
  rtb_DynamicPoleSum = mul_s32_s32_s32_sr9(PDG_CGEA_1_2_V2_1_U.PG_WHL_TRQ_FILTER,
    PDG_CGEA_1_2_V2_1_DWork.DynamicPoleUD_DSTATE - rtb_Switch2) + rtb_Switch2;

  /* Chart: '<S1>/PDG' incorporates:
   *  Inport: '<Root>/AwdRngFalt_D_Stat'
   *  Inport: '<Root>/AwdRng_D_Actl'
   *  Inport: '<Root>/GearLvrPos_D_Actl'
   *  Inport: '<Root>/PG_MAX_POWER_VALUE'
   *  Inport: '<Root>/PG_PERCENT_FILL_CONV_CONSTANT'
   *  Inport: '<Root>/PG_POWER_CONV_CONSTANT'
   *  Inport: '<Root>/PG_POWER_MULTIPLIER'
   *  Inport: '<Root>/PG_REAR_AXLE_RATIO'
   *  Inport: '<Root>/PG_WHEEL_RPM_CONV_CONSTANT'
   *  Inport: '<Root>/veh_v_actleng'
   */
  /* Gateway: Power Gauge/PDG */
  /* During: Power Gauge/PDG */
  /* Entry Internal: Power Gauge/PDG */
  /* Transition: '<S4>:107' */
  /* ReverseDriveSportDLowfirstsecondthirdfourthfifthsixth */
  if (((((PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 0) ||
         (PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 2048)) ||
        (PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 2560)) ||
       (PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 3072)) &&
      ((((((((((PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 512) ||
               (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 1536)) ||
              (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 2048)) ||
             (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 2560)) ||
            (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 3072)) ||
           (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 3584)) ||
          (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 4096)) ||
         (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 4608)) ||
        (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 5120)) ||
       (PDG_CGEA_1_2_V2_1_U.GearLvrPos_D_Actl == 5632))) {
    /* Transition: '<S4>:146' */
    if (PDG_CGEA_1_2_V2_1_U.AwdRngFalt_D_Stat != 512) {
      /* Transition: '<S4>:104' */
      if (PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 2560) {
        /* Transition: '<S4>:143' */
        /* 4x4 Auto Mode */
        /* Transition: '<S4>:141' */
        /* Simulink Function 'Absolute': '<S4>:158' */
        PDG_CGEA_1_2_V2_1_DWork.input = (uint32_T)rtb_PrplWhlTot_Tq_Actl_filt;

        /* Outputs for Function Call SubSystem: '<S4>/Absolute' */
        PDG_CGEA_1_2_V2_1_Absolute(PDG_CGEA_1_2_V2_1_DWork.input,
          &PDG_CGEA_1_2_V2_1_DWork.Absolute);

        /* End of Outputs for SubSystem: '<S4>/Absolute' */
        rtb_Switch2 = PDG_CGEA_1_2_V2_1_DWork.Absolute.Abs;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = rtb_DynamicPoleSum;
        PDG_CGEA_1_2_V2_1_DWork.input2 = PDG_CGEA_1_2_V2_1_U.PG_REAR_AXLE_RATIO;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Front_Axle_Torque = PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = PDG_CGEA_1_2_V2_1_U.veh_v_actleng;
        PDG_CGEA_1_2_V2_1_DWork.input2 =
          PDG_CGEA_1_2_V2_1_U.PG_WHEEL_RPM_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Wheel_RPM = PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.Max_Power =
          PDG_CGEA_1_2_V2_1_U.PG_MAX_POWER_VALUE;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = Front_Axle_Torque;
        PDG_CGEA_1_2_V2_1_DWork.input2 =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:120' */
        PDG_CGEA_1_2_V2_1_DWork.dividend =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.divisor =
          PDG_CGEA_1_2_V2_1_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
          PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_DWork.Front_Power =
          PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = rtb_Switch2;
        PDG_CGEA_1_2_V2_1_DWork.input2 = Wheel_RPM;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:120' */
        PDG_CGEA_1_2_V2_1_DWork.dividend =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.divisor =
          PDG_CGEA_1_2_V2_1_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
          PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_DWork.Rear_Power =
          PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;

        /* Transition: '<S4>:176' */
      } else {
        /* Transition: '<S4>:103' */
      }

      /* Transition: '<S4>:140' */
      if ((PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 0) ||
          (PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 2048)) {
        /* Transition: '<S4>:174' */
        /* 4x4 High or 4x4 Low Mode */
        /* Transition: '<S4>:172' */
        /* Simulink Function 'Absolute': '<S4>:158' */
        PDG_CGEA_1_2_V2_1_DWork.input = (uint32_T)rtb_PrplWhlTot_Tq_Actl_filt;

        /* Outputs for Function Call SubSystem: '<S4>/Absolute' */
        PDG_CGEA_1_2_V2_1_Absolute(PDG_CGEA_1_2_V2_1_DWork.input,
          &PDG_CGEA_1_2_V2_1_DWork.Absolute);

        /* End of Outputs for SubSystem: '<S4>/Absolute' */
        rtb_Switch2 = PDG_CGEA_1_2_V2_1_DWork.Absolute.Abs;
        Front_Axle_Torque = PDG_CGEA_1_2_V2_1_DWork.Absolute.Abs;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = PDG_CGEA_1_2_V2_1_U.veh_v_actleng;
        PDG_CGEA_1_2_V2_1_DWork.input2 =
          PDG_CGEA_1_2_V2_1_U.PG_WHEEL_RPM_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Wheel_RPM = PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.Max_Power =
          PDG_CGEA_1_2_V2_1_U.PG_MAX_POWER_VALUE;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = Front_Axle_Torque;
        PDG_CGEA_1_2_V2_1_DWork.input2 =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:120' */
        PDG_CGEA_1_2_V2_1_DWork.dividend =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.divisor =
          PDG_CGEA_1_2_V2_1_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
          PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_DWork.Front_Power =
          PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = rtb_Switch2;
        PDG_CGEA_1_2_V2_1_DWork.input2 = Wheel_RPM;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:120' */
        PDG_CGEA_1_2_V2_1_DWork.dividend =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.divisor =
          PDG_CGEA_1_2_V2_1_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
          PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_DWork.Rear_Power =
          PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;

        /* Transition: '<S4>:136' */
      } else {
        /* Transition: '<S4>:138' */
      }

      /* Transition: '<S4>:170' */
      guard = TRUE;
    } else {
      /* Transition: '<S4>:105' */
      if (PDG_CGEA_1_2_V2_1_U.AwdRngFalt_D_Stat == 512) {
        /* Transition: '<S4>:134' */
        guard = TRUE;
      } else {
        /* Transition: '<S4>:132' */
        rtb_Front_Percent_Fill = 0;
        rtb_Rear_Percent_Fill = 0;
      }
    }

    if (guard) {
      if ((PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl == 3072) ||
          ((PDG_CGEA_1_2_V2_1_U.AwdRng_D_Actl != 3072) &&
           (PDG_CGEA_1_2_V2_1_U.AwdRngFalt_D_Stat == 512))) {
        /* Transition: '<S4>:168' */
        /* 4x2 High Mode */
        /* Transition: '<S4>:130' */
        /* Simulink Function 'Absolute': '<S4>:158' */
        PDG_CGEA_1_2_V2_1_DWork.input = (uint32_T)rtb_PrplWhlTot_Tq_Actl_filt;

        /* Outputs for Function Call SubSystem: '<S4>/Absolute' */
        PDG_CGEA_1_2_V2_1_Absolute(PDG_CGEA_1_2_V2_1_DWork.input,
          &PDG_CGEA_1_2_V2_1_DWork.Absolute);

        /* End of Outputs for SubSystem: '<S4>/Absolute' */
        rtb_Switch2 = PDG_CGEA_1_2_V2_1_DWork.Absolute.Abs;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = PDG_CGEA_1_2_V2_1_U.veh_v_actleng;
        PDG_CGEA_1_2_V2_1_DWork.input2 =
          PDG_CGEA_1_2_V2_1_U.PG_WHEEL_RPM_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Wheel_RPM = PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.Max_Power =
          PDG_CGEA_1_2_V2_1_U.PG_MAX_POWER_VALUE;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = 0;
        PDG_CGEA_1_2_V2_1_DWork.input2 =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:120' */
        PDG_CGEA_1_2_V2_1_DWork.dividend =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.divisor =
          PDG_CGEA_1_2_V2_1_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
          PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_DWork.Front_Power =
          PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;

        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = rtb_Switch2;
        PDG_CGEA_1_2_V2_1_DWork.input2 = Wheel_RPM;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:120' */
        PDG_CGEA_1_2_V2_1_DWork.dividend =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;
        PDG_CGEA_1_2_V2_1_DWork.divisor =
          PDG_CGEA_1_2_V2_1_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
          PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_2_V2_1_DWork.Rear_Power =
          PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;

        /* Transition: '<S4>:164' */
      } else {
        /* Transition: '<S4>:166' */
      }

      /* Transition: '<S4>:128' */
      if (PDG_CGEA_1_2_V2_1_DWork.Rear_Power > PDG_CGEA_1_2_V2_1_DWork.Max_Power)
      {
        /* Transition: '<S4>:162' */
        /* Transition: '<S4>:160' */
        PDG_CGEA_1_2_V2_1_DWork.Rear_Power = PDG_CGEA_1_2_V2_1_DWork.Max_Power;

        /* Transition: '<S4>:125' */
      } else {
        /* Transition: '<S4>:126' */
      }

      /* Transition: '<S4>:159' */
      if (PDG_CGEA_1_2_V2_1_DWork.Front_Power >
          ((PDG_CGEA_1_2_V2_1_DWork.Rear_Power *
            PDG_CGEA_1_2_V2_1_U.PG_POWER_MULTIPLIER) >> 9)) {
        /* Transition: '<S4>:124' */
        /* Transition: '<S4>:123' */
        /* Simulink Function 'Multiply': '<S4>:111' */
        PDG_CGEA_1_2_V2_1_DWork.input1 = PDG_CGEA_1_2_V2_1_DWork.Rear_Power;
        PDG_CGEA_1_2_V2_1_DWork.input2 = PDG_CGEA_1_2_V2_1_U.PG_POWER_MULTIPLIER;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
          PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_2_V2_1_DWork.Front_Power =
          PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;

        /* Transition: '<S4>:153' */
      } else {
        /* Transition: '<S4>:155' */
      }

      /* Transition: '<S4>:122' */
      rtb_Switch2 = PDG_CGEA_1_2_V2_1_DWork.Front_Power;

      /* Simulink Function 'Multiply': '<S4>:111' */
      PDG_CGEA_1_2_V2_1_DWork.input1 = PDG_CGEA_1_2_V2_1_DWork.Max_Power;
      PDG_CGEA_1_2_V2_1_DWork.input2 =
        PDG_CGEA_1_2_V2_1_U.PG_PERCENT_FILL_CONV_CONSTANT;

      /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
      PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
        PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

      /* End of Outputs for SubSystem: '<S4>/Multiply' */

      /* Simulink Function 'Divide': '<S4>:120' */
      PDG_CGEA_1_2_V2_1_DWork.dividend = rtb_Switch2;
      PDG_CGEA_1_2_V2_1_DWork.divisor =
        PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;

      /* Outputs for Function Call SubSystem: '<S4>/Divide' */
      PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
        PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

      /* End of Outputs for SubSystem: '<S4>/Divide' */
      rtb_Front_Percent_Fill = PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;
      rtb_Switch2 = PDG_CGEA_1_2_V2_1_DWork.Rear_Power;

      /* Simulink Function 'Multiply': '<S4>:111' */
      PDG_CGEA_1_2_V2_1_DWork.input1 = PDG_CGEA_1_2_V2_1_DWork.Max_Power;
      PDG_CGEA_1_2_V2_1_DWork.input2 =
        PDG_CGEA_1_2_V2_1_U.PG_PERCENT_FILL_CONV_CONSTANT;

      /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
      PDG_CGEA_1_2_V2_1_Multiply(PDG_CGEA_1_2_V2_1_DWork.input1,
        PDG_CGEA_1_2_V2_1_DWork.input2, &PDG_CGEA_1_2_V2_1_DWork.Multiply);

      /* End of Outputs for SubSystem: '<S4>/Multiply' */

      /* Simulink Function 'Divide': '<S4>:120' */
      PDG_CGEA_1_2_V2_1_DWork.dividend = rtb_Switch2;
      PDG_CGEA_1_2_V2_1_DWork.divisor =
        PDG_CGEA_1_2_V2_1_DWork.Multiply.Multiply;

      /* Outputs for Function Call SubSystem: '<S4>/Divide' */
      PDG_CGEA_1_2_V2_1_Divide(PDG_CGEA_1_2_V2_1_DWork.dividend,
        PDG_CGEA_1_2_V2_1_DWork.divisor, &PDG_CGEA_1_2_V2_1_DWork.Divide);

      /* End of Outputs for SubSystem: '<S4>/Divide' */
      rtb_Rear_Percent_Fill = PDG_CGEA_1_2_V2_1_DWork.Divide.Divide;

      /* Transition: '<S4>:116' */
    }
  } else {
    /* Transition: '<S4>:145' */
    rtb_Front_Percent_Fill = 0;
    rtb_Rear_Percent_Fill = 0;

    /* Transition: '<S4>:151' */
  }

  /* End of Chart: '<S1>/PDG' */

  /* Outport: '<Root>/PG_front_percent_fill' */
  PDG_CGEA_1_2_V2_1_Y.PG_front_percent_fill = rtb_Front_Percent_Fill;

  /* Outport: '<Root>/PG_rear_percent_fill' */
  PDG_CGEA_1_2_V2_1_Y.PG_rear_percent_fill = rtb_Rear_Percent_Fill;

  /* Update for UnitDelay: '<S5>/PGTorqueDecayUnit Delay' */
  PDG_CGEA_1_2_V2_1_DWork.PGTorqueDecayUnitDelay_DSTATE =
    rtb_PrplWhlTot_Tq_Actl_filt;

  /* Update for UnitDelay: '<S12>/TcFilterUnit Delay' */
  PDG_CGEA_1_2_V2_1_DWork.TcFilterUnitDelay_DSTATE = rtb_PrplWhlTot_Tq_Actl_filt;

  /* Update for UnitDelay: '<S2>/DynamicPoleUD' */
  PDG_CGEA_1_2_V2_1_DWork.DynamicPoleUD_DSTATE = rtb_DynamicPoleSum;
}

/* Model initialize function */
void PDG_CGEA_1_2_V2_1_initialize(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
