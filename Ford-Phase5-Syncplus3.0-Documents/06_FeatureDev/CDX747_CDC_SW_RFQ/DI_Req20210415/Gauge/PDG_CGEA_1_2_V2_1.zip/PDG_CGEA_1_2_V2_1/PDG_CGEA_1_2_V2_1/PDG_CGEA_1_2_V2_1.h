/*
 * File: PDG_CGEA_1_2_V2_1.h
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V2_1'.
 *
 * Model version                  : 1.1177
 * Simulink Coder version         : 8.4 (R2013a) 13-Feb-2013
 * TLC version                    : 8.4 (Jan 19 2013)
 * C/C++ source code generated on : Tue Jul 08 13:12:02 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (8), Warnings (2), Error (0)
 */

#ifndef RTW_HEADER_PDG_CGEA_1_2_V2_1_h_
#define RTW_HEADER_PDG_CGEA_1_2_V2_1_h_
#ifndef PDG_CGEA_1_2_V2_1_COMMON_INCLUDES_
# define PDG_CGEA_1_2_V2_1_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* PDG_CGEA_1_2_V2_1_COMMON_INCLUDES_ */

#include "PDG_CGEA_1_2_V2_1_types.h"

/* Macros for accessing real-time model data structure */

/* Block signals and states (auto storage) for system '<S4>/Multiply' */
typedef struct {
  int32_T Multiply;                    /* '<S9>/Multiply' */
} rtDW_Multiply_PDG_CGEA_1_2_V2_1;

/* Block signals and states (auto storage) for system '<S4>/Absolute' */
typedef struct {
  int32_T Abs;                         /* '<S7>/Abs' */
} rtDW_Absolute_PDG_CGEA_1_2_V2_1;

/* Block signals and states (auto storage) for system '<S4>/Divide' */
typedef struct {
  int32_T Divide;                      /* '<S8>/Divide' */
} rtDW_Divide_PDG_CGEA_1_2_V2_1;

/* Block signals and states (auto storage) for system '<Root>' */
typedef struct {
  rtDW_Divide_PDG_CGEA_1_2_V2_1 Divide;/* '<S4>/Divide' */
  rtDW_Absolute_PDG_CGEA_1_2_V2_1 Absolute;/* '<S4>/Absolute' */
  rtDW_Multiply_PDG_CGEA_1_2_V2_1 Multiply;/* '<S4>/Multiply' */
  int32_T output;                      /* '<S5>/DynamicSwitch' */
  int32_T input1;                      /* '<S1>/PDG' */
  int32_T input2;                      /* '<S1>/PDG' */
  int32_T dividend;                    /* '<S1>/PDG' */
  int32_T divisor;                     /* '<S1>/PDG' */
  int32_T PGTorqueDecayUnitDelay_DSTATE;/* '<S5>/PGTorqueDecayUnit Delay' */
  int32_T TcFilterUnitDelay_DSTATE;    /* '<S12>/TcFilterUnit Delay' */
  int32_T DynamicPoleUD_DSTATE;        /* '<S2>/DynamicPoleUD' */
  int32_T Front_Power;                 /* '<S1>/PDG' */
  int32_T Max_Power;                   /* '<S1>/PDG' */
  int32_T Rear_Power;                  /* '<S1>/PDG' */
  uint32_T input;                      /* '<S1>/PDG' */
  boolean_T output_h;                  /* '<S3>/DynamicCompare' */
} D_Work_PDG_CGEA_1_2_V2_1;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  int32_T prpwhltot_tq_actl;           /* '<Root>/prpwhltot_tq_actl' */
  int32_T veh_v_actleng;               /* '<Root>/veh_v_actleng' */
  int32_T awdlck_tq_req;               /* '<Root>/awdlck_tq_req' */
  int32_T AwdRng_D_Actl;               /* '<Root>/AwdRng_D_Actl' */
  int32_T AwdRngFalt_D_Stat;           /* '<Root>/AwdRngFalt_D_Stat' */
  int32_T GearLvrPos_D_Actl;           /* '<Root>/GearLvrPos_D_Actl' */
  int32_T PG_MAX_POWER_VALUE;          /* '<Root>/PG_MAX_POWER_VALUE' */
  int32_T PG_WHL_TRQ_FILTER;           /* '<Root>/PG_WHL_TRQ_FILTER' */
  int32_T PG_PERCENT_FILL_CONV_CONSTANT;/* '<Root>/PG_PERCENT_FILL_CONV_CONSTANT' */
  int32_T PG_POWER_CONV_CONSTANT;      /* '<Root>/PG_POWER_CONV_CONSTANT' */
  int32_T PG_POWER_MULTIPLIER;         /* '<Root>/PG_POWER_MULTIPLIER' */
  int32_T PG_REAR_AXLE_RATIO;          /* '<Root>/PG_REAR_AXLE_RATIO' */
  int32_T PG_WHEEL_RPM_CONV_CONSTANT;  /* '<Root>/PG_WHEEL_RPM_CONV_CONSTANT' */
  int32_T PG_DECAY_RISING;             /* '<Root>/PG_DECAY_RISING' */
  int32_T PG_DECAY_FALLING_HI_TORQ;    /* '<Root>/PG_DECAY_FALLING_HI_TORQ' */
  int32_T PG_PT_TORQUE_MAX;            /* '<Root>/PG_PT_TORQUE_MAX' */
  int32_T PG_DECAY_FALLING_LO_TORQ;    /* '<Root>/PG_DECAY_FALLING_LO_TORQ' */
  int32_T PG_PRPLWHL_TQ_LOW_LIMIT;     /* '<Root>/PG_PRPLWHL_TQ_LOW_LIMIT' */
  int32_T PG_DECAY_FALLING_SWITCHPOINT;/* '<Root>/PG_DECAY_FALLING_SWITCHPOINT' */
} ExternalInputs_PDG_CGEA_1_2_V2_;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  int32_T PG_front_percent_fill;       /* '<Root>/PG_front_percent_fill' */
  int32_T PG_rear_percent_fill;        /* '<Root>/PG_rear_percent_fill' */
} ExternalOutputs_PDG_CGEA_1_2_V2;

/* Block signals and states (auto storage) */
extern D_Work_PDG_CGEA_1_2_V2_1 PDG_CGEA_1_2_V2_1_DWork;

/* External inputs (root inport signals with auto storage) */
extern ExternalInputs_PDG_CGEA_1_2_V2_ PDG_CGEA_1_2_V2_1_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExternalOutputs_PDG_CGEA_1_2_V2 PDG_CGEA_1_2_V2_1_Y;

/* Model entry point functions */
extern void PDG_CGEA_1_2_V2_1_initialize(void);
extern void PDG_CGEA_1_2_V2_1_step(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PDG_CGEA_1_2_V2_1'
 * '<S1>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge'
 * '<S2>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/Dynamic Pole'
 * '<S3>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/Engine_Brake_Logic'
 * '<S4>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/PDG'
 * '<S5>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/PG Torque Decay'
 * '<S6>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/Engine_Brake_Logic/DynamicCompare'
 * '<S7>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/PDG/Absolute'
 * '<S8>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/PDG/Divide'
 * '<S9>'   : 'PDG_CGEA_1_2_V2_1/Power Gauge/PDG/Multiply'
 * '<S10>'  : 'PDG_CGEA_1_2_V2_1/Power Gauge/PG Torque Decay/DynamicSwitch'
 * '<S11>'  : 'PDG_CGEA_1_2_V2_1/Power Gauge/PG Torque Decay/Saturation Dynamic'
 * '<S12>'  : 'PDG_CGEA_1_2_V2_1/Power Gauge/PG Torque Decay/TC filter'
 */
#endif                                 /* RTW_HEADER_PDG_CGEA_1_2_V2_1_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
