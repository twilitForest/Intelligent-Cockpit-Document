/*
 * File: PDG_CGEA_1_2_V2_1_types.h
 *
 * Code generated for Simulink model 'PDG_CGEA_1_2_V2_1'.
 *
 * Model version                  : 1.1177
 * Simulink Coder version         : 8.4 (R2013a) 13-Feb-2013
 * TLC version                    : 8.4 (Jan 19 2013)
 * C/C++ source code generated on : Tue Jul 08 13:12:02 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. MISRA-C:2004 guidelines
 *    2. Execution efficiency
 * Validation result: Passed (8), Warnings (2), Error (0)
 */

#ifndef RTW_HEADER_PDG_CGEA_1_2_V2_1_types_h_
#define RTW_HEADER_PDG_CGEA_1_2_V2_1_types_h_
#endif                                 /* RTW_HEADER_PDG_CGEA_1_2_V2_1_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
