/*
 * File: PDG_CGEA_1_3_V_4_types.h
 *
 * Code generated for Simulink model 'PDG_CGEA_1_3_V_4'.
 *
 * Model version                  : 1.1162
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * C/C++ source code generated on : Wed Jul 01 15:44:05 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. ROM efficiency
 *    2. RAM efficiency
 *    3. Execution efficiency
 *    4. MISRA-C:2004 guidelines
 * Validation result: Passed (10), Warnings (4), Error (0)
 */

#ifndef RTW_HEADER_PDG_CGEA_1_3_V_4_types_h_
#define RTW_HEADER_PDG_CGEA_1_3_V_4_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct P_PDG_CGEA_1_3_V_4_T_ P_PDG_CGEA_1_3_V_4_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_PDG_CGEA_1_3_V_4_T RT_MODEL_PDG_CGEA_1_3_V_4_T;

#endif                                 /* RTW_HEADER_PDG_CGEA_1_3_V_4_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
