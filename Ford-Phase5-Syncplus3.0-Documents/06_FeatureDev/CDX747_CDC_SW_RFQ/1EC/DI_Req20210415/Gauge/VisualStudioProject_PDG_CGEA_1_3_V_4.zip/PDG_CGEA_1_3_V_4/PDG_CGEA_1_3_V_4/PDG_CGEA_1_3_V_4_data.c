/*
 * File: PDG_CGEA_1_3_V_4_data.c
 *
 * Code generated for Simulink model 'PDG_CGEA_1_3_V_4'.
 *
 * Model version                  : 1.1162
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * C/C++ source code generated on : Wed Jul 01 15:44:05 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. ROM efficiency
 *    2. RAM efficiency
 *    3. Execution efficiency
 *    4. MISRA-C:2004 guidelines
 * Validation result: Passed (10), Warnings (4), Error (0)
 */

#include "PDG_CGEA_1_3_V_4.h"
#include "PDG_CGEA_1_3_V_4_private.h"

/* Block parameters (auto storage) */
P_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_P = {
  0,                                   /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S3>/Constant'
                                        */
  0,                                   /* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S5>/Unit Delay'
                                        */
  0,                                   /* Computed Parameter: PGTorqueDecayConstant_Value
                                        * Referenced by: '<S5>/PGTorqueDecayConstant'
                                        */
  0,                                   /* Computed Parameter: rising_or_falling_Threshold
                                        * Referenced by: '<S5>/rising_or_falling'
                                        */
  0,                                   /* Computed Parameter: UnitDelay_InitialCondition_e
                                        * Referenced by: '<S12>/Unit Delay'
                                        */
  0,                                   /* Computed Parameter: DynamicPoleUD_InitialCondition
                                        * Referenced by: '<S2>/DynamicPoleUD'
                                        */
  51200,                               /* Computed Parameter: FrontSaturation_UpperSat
                                        * Referenced by: '<S1>/Front Saturation'
                                        */
  0,                                   /* Computed Parameter: FrontSaturation_LowerSat
                                        * Referenced by: '<S1>/Front Saturation'
                                        */
  51200,                               /* Computed Parameter: RearSaturation_UpperSat
                                        * Referenced by: '<S1>/Rear Saturation'
                                        */
  0                                    /* Computed Parameter: RearSaturation_LowerSat
                                        * Referenced by: '<S1>/Rear Saturation'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
