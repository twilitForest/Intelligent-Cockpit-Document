/*
 * File: PDG_CGEA_1_3_V_4.c
 *
 * Code generated for Simulink model 'PDG_CGEA_1_3_V_4'.
 *
 * Model version                  : 1.1162
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * C/C++ source code generated on : Wed Jul 01 15:44:05 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. ROM efficiency
 *    2. RAM efficiency
 *    3. Execution efficiency
 *    4. MISRA-C:2004 guidelines
 * Validation result: Passed (10), Warnings (4), Error (0)
 */

#include "PDG_CGEA_1_3_V_4.h"
#include "PDG_CGEA_1_3_V_4_private.h"

/* Block signals (auto storage) */
B_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_B;

/* Block states (auto storage) */
DW_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_Y;

/* Real-time model */
RT_MODEL_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_M_;
RT_MODEL_PDG_CGEA_1_3_V_4_T *const PDG_CGEA_1_3_V_4_M = &PDG_CGEA_1_3_V_4_M_;
int32_T div_repeat_s32(int32_T numerator, int32_T denominator, uint32_T
  nRepeatSub)
{
  int32_T quotient;
  uint32_T tempAbsQuotient;
  if (denominator == 0) {
    quotient = numerator >= 0 ? MAX_int32_T : MIN_int32_T;

    /* Divide by zero handler */
  } else {
    tempAbsQuotient = div_nzp_repeat_u32((uint32_T)(numerator >= 0 ? numerator :
      -numerator), (uint32_T)(denominator >= 0 ? denominator : -denominator),
      nRepeatSub);
    quotient = (numerator < 0) != (denominator < 0) ? -(int32_T)tempAbsQuotient :
      (int32_T)tempAbsQuotient;
  }

  return quotient;
}

uint32_T div_nzp_repeat_u32(uint32_T numerator, uint32_T denominator, uint32_T
  nRepeatSub)
{
  uint32_T quotient;
  uint32_T iRepeatSub;
  boolean_T numeratorExtraBit;
  quotient = numerator / denominator;
  numerator %= denominator;
  for (iRepeatSub = 0U; iRepeatSub < nRepeatSub; iRepeatSub++) {
    numeratorExtraBit = (numerator >= 2147483648U);
    numerator <<= 1U;
    quotient <<= 1U;
    if (numeratorExtraBit || (numerator >= denominator)) {
      quotient++;
      numerator -= denominator;
    }
  }

  return quotient;
}

void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                  *ptrOutBitsLo)
{
  uint32_T absIn0;
  uint32_T absIn1;
  uint32_T in0Lo;
  uint32_T in0Hi;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = (uint32_T)(in0 < 0 ? -in0 : in0);
  absIn1 = (uint32_T)(in1 < 0 ? -in1 : in1);
  in0Hi = absIn0 >> 16U;
  in0Lo = absIn0 & 65535U;
  in1Hi = absIn1 >> 16U;
  absIn0 = absIn1 & 65535U;
  productHiLo = in0Hi * absIn0;
  productLoHi = in0Lo * in1Hi;
  absIn0 *= in0Lo;
  absIn1 = 0U;
  in0Lo = (productLoHi << 16U) + absIn0;
  if (in0Lo < absIn0) {
    absIn1 = 1U;
  }

  absIn0 = in0Lo;
  in0Lo += productHiLo << 16U;
  if (in0Lo < absIn0) {
    absIn1++;
  }

  absIn0 = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi) +
    absIn1;
  if (!((in0 == 0) || ((in1 == 0) || ((in0 > 0) == (in1 > 0))))) {
    absIn0 = ~absIn0;
    in0Lo = ~in0Lo;
    in0Lo++;
    if (in0Lo == 0U) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = in0Lo;
}

int32_T mul_s32_s32_s32_sr9(int32_T a, int32_T b)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  u32_clo = u32_chi << 23U | u32_clo >> 9U;
  return (int32_T)u32_clo;
}

int32_T mul_s32_s32_s32_sr9_zero(int32_T a, int32_T b)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  u32_clo = (((int32_T)u32_chi < 0) && ((u32_clo & 511U) != 0U)) + (u32_chi <<
    23U | u32_clo >> 9U);
  return (int32_T)u32_clo;
}

/* Output and update for function-call system: '<S4>/Divide' */
void PDG_CGEA_1_3_V_4_Divide(int32_T rtu_dividend, int32_T rtu_divisor,
  B_Divide_PDG_CGEA_1_3_V_4_T *localB)
{
  /* Product: '<S8>/Divide' */
  localB->Divide = div_repeat_s32(rtu_dividend, rtu_divisor, 9U);
}

/* Output and update for function-call system: '<S4>/Multiply' */
void PDG_CGEA_1_3_V_4_Multiply(int32_T rtu_input1, int32_T rtu_input2,
  B_Multiply_PDG_CGEA_1_3_V_4_T *localB)
{
  /* Product: '<S9>/Multiply' */
  localB->Multiply = mul_s32_s32_s32_sr9(rtu_input1, rtu_input2);
}

/* Output and update for function-call system: '<S4>/Absolute' */
void PDG_CGEA_1_3_V_4_Absolute(int32_T rtu_input, B_Absolute_PDG_CGEA_1_3_V_4_T *
  localB)
{
  /* Abs: '<S7>/Abs' */
  if (rtu_input < 0) {
    localB->Abs = -rtu_input;
  } else {
    localB->Abs = rtu_input;
  }

  /* End of Abs: '<S7>/Abs' */
}

/* Model step function */
void PDG_CGEA_1_3_V_4_step(void)
{
  int32_T Front_Axle_Torque;
  int32_T Rear_Axle_Torque;
  int32_T Wheel_RPM;
  boolean_T guard1 = false;

  /* UnitDelay: '<S5>/Unit Delay' */
  PDG_CGEA_1_3_V_4_B.pg_decay_output_unit_delay =
    PDG_CGEA_1_3_V_4_DW.UnitDelay_DSTATE;

  /* RelationalOperator: '<S11>/LowerRelop1' incorporates:
   *  Inport: '<Root>/PG_PT_TORQUE_MAX'
   *  Inport: '<Root>/prplwhltot_tq_actl'
   */
  PDG_CGEA_1_3_V_4_B.LowerRelop1 = (PDG_CGEA_1_3_V_4_U.prplwhltot_tq_actl >
    PDG_CGEA_1_3_V_4_U.PG_PT_TORQUE_MAX);

  /* RelationalOperator: '<S11>/UpperRelop' incorporates:
   *  Constant: '<S5>/PGTorqueDecayConstant'
   *  Inport: '<Root>/prplwhltot_tq_actl'
   */
  PDG_CGEA_1_3_V_4_B.UpperRelop = (PDG_CGEA_1_3_V_4_U.prplwhltot_tq_actl <
    PDG_CGEA_1_3_V_4_P.PGTorqueDecayConstant_Value);

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S5>/PGTorqueDecayConstant'
   *  Inport: '<Root>/prplwhltot_tq_actl'
   */
  if (PDG_CGEA_1_3_V_4_B.UpperRelop) {
    PDG_CGEA_1_3_V_4_B.Switch = PDG_CGEA_1_3_V_4_P.PGTorqueDecayConstant_Value;
  } else {
    PDG_CGEA_1_3_V_4_B.Switch = PDG_CGEA_1_3_V_4_U.prplwhltot_tq_actl;
  }

  /* End of Switch: '<S11>/Switch' */

  /* Switch: '<S11>/Switch2' incorporates:
   *  Inport: '<Root>/PG_PT_TORQUE_MAX'
   */
  if (PDG_CGEA_1_3_V_4_B.LowerRelop1) {
    PDG_CGEA_1_3_V_4_B.Switch2 = PDG_CGEA_1_3_V_4_U.PG_PT_TORQUE_MAX;
  } else {
    PDG_CGEA_1_3_V_4_B.Switch2 = PDG_CGEA_1_3_V_4_B.Switch;
  }

  /* End of Switch: '<S11>/Switch2' */

  /* Sum: '<S5>/Sum1' */
  Rear_Axle_Torque = PDG_CGEA_1_3_V_4_B.Switch2;
  Front_Axle_Torque = PDG_CGEA_1_3_V_4_B.pg_decay_output_unit_delay;
  Wheel_RPM = Rear_Axle_Torque - Front_Axle_Torque;
  if ((Rear_Axle_Torque < 0) && ((Front_Axle_Torque >= 0) && (Wheel_RPM >= 0)))
  {
    Wheel_RPM = MIN_int32_T;
  } else {
    if ((Rear_Axle_Torque >= 0) && ((Front_Axle_Torque < 0) && (Wheel_RPM < 0)))
    {
      Wheel_RPM = MAX_int32_T;
    }
  }

  PDG_CGEA_1_3_V_4_B.Sum1 = Wheel_RPM;

  /* End of Sum: '<S5>/Sum1' */

  /* Chart: '<S5>/DynamicSwitch' incorporates:
   *  Inport: '<Root>/PG_DECAY_FALLING_HI_TORQ'
   *  Inport: '<Root>/PG_DECAY_FALLING_LO_TORQ'
   *  Inport: '<Root>/PG_DEGA_FALLING_SWITCHPOINT'
   */
  /* Gateway: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* During: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* Entry Internal: Power Gauge/PG Torque Decay/DynamicSwitch */
  /* Transition: '<S10>:12' */
  if (PDG_CGEA_1_3_V_4_B.Switch2 >=
      PDG_CGEA_1_3_V_4_U.PG_DEGA_FALLING_SWITCHPOINT) {
    /* Transition: '<S10>:15' */
    /* Transition: '<S10>:20' */
    PDG_CGEA_1_3_V_4_B.output = PDG_CGEA_1_3_V_4_U.PG_DECAY_FALLING_HI_TORQ;

    /* Transition: '<S10>:24' */
  } else {
    if (PDG_CGEA_1_3_V_4_B.Switch2 <
        PDG_CGEA_1_3_V_4_U.PG_DEGA_FALLING_SWITCHPOINT) {
      /* Transition: '<S10>:16' */
      /* Transition: '<S10>:19' */
      PDG_CGEA_1_3_V_4_B.output = PDG_CGEA_1_3_V_4_U.PG_DECAY_FALLING_LO_TORQ;

      /* Transition: '<S10>:22' */
    }
  }

  /* End of Chart: '<S5>/DynamicSwitch' */

  /* Switch: '<S5>/rising_or_falling' incorporates:
   *  Inport: '<Root>/PG_DECAY_RISING'
   */
  if (PDG_CGEA_1_3_V_4_B.Sum1 >= PDG_CGEA_1_3_V_4_P.rising_or_falling_Threshold)
  {
    PDG_CGEA_1_3_V_4_B.pg_decay_rise_fall_switch =
      PDG_CGEA_1_3_V_4_U.PG_DECAY_RISING;
  } else {
    PDG_CGEA_1_3_V_4_B.pg_decay_rise_fall_switch = PDG_CGEA_1_3_V_4_B.output;
  }

  /* End of Switch: '<S5>/rising_or_falling' */

  /* UnitDelay: '<S12>/Unit Delay' */
  PDG_CGEA_1_3_V_4_B.pre_decay_output_unit_delay =
    PDG_CGEA_1_3_V_4_DW.UnitDelay_DSTATE_o;

  /* Sum: '<S12>/Subtract1' */
  PDG_CGEA_1_3_V_4_B.pg_torque_in_for_tc_filter_minu =
    PDG_CGEA_1_3_V_4_B.pre_decay_output_unit_delay - PDG_CGEA_1_3_V_4_B.Switch2;

  /* Product: '<S12>/Product1' */
  PDG_CGEA_1_3_V_4_B.pg_torque_with_delay_times_tc_i = mul_s32_s32_s32_sr9_zero
    (PDG_CGEA_1_3_V_4_B.pg_decay_rise_fall_switch,
     PDG_CGEA_1_3_V_4_B.pg_torque_in_for_tc_filter_minu);

  /* Sum: '<S12>/Subtract' */
  PDG_CGEA_1_3_V_4_B.PrplWhlTot_Tq_Actl_filt =
    PDG_CGEA_1_3_V_4_B.pre_decay_output_unit_delay -
    PDG_CGEA_1_3_V_4_B.pg_torque_with_delay_times_tc_i;

  /* UnitDelay: '<S2>/DynamicPoleUD' */
  PDG_CGEA_1_3_V_4_B.DynamicPoleYk1 = PDG_CGEA_1_3_V_4_DW.DynamicPoleUD_DSTATE;

  /* Chart: '<S3>/DynamicCompare' incorporates:
   *  Inport: '<Root>/PG_PRPLWHL_TQ_LOW_LIMIT '
   *  Inport: '<Root>/prplwhltot_tq_actl'
   */
  /* Gateway: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* During: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* Entry Internal: Power Gauge/Engine_Brake_Logic/DynamicCompare */
  /* Transition: '<S6>:2' */
  if (PDG_CGEA_1_3_V_4_U.prplwhltot_tq_actl <=
      PDG_CGEA_1_3_V_4_U.PG_PRPLWHL_TQ_LOW_LIMIT) {
    /* Transition: '<S6>:5' */
    /* Transition: '<S6>:13' */
    PDG_CGEA_1_3_V_4_B.output_l = true;

    /* Transition: '<S6>:12' */
  } else {
    if (PDG_CGEA_1_3_V_4_U.prplwhltot_tq_actl >
        PDG_CGEA_1_3_V_4_U.PG_PRPLWHL_TQ_LOW_LIMIT) {
      /* Transition: '<S6>:6' */
      /* Transition: '<S6>:10' */
      PDG_CGEA_1_3_V_4_B.output_l = false;

      /* Transition: '<S6>:11' */
    }
  }

  /* End of Chart: '<S3>/DynamicCompare' */

  /* Switch: '<S3>/Switch' incorporates:
   *  Constant: '<S3>/Constant'
   *  Inport: '<Root>/awdlck_tq_actl'
   */
  if (PDG_CGEA_1_3_V_4_B.output_l) {
    PDG_CGEA_1_3_V_4_B.Switch_a = PDG_CGEA_1_3_V_4_P.Constant_Value;
  } else {
    PDG_CGEA_1_3_V_4_B.Switch_a = PDG_CGEA_1_3_V_4_U.awdlck_tq_actl;
  }

  /* End of Switch: '<S3>/Switch' */

  /* Sum: '<S2>/DynamicPoleDiff' */
  PDG_CGEA_1_3_V_4_B.Yk1Uk = PDG_CGEA_1_3_V_4_B.DynamicPoleYk1 -
    PDG_CGEA_1_3_V_4_B.Switch_a;

  /* Product: '<S2>/DynamicPoleProduct' incorporates:
   *  Inport: '<Root>/PG_WHL_TRQ_FILTER'
   */
  PDG_CGEA_1_3_V_4_B.DynamicPolePoleYk1Uk = mul_s32_s32_s32_sr9
    (PDG_CGEA_1_3_V_4_U.PG_WHL_TRQ_FILTER, PDG_CGEA_1_3_V_4_B.Yk1Uk);

  /* Sum: '<S2>/DynamicPoleSum' */
  PDG_CGEA_1_3_V_4_B.DynamicPoleSum = PDG_CGEA_1_3_V_4_B.DynamicPolePoleYk1Uk +
    PDG_CGEA_1_3_V_4_B.Switch_a;

  /* Chart: '<S1>/PG' incorporates:
   *  Inport: '<Root>/AwdRngeFalt_D_Stat'
   *  Inport: '<Root>/PG_MAX_POWER_VALUE'
   *  Inport: '<Root>/PG_PERCENT_FILL_CONV_CONSTANT'
   *  Inport: '<Root>/PG_POWER_CONV_CONSTANT'
   *  Inport: '<Root>/PG_POWER_MULTIPLIER'
   *  Inport: '<Root>/PG_REAR_AXLE_RATIO'
   *  Inport: '<Root>/PG_WHEEL_RPM_CONV_CONSTANT'
   *  Inport: '<Root>/awdrnge_d_actl'
   *  Inport: '<Root>/veh_v_actleng'
   */
  /* Gateway: Power Gauge/PG */
  /* During: Power Gauge/PG */
  /* Entry Internal: Power Gauge/PG */
  /* Transition: '<S4>:33' */
  if ((PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x0) ||
      (PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x4) ||
      (PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x5) ||
      (PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x6)) {
    /* Transition: '<S4>:12' */
    if (PDG_CGEA_1_3_V_4_U.AwdRngeFalt_D_Stat != 512) {
      /* Transition: '<S4>:30' */
      if (PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x5) {
        /* Transition: '<S4>:15' */
        /* 4x4 Auto Mode */
        /* Transition: '<S4>:9' */
        /* Simulink Function 'Absolute': '<S4>:99' */
        PDG_CGEA_1_3_V_4_B.input = PDG_CGEA_1_3_V_4_B.PrplWhlTot_Tq_Actl_filt;

        /* Outputs for Function Call SubSystem: '<S4>/Absolute' */
        PDG_CGEA_1_3_V_4_Absolute(PDG_CGEA_1_3_V_4_B.input,
          &PDG_CGEA_1_3_V_4_B.Absolute);

        /* End of Outputs for SubSystem: '<S4>/Absolute' */
        Rear_Axle_Torque = PDG_CGEA_1_3_V_4_B.Absolute.Abs;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = PDG_CGEA_1_3_V_4_B.DynamicPoleSum;
        PDG_CGEA_1_3_V_4_B.input2 = PDG_CGEA_1_3_V_4_U.PG_REAR_AXLE_RATIO;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Front_Axle_Torque = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = PDG_CGEA_1_3_V_4_U.veh_v_actleng;
        PDG_CGEA_1_3_V_4_B.input2 =
          PDG_CGEA_1_3_V_4_U.PG_WHEEL_RPM_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Wheel_RPM = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_DW.Max_Power = PDG_CGEA_1_3_V_4_U.PG_MAX_POWER_VALUE;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = Front_Axle_Torque;
        PDG_CGEA_1_3_V_4_B.input2 = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:92' */
        PDG_CGEA_1_3_V_4_B.dividend = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
          PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_DW.Front_Power = PDG_CGEA_1_3_V_4_B.Divide.Divide;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = Rear_Axle_Torque;
        PDG_CGEA_1_3_V_4_B.input2 = Wheel_RPM;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:92' */
        PDG_CGEA_1_3_V_4_B.dividend = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
          PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_DW.Rear_Power = PDG_CGEA_1_3_V_4_B.Divide.Divide;

        /* Transition: '<S4>:17' */
      } else {
        /* Transition: '<S4>:16' */
      }

      /* Transition: '<S4>:18' */
      if ((PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x0) ||
          (PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x4)) {
        /* Transition: '<S4>:19' */
        /* 4x4 High or 4x4 Low Mode */
        /* Transition: '<S4>:27' */
        /* Simulink Function 'Absolute': '<S4>:99' */
        PDG_CGEA_1_3_V_4_B.input = PDG_CGEA_1_3_V_4_B.PrplWhlTot_Tq_Actl_filt;

        /* Outputs for Function Call SubSystem: '<S4>/Absolute' */
        PDG_CGEA_1_3_V_4_Absolute(PDG_CGEA_1_3_V_4_B.input,
          &PDG_CGEA_1_3_V_4_B.Absolute);

        /* End of Outputs for SubSystem: '<S4>/Absolute' */
        Rear_Axle_Torque = PDG_CGEA_1_3_V_4_B.Absolute.Abs;
        Front_Axle_Torque = PDG_CGEA_1_3_V_4_B.Absolute.Abs;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = PDG_CGEA_1_3_V_4_U.veh_v_actleng;
        PDG_CGEA_1_3_V_4_B.input2 =
          PDG_CGEA_1_3_V_4_U.PG_WHEEL_RPM_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Wheel_RPM = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_DW.Max_Power = PDG_CGEA_1_3_V_4_U.PG_MAX_POWER_VALUE;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = Front_Axle_Torque;
        PDG_CGEA_1_3_V_4_B.input2 = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:92' */
        PDG_CGEA_1_3_V_4_B.dividend = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
          PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_DW.Front_Power = PDG_CGEA_1_3_V_4_B.Divide.Divide;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = Rear_Axle_Torque;
        PDG_CGEA_1_3_V_4_B.input2 = Wheel_RPM;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:92' */
        PDG_CGEA_1_3_V_4_B.dividend = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
          PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_DW.Rear_Power = PDG_CGEA_1_3_V_4_B.Divide.Divide;

        /* Transition: '<S4>:25' */
      } else {
        /* Transition: '<S4>:21' */
      }

      /* Transition: '<S4>:11' */
      guard1 = true;
    } else {
      /* Transition: '<S4>:14' */
      if (PDG_CGEA_1_3_V_4_U.AwdRngeFalt_D_Stat == 512) {
        /* Transition: '<S4>:31' */
        guard1 = true;
      } else {
        /* Transition: '<S4>:32' */
        PDG_CGEA_1_3_V_4_B.Front_Percent_Fill = 0;
        PDG_CGEA_1_3_V_4_B.Rear_Percent_Fill = 0;
      }
    }

    if (guard1) {
      if ((PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 == 0x6) ||
          ((PDG_CGEA_1_3_V_4_U.awdrnge_d_actl >> 9 != 0x6) &&
           (PDG_CGEA_1_3_V_4_U.AwdRngeFalt_D_Stat == 512))) {
        /* Transition: '<S4>:4' */
        /* 4x2 High Mode */
        /* Transition: '<S4>:3' */
        /* Simulink Function 'Absolute': '<S4>:99' */
        PDG_CGEA_1_3_V_4_B.input = PDG_CGEA_1_3_V_4_B.PrplWhlTot_Tq_Actl_filt;

        /* Outputs for Function Call SubSystem: '<S4>/Absolute' */
        PDG_CGEA_1_3_V_4_Absolute(PDG_CGEA_1_3_V_4_B.input,
          &PDG_CGEA_1_3_V_4_B.Absolute);

        /* End of Outputs for SubSystem: '<S4>/Absolute' */
        Rear_Axle_Torque = PDG_CGEA_1_3_V_4_B.Absolute.Abs;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = PDG_CGEA_1_3_V_4_U.veh_v_actleng;
        PDG_CGEA_1_3_V_4_B.input2 =
          PDG_CGEA_1_3_V_4_U.PG_WHEEL_RPM_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        Wheel_RPM = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_DW.Max_Power = PDG_CGEA_1_3_V_4_U.PG_MAX_POWER_VALUE;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = 0;
        PDG_CGEA_1_3_V_4_B.input2 = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:92' */
        PDG_CGEA_1_3_V_4_B.dividend = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
          PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_DW.Front_Power = PDG_CGEA_1_3_V_4_B.Divide.Divide;

        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = Rear_Axle_Torque;
        PDG_CGEA_1_3_V_4_B.input2 = Wheel_RPM;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */

        /* Simulink Function 'Divide': '<S4>:92' */
        PDG_CGEA_1_3_V_4_B.dividend = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;
        PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_U.PG_POWER_CONV_CONSTANT;

        /* Outputs for Function Call SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
          PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

        /* End of Outputs for SubSystem: '<S4>/Divide' */
        PDG_CGEA_1_3_V_4_DW.Rear_Power = PDG_CGEA_1_3_V_4_B.Divide.Divide;

        /* Transition: '<S4>:28' */
      } else {
        /* Transition: '<S4>:26' */
      }

      /* Transition: '<S4>:6' */
      if (PDG_CGEA_1_3_V_4_DW.Rear_Power > PDG_CGEA_1_3_V_4_DW.Max_Power) {
        /* Transition: '<S4>:2' */
        /* Transition: '<S4>:23' */
        PDG_CGEA_1_3_V_4_DW.Rear_Power = PDG_CGEA_1_3_V_4_DW.Max_Power;

        /* Transition: '<S4>:7' */
      } else {
        /* Transition: '<S4>:24' */
      }

      /* Transition: '<S4>:22' */
      if (PDG_CGEA_1_3_V_4_DW.Front_Power > (PDG_CGEA_1_3_V_4_DW.Rear_Power *
           PDG_CGEA_1_3_V_4_U.PG_POWER_MULTIPLIER >> 9)) {
        /* Transition: '<S4>:13' */
        /* Transition: '<S4>:8' */
        /* Simulink Function 'Multiply': '<S4>:96' */
        PDG_CGEA_1_3_V_4_B.input1 = PDG_CGEA_1_3_V_4_DW.Rear_Power;
        PDG_CGEA_1_3_V_4_B.input2 = PDG_CGEA_1_3_V_4_U.PG_POWER_MULTIPLIER;

        /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
          PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

        /* End of Outputs for SubSystem: '<S4>/Multiply' */
        PDG_CGEA_1_3_V_4_DW.Front_Power = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;

        /* Transition: '<S4>:29' */
      } else {
        /* Transition: '<S4>:5' */
      }

      /* Transition: '<S4>:20' */
      Rear_Axle_Torque = PDG_CGEA_1_3_V_4_DW.Front_Power;

      /* Simulink Function 'Multiply': '<S4>:96' */
      PDG_CGEA_1_3_V_4_B.input1 = PDG_CGEA_1_3_V_4_DW.Max_Power;
      PDG_CGEA_1_3_V_4_B.input2 =
        PDG_CGEA_1_3_V_4_U.PG_PERCENT_FILL_CONV_CONSTANT;

      /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
      PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
        PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

      /* End of Outputs for SubSystem: '<S4>/Multiply' */

      /* Simulink Function 'Divide': '<S4>:92' */
      PDG_CGEA_1_3_V_4_B.dividend = Rear_Axle_Torque;
      PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;

      /* Outputs for Function Call SubSystem: '<S4>/Divide' */
      PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
        PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

      /* End of Outputs for SubSystem: '<S4>/Divide' */
      PDG_CGEA_1_3_V_4_B.Front_Percent_Fill = PDG_CGEA_1_3_V_4_B.Divide.Divide;
      Rear_Axle_Torque = PDG_CGEA_1_3_V_4_DW.Rear_Power;

      /* Simulink Function 'Multiply': '<S4>:96' */
      PDG_CGEA_1_3_V_4_B.input1 = PDG_CGEA_1_3_V_4_DW.Max_Power;
      PDG_CGEA_1_3_V_4_B.input2 =
        PDG_CGEA_1_3_V_4_U.PG_PERCENT_FILL_CONV_CONSTANT;

      /* Outputs for Function Call SubSystem: '<S4>/Multiply' */
      PDG_CGEA_1_3_V_4_Multiply(PDG_CGEA_1_3_V_4_B.input1,
        PDG_CGEA_1_3_V_4_B.input2, &PDG_CGEA_1_3_V_4_B.Multiply);

      /* End of Outputs for SubSystem: '<S4>/Multiply' */

      /* Simulink Function 'Divide': '<S4>:92' */
      PDG_CGEA_1_3_V_4_B.dividend = Rear_Axle_Torque;
      PDG_CGEA_1_3_V_4_B.divisor = PDG_CGEA_1_3_V_4_B.Multiply.Multiply;

      /* Outputs for Function Call SubSystem: '<S4>/Divide' */
      PDG_CGEA_1_3_V_4_Divide(PDG_CGEA_1_3_V_4_B.dividend,
        PDG_CGEA_1_3_V_4_B.divisor, &PDG_CGEA_1_3_V_4_B.Divide);

      /* End of Outputs for SubSystem: '<S4>/Divide' */
      PDG_CGEA_1_3_V_4_B.Rear_Percent_Fill = PDG_CGEA_1_3_V_4_B.Divide.Divide;

      /* Transition: '<S4>:10' */
    }
  } else {
    /* Transition: '<S4>:34' */
    PDG_CGEA_1_3_V_4_B.Front_Percent_Fill = 0;
    PDG_CGEA_1_3_V_4_B.Rear_Percent_Fill = 0;

    /* Transition: '<S4>:35' */
  }

  /* End of Chart: '<S1>/PG' */

  /* Saturate: '<S1>/Front Saturation' */
  Rear_Axle_Torque = PDG_CGEA_1_3_V_4_B.Front_Percent_Fill;
  Front_Axle_Torque = PDG_CGEA_1_3_V_4_P.FrontSaturation_LowerSat;
  Wheel_RPM = PDG_CGEA_1_3_V_4_P.FrontSaturation_UpperSat;
  if (Rear_Axle_Torque > Wheel_RPM) {
    /* Outport: '<Root>/Front_Percent_Fill' */
    PDG_CGEA_1_3_V_4_Y.Front_Percent_Fill = Wheel_RPM;
  } else if (Rear_Axle_Torque < Front_Axle_Torque) {
    /* Outport: '<Root>/Front_Percent_Fill' */
    PDG_CGEA_1_3_V_4_Y.Front_Percent_Fill = Front_Axle_Torque;
  } else {
    /* Outport: '<Root>/Front_Percent_Fill' */
    PDG_CGEA_1_3_V_4_Y.Front_Percent_Fill = Rear_Axle_Torque;
  }

  /* End of Saturate: '<S1>/Front Saturation' */

  /* Saturate: '<S1>/Rear Saturation' */
  Rear_Axle_Torque = PDG_CGEA_1_3_V_4_B.Rear_Percent_Fill;
  Front_Axle_Torque = PDG_CGEA_1_3_V_4_P.RearSaturation_LowerSat;
  Wheel_RPM = PDG_CGEA_1_3_V_4_P.RearSaturation_UpperSat;
  if (Rear_Axle_Torque > Wheel_RPM) {
    /* Outport: '<Root>/Rear_Percent_Fill' */
    PDG_CGEA_1_3_V_4_Y.Rear_Percent_Fill = Wheel_RPM;
  } else if (Rear_Axle_Torque < Front_Axle_Torque) {
    /* Outport: '<Root>/Rear_Percent_Fill' */
    PDG_CGEA_1_3_V_4_Y.Rear_Percent_Fill = Front_Axle_Torque;
  } else {
    /* Outport: '<Root>/Rear_Percent_Fill' */
    PDG_CGEA_1_3_V_4_Y.Rear_Percent_Fill = Rear_Axle_Torque;
  }

  /* End of Saturate: '<S1>/Rear Saturation' */

  /* Update for UnitDelay: '<S5>/Unit Delay' */
  PDG_CGEA_1_3_V_4_DW.UnitDelay_DSTATE =
    PDG_CGEA_1_3_V_4_B.PrplWhlTot_Tq_Actl_filt;

  /* Update for UnitDelay: '<S12>/Unit Delay' */
  PDG_CGEA_1_3_V_4_DW.UnitDelay_DSTATE_o =
    PDG_CGEA_1_3_V_4_B.PrplWhlTot_Tq_Actl_filt;

  /* Update for UnitDelay: '<S2>/DynamicPoleUD' */
  PDG_CGEA_1_3_V_4_DW.DynamicPoleUD_DSTATE = PDG_CGEA_1_3_V_4_B.DynamicPoleSum;
}

/* Model initialize function */
void PDG_CGEA_1_3_V_4_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(PDG_CGEA_1_3_V_4_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &PDG_CGEA_1_3_V_4_B), 0,
                sizeof(B_PDG_CGEA_1_3_V_4_T));

  /* states (dwork) */
  (void) memset((void *)&PDG_CGEA_1_3_V_4_DW, 0,
                sizeof(DW_PDG_CGEA_1_3_V_4_T));

  /* external inputs */
  (void) memset((void *)&PDG_CGEA_1_3_V_4_U, 0,
                sizeof(ExtU_PDG_CGEA_1_3_V_4_T));

  /* external outputs */
  (void) memset((void *)&PDG_CGEA_1_3_V_4_Y, 0,
                sizeof(ExtY_PDG_CGEA_1_3_V_4_T));

  /* InitializeConditions for UnitDelay: '<S5>/Unit Delay' */
  PDG_CGEA_1_3_V_4_DW.UnitDelay_DSTATE =
    PDG_CGEA_1_3_V_4_P.UnitDelay_InitialCondition;

  /* InitializeConditions for Chart: '<S5>/DynamicSwitch' */
  PDG_CGEA_1_3_V_4_B.output = 0;

  /* InitializeConditions for UnitDelay: '<S12>/Unit Delay' */
  PDG_CGEA_1_3_V_4_DW.UnitDelay_DSTATE_o =
    PDG_CGEA_1_3_V_4_P.UnitDelay_InitialCondition_e;

  /* InitializeConditions for UnitDelay: '<S2>/DynamicPoleUD' */
  PDG_CGEA_1_3_V_4_DW.DynamicPoleUD_DSTATE =
    PDG_CGEA_1_3_V_4_P.DynamicPoleUD_InitialCondition;

  /* InitializeConditions for Chart: '<S3>/DynamicCompare' */
  PDG_CGEA_1_3_V_4_B.output_l = false;

  /* InitializeConditions for Chart: '<S1>/PG' */
  PDG_CGEA_1_3_V_4_DW.Front_Power = 0;
  PDG_CGEA_1_3_V_4_DW.Max_Power = 0;
  PDG_CGEA_1_3_V_4_DW.Rear_Power = 0;
}

/* Model terminate function */
void PDG_CGEA_1_3_V_4_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
