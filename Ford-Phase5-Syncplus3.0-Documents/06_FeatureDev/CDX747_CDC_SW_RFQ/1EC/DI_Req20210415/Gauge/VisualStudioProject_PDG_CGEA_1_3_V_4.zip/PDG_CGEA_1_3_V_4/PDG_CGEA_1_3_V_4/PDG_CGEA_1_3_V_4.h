/*
 * File: PDG_CGEA_1_3_V_4.h
 *
 * Code generated for Simulink model 'PDG_CGEA_1_3_V_4'.
 *
 * Model version                  : 1.1162
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * C/C++ source code generated on : Wed Jul 01 15:44:05 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. ROM efficiency
 *    2. RAM efficiency
 *    3. Execution efficiency
 *    4. MISRA-C:2004 guidelines
 * Validation result: Passed (10), Warnings (4), Error (0)
 */

#ifndef RTW_HEADER_PDG_CGEA_1_3_V_4_h_
#define RTW_HEADER_PDG_CGEA_1_3_V_4_h_
#include <stddef.h>
#include <string.h>
#ifndef PDG_CGEA_1_3_V_4_COMMON_INCLUDES_
# define PDG_CGEA_1_3_V_4_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* PDG_CGEA_1_3_V_4_COMMON_INCLUDES_ */

#include "PDG_CGEA_1_3_V_4_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals for system '<S4>/Divide' */
typedef struct {
  int32_T Divide;                      /* '<S8>/Divide' */
} B_Divide_PDG_CGEA_1_3_V_4_T;

/* Block signals for system '<S4>/Multiply' */
typedef struct {
  int32_T Multiply;                    /* '<S9>/Multiply' */
} B_Multiply_PDG_CGEA_1_3_V_4_T;

/* Block signals for system '<S4>/Absolute' */
typedef struct {
  int32_T Abs;                         /* '<S7>/Abs' */
} B_Absolute_PDG_CGEA_1_3_V_4_T;

/* Block signals (auto storage) */
typedef struct {
  int32_T pg_decay_output_unit_delay;  /* '<S5>/Unit Delay' */
  int32_T Switch;                      /* '<S11>/Switch' */
  int32_T Switch2;                     /* '<S11>/Switch2' */
  int32_T Sum1;                        /* '<S5>/Sum1' */
  int32_T pg_decay_rise_fall_switch;   /* '<S5>/rising_or_falling' */
  int32_T pre_decay_output_unit_delay; /* '<S12>/Unit Delay' */
  int32_T pg_torque_in_for_tc_filter_minu;/* '<S12>/Subtract1' */
  int32_T pg_torque_with_delay_times_tc_i;/* '<S12>/Product1' */
  int32_T PrplWhlTot_Tq_Actl_filt;     /* '<S12>/Subtract' */
  int32_T DynamicPoleYk1;              /* '<S2>/DynamicPoleUD' */
  int32_T Switch_a;                    /* '<S3>/Switch' */
  int32_T Yk1Uk;                       /* '<S2>/DynamicPoleDiff' */
  int32_T DynamicPolePoleYk1Uk;        /* '<S2>/DynamicPoleProduct' */
  int32_T DynamicPoleSum;              /* '<S2>/DynamicPoleSum' */
  int32_T output;                      /* '<S5>/DynamicSwitch' */
  int32_T Front_Percent_Fill;          /* '<S1>/PG' */
  int32_T Rear_Percent_Fill;           /* '<S1>/PG' */
  int32_T dividend;                    /* '<S1>/PG' */
  int32_T divisor;                     /* '<S1>/PG' */
  int32_T input1;                      /* '<S1>/PG' */
  int32_T input2;                      /* '<S1>/PG' */
  int32_T input;                       /* '<S1>/PG' */
  boolean_T LowerRelop1;               /* '<S11>/LowerRelop1' */
  boolean_T UpperRelop;                /* '<S11>/UpperRelop' */
  boolean_T output_l;                  /* '<S3>/DynamicCompare' */
  B_Absolute_PDG_CGEA_1_3_V_4_T Absolute;/* '<S4>/Absolute' */
  B_Multiply_PDG_CGEA_1_3_V_4_T Multiply;/* '<S4>/Multiply' */
  B_Divide_PDG_CGEA_1_3_V_4_T Divide;  /* '<S4>/Divide' */
} B_PDG_CGEA_1_3_V_4_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  int32_T UnitDelay_DSTATE;            /* '<S5>/Unit Delay' */
  int32_T UnitDelay_DSTATE_o;          /* '<S12>/Unit Delay' */
  int32_T DynamicPoleUD_DSTATE;        /* '<S2>/DynamicPoleUD' */
  int32_T Sum1_DWORK1;                 /* '<S5>/Sum1' */
  int32_T Front_Power;                 /* '<S1>/PG' */
  int32_T Max_Power;                   /* '<S1>/PG' */
  int32_T Rear_Power;                  /* '<S1>/PG' */
} DW_PDG_CGEA_1_3_V_4_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  int32_T AwdRngeFalt_D_Stat;          /* '<Root>/AwdRngeFalt_D_Stat' */
  int32_T PG_LIN_FACTOR;               /* '<Root>/PG_LIN_FACTOR' */
  int32_T PG_MAX_POWER_VALUE;          /* '<Root>/PG_MAX_POWER_VALUE' */
  int32_T PG_PERCENT_FILL_CONV_CONSTANT;/* '<Root>/PG_PERCENT_FILL_CONV_CONSTANT' */
  int32_T PG_POWER_CONV_CONSTANT;      /* '<Root>/PG_POWER_CONV_CONSTANT' */
  int32_T PG_POWER_MULTIPLIER;         /* '<Root>/PG_POWER_MULTIPLIER' */
  int32_T PG_REAR_AXLE_RATIO;          /* '<Root>/PG_REAR_AXLE_RATIO' */
  int32_T PG_WHEEL_RPM_CONV_CONSTANT;  /* '<Root>/PG_WHEEL_RPM_CONV_CONSTANT' */
  int32_T prplwhltot_tq_actl;          /* '<Root>/prplwhltot_tq_actl' */
  int32_T veh_v_actleng;               /* '<Root>/veh_v_actleng' */
  int32_T awdlck_tq_actl;              /* '<Root>/awdlck_tq_actl' */
  int32_T awdrnge_d_actl;              /* '<Root>/awdrnge_d_actl' */
  int32_T PG_PT_TORQUE_MAX;            /* '<Root>/PG_PT_TORQUE_MAX' */
  int32_T PG_DECAY_RISING;             /* '<Root>/PG_DECAY_RISING' */
  int32_T PG_DECAY_FALLING_HI_TORQ;    /* '<Root>/PG_DECAY_FALLING_HI_TORQ' */
  int32_T PG_DECAY_FALLING_LO_TORQ;    /* '<Root>/PG_DECAY_FALLING_LO_TORQ' */
  int32_T PG_DEGA_FALLING_SWITCHPOINT; /* '<Root>/PG_DEGA_FALLING_SWITCHPOINT' */
  int32_T PG_WHL_TRQ_FILTER;           /* '<Root>/PG_WHL_TRQ_FILTER' */
  int32_T PG_PRPLWHL_TQ_LOW_LIMIT;     /* '<Root>/PG_PRPLWHL_TQ_LOW_LIMIT ' */
} ExtU_PDG_CGEA_1_3_V_4_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  int32_T Front_Percent_Fill;          /* '<Root>/Front_Percent_Fill' */
  int32_T Rear_Percent_Fill;           /* '<Root>/Rear_Percent_Fill' */
} ExtY_PDG_CGEA_1_3_V_4_T;

/* Parameters (auto storage) */
struct P_PDG_CGEA_1_3_V_4_T_ {
  int32_T Constant_Value;              /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S3>/Constant'
                                        */
  int32_T UnitDelay_InitialCondition;  /* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S5>/Unit Delay'
                                        */
  int32_T PGTorqueDecayConstant_Value; /* Computed Parameter: PGTorqueDecayConstant_Value
                                        * Referenced by: '<S5>/PGTorqueDecayConstant'
                                        */
  int32_T rising_or_falling_Threshold; /* Computed Parameter: rising_or_falling_Threshold
                                        * Referenced by: '<S5>/rising_or_falling'
                                        */
  int32_T UnitDelay_InitialCondition_e;/* Computed Parameter: UnitDelay_InitialCondition_e
                                        * Referenced by: '<S12>/Unit Delay'
                                        */
  int32_T DynamicPoleUD_InitialCondition;/* Computed Parameter: DynamicPoleUD_InitialCondition
                                          * Referenced by: '<S2>/DynamicPoleUD'
                                          */
  int32_T FrontSaturation_UpperSat;    /* Computed Parameter: FrontSaturation_UpperSat
                                        * Referenced by: '<S1>/Front Saturation'
                                        */
  int32_T FrontSaturation_LowerSat;    /* Computed Parameter: FrontSaturation_LowerSat
                                        * Referenced by: '<S1>/Front Saturation'
                                        */
  int32_T RearSaturation_UpperSat;     /* Computed Parameter: RearSaturation_UpperSat
                                        * Referenced by: '<S1>/Rear Saturation'
                                        */
  int32_T RearSaturation_LowerSat;     /* Computed Parameter: RearSaturation_LowerSat
                                        * Referenced by: '<S1>/Rear Saturation'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_PDG_CGEA_1_3_V_4_T {
  const char_T * volatile errorStatus;
};

/* Block parameters (auto storage) */
extern P_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_P;

/* Block signals (auto storage) */
extern B_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_B;

/* Block states (auto storage) */
extern DW_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_PDG_CGEA_1_3_V_4_T PDG_CGEA_1_3_V_4_Y;

/* Model entry point functions */
extern void PDG_CGEA_1_3_V_4_initialize(void);
extern void PDG_CGEA_1_3_V_4_step(void);
extern void PDG_CGEA_1_3_V_4_terminate(void);

/* Real-time Model object */
extern RT_MODEL_PDG_CGEA_1_3_V_4_T *const PDG_CGEA_1_3_V_4_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PDG_CGEA_1_3_V_4'
 * '<S1>'   : 'PDG_CGEA_1_3_V_4/Power Gauge'
 * '<S2>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/Dynamic Pole'
 * '<S3>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/Engine_Brake_Logic'
 * '<S4>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/PG'
 * '<S5>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/PG Torque Decay'
 * '<S6>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/Engine_Brake_Logic/DynamicCompare'
 * '<S7>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/PG/Absolute'
 * '<S8>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/PG/Divide'
 * '<S9>'   : 'PDG_CGEA_1_3_V_4/Power Gauge/PG/Multiply'
 * '<S10>'  : 'PDG_CGEA_1_3_V_4/Power Gauge/PG Torque Decay/DynamicSwitch'
 * '<S11>'  : 'PDG_CGEA_1_3_V_4/Power Gauge/PG Torque Decay/Saturation Dynamic'
 * '<S12>'  : 'PDG_CGEA_1_3_V_4/Power Gauge/PG Torque Decay/TC filter'
 */
#endif                                 /* RTW_HEADER_PDG_CGEA_1_3_V_4_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
