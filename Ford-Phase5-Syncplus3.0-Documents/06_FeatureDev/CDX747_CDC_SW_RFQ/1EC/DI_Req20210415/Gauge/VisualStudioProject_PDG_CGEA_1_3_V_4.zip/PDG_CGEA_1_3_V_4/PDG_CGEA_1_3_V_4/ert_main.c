/*
 * File: ert_main.c
 *
 * Code generated for Simulink model 'PDG_CGEA_1_3_V_4'.
 *
 * Model version                  : 1.1162
 * Simulink Coder version         : 8.7 (R2014b) 08-Sep-2014
 * C/C++ source code generated on : Wed Jul 01 15:12:27 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->Custom
 * Code generation objectives:
 *    1. ROM efficiency
 *    2. RAM efficiency
 *    3. Execution efficiency
 *    4. MISRA-C:2004 guidelines
 * Validation result: Passed (10), Warnings (4), Error (0)
 */

#include <stddef.h>
#include <stdio.h>                     /* This ert_main.c example uses printf/fflush */
#include "PDG_CGEA_1_3_V_4.h"          /* Model's header file */
#include "rtwtypes.h"
#include <math.h>

#define FLOAT2FIXED(input, fractionBits) ((int)((input) * (1 << fractionBits))) 
#define FIXED2DOUBLE(input, fractionBits) (((double)(input)) / (1 << fractionBits))

/*
 * Associating rt_OneStep with a real-time clock or interrupt service routine
 * is what makes the generated code "real-time".  The function rt_OneStep is
 * always associated with the base rate of the model.  Subrates are managed
 * by the base rate from inside the generated code.  Enabling/disabling
 * interrupts and floating point context switches are target specific.  This
 * example code indicates where these should take place relative to executing
 * the generated code step function.  Overrun behavior should be tailored to
 * your application needs.  This example simply sets an error status in the
 * real-time model and returns from rt_OneStep.
 */
void rt_OneStep(void);
void rt_OneStep(void)
{
  static boolean_T OverrunFlag = 0;

  /* Disable interrupts here */

  /* Check for overrun */
  if (OverrunFlag) {
    rtmSetErrorStatus(PDG_CGEA_1_3_V_4_M, "Overrun");
    return;
  }

  OverrunFlag = true;

  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  /* Set model inputs here */

  /* Step the model */
  PDG_CGEA_1_3_V_4_step();

  /* Get model outputs here */

  /* Indicate task complete */
  OverrunFlag = false;

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}





/*
 * The example "main" function illustrates what is required by your
 * application code to initialize, execute, and terminate the generated code.
 * Attaching rt_OneStep to a real-time clock is target specific.  This example
 * illustates how you do this relative to initializing the model.
 */
int_T main(int_T argc, const char *argv[])
{
	FILE * IN;
	FILE * OUT;

	float awdlck_tq_req  	            = 0;
	float AwdRngFalt_D_Stat	            = 0;
	float AwdRng_D_Actl    	            = 0;
	float GearLvrPos_D_Actl	            = 0;
	float prpwhltot_tq_actl	            = 0;
	float veh_v_actleng    	            = 0;
	float PG_LINEARITY_FACTOR           = .6;
	float PG_MAX_POWER_VALUE            = 120;
	float PG_WHL_TRQ_FILTER             = .1;
	float PG_PERCENT_FILL_CONV_CONSTANT = .8;
	float PG_POWER_CONV_CONSTANT        = 32000;
	float PG_POWER_MULTIPLIER           = 1;
	float PG_REAR_AXLE_RATIO		    = 3.73;
	float PG_WHEEL_RPM_CONV_CONSTANT	= 6.64;
	float PG_DECAY_RISING				= 1;
	float PG_DECAY_FALLING_HI_TORQ	    = .6;
	float PG_PT_TORQUE_MAX			    = 4000;
	float PG_DECAY_FALLING_LO_TORQ	    = .6;
	float PG_PRPLWHL_TQ_LOW_LIMIT		= 1;
	float PG_DECAY_FALLING_SWITCHPOINT  = 500;

	float PG_front_percent_fill = 0;
	float PG_rear_percent_fill  = 0;

	/* Initialize model */
	PDG_CGEA_1_3_V_4_initialize();

	/* Attach rt_OneStep to a timer or interrupt service routine with
	* period 0.016 seconds (the model's base sample time) here.  The
	* call syntax for rt_OneStep is
	*
	*  rt_OneStep();
	*/

	//|31|30|29|28|27|26|25|24|23|22|21|20|19|18|17|16|15|14|13|12|11|10|09|08|07|06|05|04|03|02|01|00|
	//          

	PDG_CGEA_1_3_V_4_U.PG_MAX_POWER_VALUE            = FLOAT2FIXED(PG_MAX_POWER_VALUE            , 9);
	PDG_CGEA_1_3_V_4_U.PG_WHL_TRQ_FILTER             = FLOAT2FIXED(PG_WHL_TRQ_FILTER             , 9);
	PDG_CGEA_1_3_V_4_U.PG_PERCENT_FILL_CONV_CONSTANT = FLOAT2FIXED(PG_PERCENT_FILL_CONV_CONSTANT , 9);
	PDG_CGEA_1_3_V_4_U.PG_POWER_CONV_CONSTANT        = FLOAT2FIXED(PG_POWER_CONV_CONSTANT        , 9);
	PDG_CGEA_1_3_V_4_U.PG_POWER_MULTIPLIER           = FLOAT2FIXED(PG_POWER_MULTIPLIER           , 9);
	PDG_CGEA_1_3_V_4_U.PG_REAR_AXLE_RATIO		      = FLOAT2FIXED(PG_REAR_AXLE_RATIO		   	  , 9);
	PDG_CGEA_1_3_V_4_U.PG_WHEEL_RPM_CONV_CONSTANT	  = FLOAT2FIXED(PG_WHEEL_RPM_CONV_CONSTANT	  , 9);
	PDG_CGEA_1_3_V_4_U.PG_DECAY_RISING				  = FLOAT2FIXED(PG_DECAY_RISING				  , 9);
	PDG_CGEA_1_3_V_4_U.PG_DECAY_FALLING_HI_TORQ	  = FLOAT2FIXED(PG_DECAY_FALLING_HI_TORQ	  , 9); 
	PDG_CGEA_1_3_V_4_U.PG_PT_TORQUE_MAX			  = FLOAT2FIXED(PG_PT_TORQUE_MAX			  , 9); 
	PDG_CGEA_1_3_V_4_U.PG_DECAY_FALLING_LO_TORQ	  = FLOAT2FIXED(PG_DECAY_FALLING_LO_TORQ	  , 9); 
	PDG_CGEA_1_3_V_4_U.PG_PRPLWHL_TQ_LOW_LIMIT		  = FLOAT2FIXED(PG_PRPLWHL_TQ_LOW_LIMIT		  , 9);
	PDG_CGEA_1_3_V_4_U.PG_DEGA_FALLING_SWITCHPOINT  = FLOAT2FIXED(PG_DECAY_FALLING_SWITCHPOINT  , 9);

	IN = fopen ("in_WOT_Turn_Tip_TipTurn.csv","r");
	OUT = fopen ("out_WOT_Turn_Tip_TipTurn.csv","w+");

	printf("%f,"  , awdlck_tq_req         );
	printf("%f,"  , AwdRngFalt_D_Stat     );
	printf("%f,"  , AwdRng_D_Actl         );
	printf("%f,"  , GearLvrPos_D_Actl     );
	printf("%f,"  , prpwhltot_tq_actl     );
	printf("%f,"  , veh_v_actleng         );
	printf("%f,"  , PG_front_percent_fill );
	printf("%f\n" , PG_rear_percent_fill  );



	while(fscanf(IN,"%f,%f,%f,%f,%f,%f\n",&(awdlck_tq_req     )
		,&(AwdRngFalt_D_Stat )
		,&(AwdRng_D_Actl     )
		,&(GearLvrPos_D_Actl )
		,&(prpwhltot_tq_actl )
		,&(veh_v_actleng     )) != EOF)
	{



		/* convert numbers to fixed point */

		PDG_CGEA_1_3_V_4_U.awdlck_tq_actl	  =	FLOAT2FIXED(awdlck_tq_req     , 9);
		PDG_CGEA_1_3_V_4_U.AwdRngeFalt_D_Stat =	FLOAT2FIXED(AwdRngFalt_D_Stat , 9);
		PDG_CGEA_1_3_V_4_U.awdrnge_d_actl	  =	FLOAT2FIXED(AwdRng_D_Actl     , 9);
		//PDG_CGEA_1_3_V_4_U.GearLvrPos_D_Actl =	FLOAT2FIXED(GearLvrPos_D_Actl , 9);
		PDG_CGEA_1_3_V_4_U.prplwhltot_tq_actl =	FLOAT2FIXED(prpwhltot_tq_actl , 9);
		PDG_CGEA_1_3_V_4_U.veh_v_actleng	  =	FLOAT2FIXED(veh_v_actleng     , 9);


		/* convert fixed point numbers to float numbers */


		rt_OneStep();

		//awdlck_tq_req         = PDG_CGEA_1_3_V_4_U.awdlck_tq_req        ;
		//AwdRngFalt_D_Stat     = PDG_CGEA_1_3_V_4_U.AwdRngFalt_D_Stat    ;
		//AwdRng_D_Actl         = PDG_CGEA_1_3_V_4_U.AwdRng_D_Actl        ;
		//GearLvrPos_D_Actl     = PDG_CGEA_1_3_V_4_U.GearLvrPos_D_Actl    ;
		//prpwhltot_tq_actl     = PDG_CGEA_1_3_V_4_U.prpwhltot_tq_actl    ;
		//veh_v_actleng         = PDG_CGEA_1_3_V_4_U.veh_v_actleng        ;
		PG_front_percent_fill = pow(FIXED2DOUBLE(PDG_CGEA_1_3_V_4_Y.Front_Percent_Fill,9),PG_LINEARITY_FACTOR)*100	;
		PG_rear_percent_fill  = pow(FIXED2DOUBLE(PDG_CGEA_1_3_V_4_Y.Rear_Percent_Fill,9),PG_LINEARITY_FACTOR)*100	;

		/*printf("%f,"  , awdlck_tq_req         );
		printf("%f,"  , AwdRngFalt_D_Stat     );
		printf("%f,"  , AwdRng_D_Actl         );
		printf("%f,"  , GearLvrPos_D_Actl     );
		printf("%f,"  , prpwhltot_tq_actl     );
		printf("%f,"  , veh_v_actleng         );
		printf("%f,"  , PG_front_percent_fill );
		printf("%f\n" , PG_rear_percent_fill  );*/

		fprintf(OUT,"%f,%f,%d,%f,%f,%d,%f,%f,%d,%f,%f,%d,%f,%f,%d,%f,%f,%d,%d,%f,%d,%f\n" , awdlck_tq_req
																						  , awdlck_tq_req
			                                                                              , PDG_CGEA_1_3_V_4_U.awdlck_tq_actl
																						  , AwdRngFalt_D_Stat
			                                                                              , AwdRngFalt_D_Stat
																                          , PDG_CGEA_1_3_V_4_U.AwdRngeFalt_D_Stat
																						  , AwdRng_D_Actl
			                                                                              , AwdRng_D_Actl
																                          , PDG_CGEA_1_3_V_4_U.awdrnge_d_actl
																						  , GearLvrPos_D_Actl
			                                                                              , GearLvrPos_D_Actl
																                          , 0 //PDG_CGEA_1_3_V_4_U.GearLvrPos_D_Actl
																						  , prpwhltot_tq_actl / 4
			                                                                              , prpwhltot_tq_actl
																                          , PDG_CGEA_1_3_V_4_U.prplwhltot_tq_actl
																						  , veh_v_actleng * 100
			                                                                              , veh_v_actleng
																                          , PDG_CGEA_1_3_V_4_U.veh_v_actleng
																					      , PDG_CGEA_1_3_V_4_Y.Front_Percent_Fill
			                                                                              , PG_front_percent_fill
																					      , PDG_CGEA_1_3_V_4_Y.Rear_Percent_Fill
			                                                                              , PG_rear_percent_fill);
	}

	fclose(IN);
	fclose(OUT);

	//getchar();

	return 0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
