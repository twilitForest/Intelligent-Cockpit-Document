package com.ford.v2isetting.test.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ford.v2isetting.test.MainActivity;
import com.ford.v2isetting.test.R;

public class FunctionNotOPenActivity extends AppCompatActivity implements View.OnClickListener {

    Button confirmBtn;
    ImageButton btnBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_function_not_open);
        confirmBtn = findViewById(R.id.btn_confirm);
        confirmBtn.setOnClickListener(this);
        btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        //回到v2i beta页面
        switch (v.getId()){
            case R.id.btn_confirm:
            case R.id.btn_back:
                startActivity(new Intent(FunctionNotOPenActivity.this, MainActivity.class));
                break;
        }
    }
}
