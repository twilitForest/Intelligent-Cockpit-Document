package com.ford.v2isetting.sdk;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.NonNull;

import com.ford.sync.v2i.V2IActionBean;
import com.ford.sync.v2i.V2ISettingInterface;
import com.ford.sync.v2i.V2ISettingListener;

import java.util.List;

public class V2ISettingManager {
    private static final String TAG = "V2ISettingManager";
    private static volatile V2ISettingManager mInstance = null;
    private Context mContext;

    private ConnectionCallback mCallBack;
    private V2ISettingInterface v2ISettingInterface;
    private IBinder originBinder;

    private IBinder.DeathRecipient deathRecipient = new IBinder.DeathRecipient() {
        @Override
        public void binderDied() {
            Log.i(TAG, "----DeathRecipient  binderDied");
            V2ISettingManager.this.tryReconnectService();
        }

    };


    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.i(TAG, "----onServiceConnected");

            v2ISettingInterface = V2ISettingInterface.Stub.asInterface(iBinder);
            originBinder = iBinder;
            Log.i(TAG, "----mCallBack.onConnect()");
            mCallBack.onConnect();
            try {
                iBinder.linkToDeath(deathRecipient, 0);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.i(TAG, "----onServiceDisconnected");
            if (originBinder != null) {
                originBinder.unlinkToDeath(deathRecipient, 0);
            }
            originBinder = null;
            v2ISettingInterface = null;

            mCallBack.onDisconnect();
            V2ISettingManager.this.tryReconnectService();
        }
    };

    private void attemptToBindService() {
        Log.i(TAG, "----attemptToBindService()");
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.ford.xiaoduos.v2x", "com.ford.xiaoduos.v2x.core.datamerge.settings.aidl.V2iForSettingService"));
        boolean result = mContext.bindService(intent, connection, Context.BIND_AUTO_CREATE);
        if (!result) {
            this.connection.onServiceDisconnected((ComponentName) null);
        }
    }

    private void tryReconnectService() {
        Log.i(TAG, "----tryReconnectService()");
        mHandler.sendMessageDelayed(Message.obtain(), 2000);
    }


    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            V2ISettingManager.this.attemptToBindService();
        }
    };

    public V2ISettingManager(Context context) {
        this.mContext = context;
    }

    /**
     * 获取V2ISettingManager实例
     * @param context 上下文
     * @return V2ISettingManager
     */
    public static V2ISettingManager getInstance(Context context) {
        if (null == mInstance) {
            synchronized (V2ISettingManager.class) {
                if (null == mInstance) {
                    mInstance = new V2ISettingManager(context);
                }
            }
        }
        return mInstance;
    }

    /**
     * 连接V2I服务
     * @param callback 连接callback
     */
    public void connect(ConnectionCallback callback) {
        Log.i(TAG, "----start connect to remote service");
        this.mCallBack = callback;
        attemptToBindService();
    }

    /**
     * 初始化V2I功能
     * @param listener  V2ISettingListener
     */
    public void init(V2ISettingListener listener) {
        Log.i(TAG, "----client init V2ISettingListener");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.init(listener);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 点击车路协同时调用
     */
    public void onV2ISettingPageClick() {
        Log.i(TAG, "----onV2ISettingPageClick enter");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.onV2ISettingPageClick();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 查询设置页面所有option的值
     * @return  设置页面所有option的值
     */
    public List<V2IActionBean> queryV2ISettingList() {
        Log.i(TAG, "----queryV2ISettingList enter ");
        List<V2IActionBean> dataList = null;
        if (v2ISettingInterface != null) {
            try {
                dataList = v2ISettingInterface.queryV2ISettingList();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        return dataList;
    }

    /**
     * 点击setting的每个选项
     * @param actionBean 哪个选项和什么值
     */
    public void onSettingOptionClick(V2IActionBean actionBean) {
        Log.i(TAG, "----onSettingOptionClick enter");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.onSettingOptionClick(actionBean);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 申请试用
     * @param date yyyyMMddHHmmssSSS(24 小时制) UTC时间
     */
    public void requestV2ITrial(String date) {
        Log.i(TAG, "----requestV2ITrial enter");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.requestV2ITrial("0", date);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 更新V2I授权时间
     * @param date yyyyMMddHHmmssSSS(24 小时制) UTC时间
     */
    public void updateV2IAuthDate(String date) {
        Log.i(TAG, "----updateV2IAuthDate enter");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.requestV2ITrial("1", date);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 查询V2I授权时间
     * @return yyyyMMddHHmmssSSS(24 小时制) UTC时间
     */
    public String queryV2IAuthDate(){
        Log.i(TAG, "----queryV2IAuthDate enter");
        String authDate = "";
        if (v2ISettingInterface != null) {
            try {
                authDate = v2ISettingInterface.queryV2IAuthDate();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        return authDate;
    }

    /**
     * 取消申请试用
     */
    public void cancelV2IRequest() {
        Log.i(TAG, "----cancelV2IRequest enter");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.cancelV2IRequest();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 退出试用计划
     */
    public void exitV2ITrial() {
        Log.i(TAG, "----exitV2ITrial enter");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.exitV2ITrial();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 恢复默认设置
     */
    public void restoreDefaultSetting() {
        Log.i(TAG, "----restoreDefaultSetting enter");
        if (v2ISettingInterface != null) {
            try {
                v2ISettingInterface.restoreDefaultSetting();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 收藏V2I
     * @return 是否成功
     */
    public boolean applyV2IFavorite() {
        Log.i(TAG, "----applyV2IFavorite enter");
        boolean result = false;
        if (v2ISettingInterface != null) {
            try {
                result = v2ISettingInterface.applyV2IFavorite();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        Log.i(TAG, "----applyV2IFavorite return result = " + result);
        return result;
    }

    /**
     * 取消收藏V2I
     * @return 是否成功
     */
    public boolean cancelV2IFavorite() {
        Log.i(TAG, "----cancelV2IFavorite enter");
        boolean result = false;
        if (v2ISettingInterface != null) {
            try {
                result = v2ISettingInterface.cancelV2IFavorite();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        Log.i(TAG, "----cancelV2IFavorite return result = " + result);

        return result;
    }

    /**
     * 查询V2I收藏状态
     * @return 0-未收藏 1-已收藏
     */
    public int queryV2IFavoriteState() {
        Log.i(TAG, "----queryV2IFavoriteState enter");
        int queryV2IFavoriteState = 0;
        if (v2ISettingInterface != null) {
            try {
                queryV2IFavoriteState = v2ISettingInterface.queryV2IFavoriteState();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        Log.i(TAG, "----queryV2IFavoriteState return result = " + queryV2IFavoriteState);

        return queryV2IFavoriteState;
    }

    /**
     * 断开V2I连接
     */
    public void disconnect() {
        Log.i(TAG, "----end remote service connection");
        mContext.unbindService(connection);
    }

    public interface ConnectionCallback {
        void onConnect();

        void onDisconnect();
    }
}
