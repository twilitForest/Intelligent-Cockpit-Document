package com.ford.v2isetting.test;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.RemoteException;
import android.widget.Toast;

import com.ford.sync.v2i.SettingPage;
import com.ford.sync.v2i.V2IActionBean;
import com.ford.sync.v2i.V2ISettingListener;
import com.ford.v2isetting.sdk.V2ISettingManager;
import com.ford.v2isetting.test.activity.FunctionNotOPenActivity;
import com.ford.v2isetting.test.activity.NotServiceCityActivity;
import com.ford.v2isetting.test.activity.RequestUnderReviewActivity;
import com.ford.v2isetting.test.activity.RequestV2ITrailActivity;
import com.ford.v2isetting.test.activity.SettingSelectActivity;

import java.io.Serializable;
import java.util.List;

public class SettingApplication extends Application {

    V2ISettingManager settingManager;

    @Override
    public void onCreate() {
        super.onCreate();
        settingManager = V2ISettingManager.getInstance(getApplicationContext());
        connectToService();
    }

    private void connectToService() {
        settingManager.connect(new V2ISettingManager.ConnectionCallback() {
            @Override
            public void onConnect() {
                Constants.IS_CONNECTED = true;
                settingManager.init(new V2ISettingListener.Stub() {
                    @Override
                    public void onPageChange(SettingPage settingPage) throws RemoteException {
                        if (settingPage == SettingPage.REQUEST_V2I_TRAIL) {
                            //显示申请页面
                            if (!isBackground(getApplicationContext())) {
                                Intent intent = new Intent(getApplicationContext(), RequestV2ITrailActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        } else if (settingPage == SettingPage.REQUEST_UNDER_REVIEW_1) {
                            //显示申请中页面 按钮不可点击
                            if (!isBackground(getApplicationContext())) {
                                Intent intent = new Intent(getApplicationContext(), RequestUnderReviewActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.putExtra("clickable",false);
                                startActivity(intent);
                            }
                        } else if (settingPage == SettingPage.REQUEST_UNDER_REVIEW_2) {
                            //显示申请中页面 按钮不可点击
                            if (!isBackground(getApplicationContext())) {
                                Intent intent = new Intent(getApplicationContext(), RequestUnderReviewActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.putExtra("clickable",true);
                                startActivity(intent);
                            }
                        } else if (settingPage == SettingPage.FUNCTION_NOT_OPEN) {
                            //显示初始化，功能尚未开通页面
                            if (!isBackground(getApplicationContext())) {
                                Intent intent = new Intent(getApplicationContext(), FunctionNotOPenActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        } else if (settingPage == SettingPage.NOT_SERVING_CITY) {
                            //显示审核通过-无法使用-不在服务城市页面
                            if (!isBackground(getApplicationContext())) {
                                Intent intent = new Intent(getApplicationContext(), NotServiceCityActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        } else if (settingPage == SettingPage.SETTING_SELECT_PAGE) {
                            //显示审核通过-正常使用-setting选项页面
                            //查询setting选项的值
                            List<V2IActionBean> actionBeanList = settingManager.queryV2ISettingList();
                            if (!isBackground(getApplicationContext())) {
                                Intent intent = new Intent(getApplicationContext(), SettingSelectActivity.class);
                                intent.putExtra("dataList", (Serializable) actionBeanList);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        } else if (settingPage == SettingPage.SHOW_OTHER_PAGE) {
                            //退回首页
                            if (!isBackground(getApplicationContext())) {
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        }
                    }

                    @Override
                    public void onToast(String message) throws RemoteException {
                        new Handler(getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                });
            }

            @Override
            public void onDisconnect() {

            }
        });

    }

    //判断应用是否在前台
    public static boolean isBackground(Context context) {

        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        boolean isBackground = true;

        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.processName.equals(context.getPackageName())) {
                if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED) {
                    isBackground = true;
                } else if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
                        || appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE) {
                    isBackground = false;
                } else {
                    isBackground = true;
                }
            }
        }
        return isBackground;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
//        settingManager.disconnect();
    }
}
