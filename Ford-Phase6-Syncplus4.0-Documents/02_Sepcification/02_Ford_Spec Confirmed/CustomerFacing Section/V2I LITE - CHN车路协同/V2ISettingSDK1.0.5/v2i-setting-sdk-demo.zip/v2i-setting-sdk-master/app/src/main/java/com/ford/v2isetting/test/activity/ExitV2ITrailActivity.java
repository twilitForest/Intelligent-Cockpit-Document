package com.ford.v2isetting.test.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ford.v2isetting.sdk.V2ISettingManager;
import com.ford.v2isetting.test.Constants;
import com.ford.v2isetting.test.R;
import com.ford.v2isetting.test.utils.SpUtils;

public class ExitV2ITrailActivity extends AppCompatActivity implements View.OnClickListener{

    Button exitTrailButton,authDateBtn;
    ImageButton btnBack;
    EditText authDateET;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit_trail);
        exitTrailButton = findViewById(R.id.btn_exit_trial);
        exitTrailButton.setOnClickListener(this);
        btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(this);
        authDateBtn = findViewById(R.id.btn_auth_date);
        authDateBtn.setOnClickListener(this);
        authDateET = findViewById(R.id.ed_auth_date);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_exit_trial:
                V2ISettingManager.getInstance(getApplicationContext()).cancelV2IFavorite();
                V2ISettingManager.getInstance(getApplicationContext()).exitV2ITrial();
                break;
            case R.id.btn_back:
//                startActivity(new Intent(ExitV2ITrailActivity.this,SettingSelectActivity.class));
                finish();
                break;
            case R.id.btn_auth_date:
                V2ISettingManager.getInstance(getApplicationContext()).updateV2IAuthDate(authDateET.getText().toString());
                break;
        }
    }
}
