package com.ford.v2isetting.test;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.ford.v2isetting.sdk.V2ISettingManager;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button v2iBetaBtn,queryAuthDateBtn;
    LinearLayout lyV2I;
    boolean isConnected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        v2iBetaBtn = findViewById(R.id.btn_v2i_button);
        v2iBetaBtn.setOnClickListener(this);
        lyV2I = findViewById(R.id.ly_v2i);
        queryAuthDateBtn = findViewById(R.id.btn_query_auth_date);
        queryAuthDateBtn.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(Constants.IS_CONNECTED){
            int favoriteState = V2ISettingManager.getInstance(getApplicationContext()).queryV2IFavoriteState();
            if(favoriteState == 1){
                runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            lyV2I.setVisibility(View.VISIBLE);
                        }
                    });
            }else if(favoriteState == 0){
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        lyV2I.setVisibility(View.GONE);
                    }
                });
            }
//            boolean isCollected = SpUtils.getInstance(getApplicationContext()).getBoolean(Constants.KEY_COLLECTION, false);
//            if(isCollected){
//                boolean canCollect = V2ISettingManager.getInstance(getApplicationContext()).canShowInFavorite();
//                if(canCollect){
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            lyV2I.setVisibility(View.VISIBLE);
//                        }
//                    });
//                }else {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            lyV2I.setVisibility(View.GONE);
//                        }
//                    });
//                }
//            }else {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        lyV2I.setVisibility(View.GONE);
//                    }
//                });
//            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_v2i_button:
                V2ISettingManager.getInstance(getApplicationContext()).onV2ISettingPageClick();
                break;
            case R.id.btn_query_auth_date:
                String s = V2ISettingManager.getInstance(getApplicationContext()).queryV2IAuthDate();
                queryAuthDateBtn.setText(s);
                break;
        }
    }

}