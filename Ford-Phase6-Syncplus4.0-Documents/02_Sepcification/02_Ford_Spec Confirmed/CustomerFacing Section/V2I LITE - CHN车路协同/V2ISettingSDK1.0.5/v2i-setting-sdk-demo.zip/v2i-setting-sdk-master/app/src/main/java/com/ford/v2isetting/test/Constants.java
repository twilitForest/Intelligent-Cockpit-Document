package com.ford.v2isetting.test;

public class Constants {
    public static final String KEY_COLLECTION = "isCollected";
    public static boolean IS_CONNECTED = false;
}
