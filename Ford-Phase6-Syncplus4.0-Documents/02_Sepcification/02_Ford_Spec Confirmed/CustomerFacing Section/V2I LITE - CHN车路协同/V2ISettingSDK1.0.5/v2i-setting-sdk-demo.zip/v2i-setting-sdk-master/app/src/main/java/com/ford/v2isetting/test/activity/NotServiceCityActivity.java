package com.ford.v2isetting.test.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ford.v2isetting.sdk.V2ISettingManager;
import com.ford.v2isetting.test.MainActivity;
import com.ford.v2isetting.test.R;

public class NotServiceCityActivity extends AppCompatActivity implements View.OnClickListener {

    Button exitTrailButton;
    ImageButton btnBack;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_not_service_city);
        exitTrailButton = findViewById(R.id.btn_exit_trial);
        exitTrailButton.setOnClickListener(this);
        btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_exit_trial:
                V2ISettingManager.getInstance(getApplicationContext()).cancelV2IFavorite();
                V2ISettingManager.getInstance(getApplicationContext()).exitV2ITrial();
                break;
            case R.id.btn_back:
                startActivity(new Intent(NotServiceCityActivity.this, MainActivity.class));
                finish();
                break;
        }
    }
}
