package com.ford.sync.v2i;

import android.os.Parcel;
import android.os.Parcelable;

public enum SettingPage implements Parcelable {
    /**
     * S0000-1 服务初始化
     */
    FUNCTION_NOT_OPEN,

    /**
     * S0007 无法使用（通过申请）
     */
    NOT_SERVING_CITY,

    /**
     * S0002 车路协同系统使用申请流程
     */
    REQUEST_V2I_TRAIL,

    /**
     * S0004-1 申请中 (取消申请试用按钮置灰不可点击)
     */
    REQUEST_UNDER_REVIEW_1,

    /**
     * S0004-2 申请中 (取消申请试用按钮可点击)
     */
    REQUEST_UNDER_REVIEW_2,

    /**
     * S0101 设置页面
     */
    SETTING_SELECT_PAGE,

    /**
     * S0001-1 车辆控制-常用设置页面
     */
    SHOW_OTHER_PAGE;


    public static final Creator<SettingPage> CREATOR = new Creator<SettingPage>() {
        @Override
        public SettingPage createFromParcel(Parcel in) {
            return SettingPage.values()[in.readInt()];
        }

        @Override
        public SettingPage[] newArray(int size) {
            return new SettingPage[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(ordinal());
    }

    public void readFromParcel(Parcel in){
        in.readInt();
    }
}
