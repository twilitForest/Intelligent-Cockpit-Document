package com.ford.v2isetting.test.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class DialogUtils {
    public static void showSingleAlertDialog(Context context, String[] items, String title,final OnSingleSelectListener listener) {

        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
        alertBuilder.setTitle(title);
        alertBuilder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                listener.onSelected(i, items[i]);
                dialogInterface.dismiss();
            }
        }).create().show();
    }

    public interface OnSingleSelectListener {
        /*
         * 选中的item
         * */
        void onSelected(int index, String item);
    }
}
