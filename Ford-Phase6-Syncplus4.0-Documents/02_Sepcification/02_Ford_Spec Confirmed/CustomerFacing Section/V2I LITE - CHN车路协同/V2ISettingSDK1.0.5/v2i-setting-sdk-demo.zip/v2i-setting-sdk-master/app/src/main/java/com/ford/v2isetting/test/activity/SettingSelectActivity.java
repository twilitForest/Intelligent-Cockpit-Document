package com.ford.v2isetting.test.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ford.sync.v2i.Action;
import com.ford.sync.v2i.V2IActionBean;
import com.ford.v2isetting.sdk.V2ISettingManager;
import com.ford.v2isetting.test.MainActivity;
import com.ford.v2isetting.test.R;
import com.ford.v2isetting.test.utils.DialogUtils;

import java.util.List;

public class SettingSelectActivity extends AppCompatActivity implements View.OnClickListener {

    Switch onOff;
    Button restoreDefaultSetting;
    EditText tliSenEd, glosaEd, glnEd, rlvwEd, rsiEd, voiceEd, floatingEd;
    LinearLayout settingDetailLy;
    ImageButton btnBack, btnTips, btnCollect;
    private String[] tliArrays = {"距离远", "距离近", "关闭"};
    private String[] commonArrays = {"开启", "关闭"};
    private String[] glnArrays = {"灵敏度8秒", "灵敏度5秒", "灵敏度3秒", "关闭"};
    private String[] rlvwArrays = {"灵敏度高", "灵敏度低", "关闭"};
    private String[] voiceArrays = {"详细", "简洁", "关闭"};

    V2ISettingManager settingManager;
    int favoriteState;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_select);
        settingManager = V2ISettingManager.getInstance(getApplicationContext());
        initView();
        initData();
    }

    private void initView() {
        onOff = findViewById(R.id.switch_on_off);
        onOff.setChecked(true);
        onOff.setOnCheckedChangeListener(new MyCheckedListener());
        restoreDefaultSetting = findViewById(R.id.btn_restore_default);
        restoreDefaultSetting.setOnClickListener(this);
        settingDetailLy = findViewById(R.id.ly_setting_detail);

        tliSenEd = findViewById(R.id.ed_tli);
        glosaEd = findViewById(R.id.ed_glosa);
        glnEd = findViewById(R.id.ed_gln);
        rlvwEd = findViewById(R.id.ed_rlvw);
        rsiEd = findViewById(R.id.ed_rsi);
        voiceEd = findViewById(R.id.ed_voice);
        floatingEd = findViewById(R.id.ed_floating);
        btnBack = findViewById(R.id.btn_back);
        btnTips = findViewById(R.id.btn_tips);
        btnCollect = findViewById(R.id.btn_collect);

        tliSenEd.setOnClickListener(this);
        glosaEd.setOnClickListener(this);
        glnEd.setOnClickListener(this);
        rlvwEd.setOnClickListener(this);
        rsiEd.setOnClickListener(this);
        voiceEd.setOnClickListener(this);
        floatingEd.setOnClickListener(this);
        btnBack.setOnClickListener(this);
        btnTips.setOnClickListener(this);
        btnCollect.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        favoriteState = V2ISettingManager.getInstance(getApplicationContext()).queryV2IFavoriteState();
        if (favoriteState == 1) {
            btnCollect.setImageDrawable(getResources().getDrawable(R.mipmap.ic_collected));
        } else if (favoriteState == 0) {
            btnCollect.setImageDrawable(getResources().getDrawable(R.mipmap.ic_collect));
        }
    }

    private void initData() {
        List<V2IActionBean> dataList = (List<V2IActionBean>) getIntent().getSerializableExtra("dataList");
        if (dataList != null) {
            if (dataList.size() == 1) {
                onOff.setChecked(false);
                settingDetailLy.setVisibility(View.GONE);
            } else {
                for (V2IActionBean actionBean : dataList) {
                    Action action = actionBean.getAction();
                    int selectIndex;
                    if (action == Action.ACTION_V2I_ON_OFF) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 1) {
                            onOff.setChecked(true);
                        } else {
                            onOff.setChecked(false);
                        }
                    } else if (action == Action.ACTION_TLI_SENSITIVITY) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 0) {
                            tliSenEd.setText("距离远");
                        } else if (selectIndex == 1) {
                            tliSenEd.setText("距离近");
                        } else if (selectIndex == 2) {
                            tliSenEd.setText("关闭");
                        }

                    } else if (action == Action.ACTION_GLOSA_ON_OFF) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 0) {
                            glosaEd.setText("开启");
                        } else if (selectIndex == 1) {
                            glosaEd.setText("关闭");
                        }

                    } else if (action == Action.ACTION_GLN_SENSITIVITY) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 0) {
                            glnEd.setText("灵敏度8秒");
                        } else if (selectIndex == 1) {
                            glnEd.setText("灵敏度5秒");
                        } else if (selectIndex == 2) {
                            glnEd.setText("灵敏度3秒");
                        } else if (selectIndex == 3) {
                            glnEd.setText("关闭");
                        }

                    } else if (action == Action.ACTION_RLVW_SENSITIVITY) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 0) {
                            rlvwEd.setText("灵敏度高");
                        } else if (selectIndex == 1) {
                            rlvwEd.setText("灵敏度低");
                        } else if (selectIndex == 2) {
                            rlvwEd.setText("关闭");
                        }

                    } else if (action == Action.ACTION_RSI_ON_OFF) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 0) {
                            rsiEd.setText("开启");
                        } else if (selectIndex == 1) {
                            rsiEd.setText("关闭");
                        }

                    } else if (action == Action.ACTION_VOICE_SETTING) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 0) {
                            voiceEd.setText("详细");
                        } else if (selectIndex == 1) {
                            voiceEd.setText("简洁");
                        } else if (selectIndex == 2) {
                            voiceEd.setText("关闭");
                        }

                    } else if (action == Action.ACTION_GLOBAL_OVERLAY_ON_OFF) {
                        selectIndex = actionBean.getSelectIndex();
                        if (selectIndex == 0) {
                            floatingEd.setText("开启");
                        } else if (selectIndex == 1) {
                            floatingEd.setText("关闭");
                        }
                    }
                }
            }
        }
    }


    class MyCheckedListener implements CompoundButton.OnCheckedChangeListener {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                settingDetailLy.setVisibility(View.VISIBLE);
                V2IActionBean actionBean = new V2IActionBean(Action.ACTION_V2I_ON_OFF, 1);
                settingManager.onSettingOptionClick(actionBean);
            } else {
                settingDetailLy.setVisibility(View.GONE);
                V2IActionBean actionBean = new V2IActionBean(Action.ACTION_V2I_ON_OFF, 0);
                settingManager.onSettingOptionClick(actionBean);
            }
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ed_tli:
                DialogUtils.showSingleAlertDialog(SettingSelectActivity.this, tliArrays, "接收红绿灯信号", new DialogUtils.OnSingleSelectListener() {
                    @Override
                    public void onSelected(int index, String item) {
                        tliSenEd.setText(item);
                        V2IActionBean actionBean = new V2IActionBean(Action.ACTION_TLI_SENSITIVITY, index);
                        settingManager.onSettingOptionClick(actionBean);
                    }
                });
                break;
            case R.id.ed_glosa:
                DialogUtils.showSingleAlertDialog(SettingSelectActivity.this, commonArrays, "绿波引导", new DialogUtils.OnSingleSelectListener() {
                    @Override
                    public void onSelected(int index, String item) {
                        glosaEd.setText(item);
                        V2IActionBean actionBean = new V2IActionBean(Action.ACTION_GLOSA_ON_OFF, index);
                        settingManager.onSettingOptionClick(actionBean);
                    }
                });
                break;
            case R.id.ed_gln:
                DialogUtils.showSingleAlertDialog(SettingSelectActivity.this, glnArrays, "绿灯起步提醒", new DialogUtils.OnSingleSelectListener() {
                    @Override
                    public void onSelected(int index, String item) {
                        glnEd.setText(item);
                        V2IActionBean actionBean = new V2IActionBean(Action.ACTION_GLN_SENSITIVITY, index);
                        settingManager.onSettingOptionClick(actionBean);
                    }
                });
                break;
            case R.id.ed_rlvw:
                DialogUtils.showSingleAlertDialog(SettingSelectActivity.this, rlvwArrays, "闯红灯预警", new DialogUtils.OnSingleSelectListener() {
                    @Override
                    public void onSelected(int index, String item) {
                        rlvwEd.setText(item);
                        V2IActionBean actionBean = new V2IActionBean(Action.ACTION_RLVW_SENSITIVITY, index);
                        settingManager.onSettingOptionClick(actionBean);
                    }
                });
                break;
            case R.id.ed_rsi:
                DialogUtils.showSingleAlertDialog(SettingSelectActivity.this, commonArrays, "道路信息广播", new DialogUtils.OnSingleSelectListener() {
                    @Override
                    public void onSelected(int index, String item) {
                        rsiEd.setText(item);
                        V2IActionBean actionBean = new V2IActionBean(Action.ACTION_RSI_ON_OFF, index);
                        settingManager.onSettingOptionClick(actionBean);
                    }
                });
                break;
            case R.id.ed_voice:
                DialogUtils.showSingleAlertDialog(SettingSelectActivity.this, voiceArrays, "声音设置", new DialogUtils.OnSingleSelectListener() {
                    @Override
                    public void onSelected(int index, String item) {
                        voiceEd.setText(item);
                        V2IActionBean actionBean = new V2IActionBean(Action.ACTION_VOICE_SETTING, index);
                        settingManager.onSettingOptionClick(actionBean);
                    }
                });
                break;
            case R.id.ed_floating:
                DialogUtils.showSingleAlertDialog(SettingSelectActivity.this, commonArrays, "V2I浮窗", new DialogUtils.OnSingleSelectListener() {
                    @Override
                    public void onSelected(int index, String item) {
                        floatingEd.setText(item);
                        V2IActionBean actionBean = new V2IActionBean(Action.ACTION_GLOBAL_OVERLAY_ON_OFF, index);
                        settingManager.onSettingOptionClick(actionBean);
                    }
                });
                break;
            case R.id.btn_restore_default:
                settingManager.restoreDefaultSetting();
                break;
            case R.id.btn_back:
                startActivity(new Intent(SettingSelectActivity.this, MainActivity.class));
                finish();
                break;
            case R.id.btn_tips:
                startActivity(new Intent(SettingSelectActivity.this, ExitV2ITrailActivity.class));
//                finish();
                break;
            case R.id.btn_collect:
                favoriteState = V2ISettingManager.getInstance(getApplicationContext()).queryV2IFavoriteState();
                if (favoriteState == 1) {
                    //之前是已收藏的，再次点击变为未收藏
                    boolean b = V2ISettingManager.getInstance(getApplicationContext()).cancelV2IFavorite();
                    if (b) {
                        btnCollect.setImageDrawable(getResources().getDrawable(R.mipmap.ic_collect));
                    }

                } else if (favoriteState == 0) {
                    //之前是未收藏，再次点击变为已收藏
                    boolean b = V2ISettingManager.getInstance(getApplicationContext()).applyV2IFavorite();
                    if (b) {
                        btnCollect.setImageDrawable(getResources().getDrawable(R.mipmap.ic_collected));
                    }
                }
                break;
        }

    }
}
