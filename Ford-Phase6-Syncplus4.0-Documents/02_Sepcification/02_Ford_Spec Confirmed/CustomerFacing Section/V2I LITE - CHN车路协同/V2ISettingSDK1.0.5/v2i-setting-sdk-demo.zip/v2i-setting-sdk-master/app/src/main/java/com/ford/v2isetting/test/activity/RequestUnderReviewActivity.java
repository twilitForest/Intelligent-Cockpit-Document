package com.ford.v2isetting.test.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ford.v2isetting.sdk.V2ISettingManager;
import com.ford.v2isetting.test.MainActivity;
import com.ford.v2isetting.test.R;

public class RequestUnderReviewActivity extends AppCompatActivity implements View.OnClickListener {

    Button cancelRequestBtn;
    ImageButton btnBack;
    boolean clickable;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_under_review);
        cancelRequestBtn = findViewById(R.id.btn_cancel_request);
        cancelRequestBtn.setOnClickListener(this);
        btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(this);
        clickable = getIntent().getBooleanExtra("clickable", false);
        if(clickable){
            cancelRequestBtn.setEnabled(true);
        }else {
            cancelRequestBtn.setEnabled(false);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_cancel_request:
                V2ISettingManager.getInstance(getApplicationContext()).cancelV2IRequest();
                break;
            case R.id.btn_back:
                startActivity(new Intent(RequestUnderReviewActivity.this, MainActivity.class));
                finish();
                break;
        }
    }
}
