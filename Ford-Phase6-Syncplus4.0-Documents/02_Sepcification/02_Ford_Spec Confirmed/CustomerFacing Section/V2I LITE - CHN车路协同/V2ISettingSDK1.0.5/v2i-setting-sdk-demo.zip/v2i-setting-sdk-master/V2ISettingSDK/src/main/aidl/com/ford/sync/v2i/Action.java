package com.ford.sync.v2i;

import android.os.Parcel;
import android.os.Parcelable;

public enum Action implements Parcelable {
    /**
     * 允许车路协同
     */
    ACTION_V2I_ON_OFF,

    /**
     * 红绿灯
     */
    ACTION_TLI_SENSITIVITY,

    /**
     * 绿波车速
     */
    ACTION_GLOSA_ON_OFF,

    /**
     * 绿灯起步提醒
     */
    ACTION_GLN_SENSITIVITY,

    /**
     * 闯红灯预警
     */
    ACTION_RLVW_SENSITIVITY,

    /**
     * 道路信息广播
     */
    ACTION_RSI_ON_OFF,

    /**
     * 声音设置
     */
    ACTION_VOICE_SETTING,

    /**
     * 浮窗
     */
    ACTION_GLOBAL_OVERLAY_ON_OFF;


    public static final Creator<Action> CREATOR = new Creator<Action>() {
        @Override
        public Action createFromParcel(Parcel in) {
            return Action.values()[in.readInt()];
        }

        @Override
        public Action[] newArray(int size) {
            return new Action[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(ordinal());
    }

    public void readFromParcel(Parcel in){
        in.readInt();
    }
}
