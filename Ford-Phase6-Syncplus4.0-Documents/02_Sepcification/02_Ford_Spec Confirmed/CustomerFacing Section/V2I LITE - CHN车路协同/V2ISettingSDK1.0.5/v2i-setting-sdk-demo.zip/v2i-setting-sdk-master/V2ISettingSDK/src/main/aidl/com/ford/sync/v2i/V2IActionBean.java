package com.ford.sync.v2i;

import android.os.Parcel;
import android.os.Parcelable;

public class V2IActionBean implements Parcelable {

    Action action;
    int selectIndex;

    protected V2IActionBean(Parcel in) {
        selectIndex = in.readInt();
        action = (Action) in.readParcelable(Action.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(selectIndex);
        dest.writeParcelable(action, 0);
    }

    public void readFromParcel(Parcel in){
        selectIndex = in.readInt();
        action = (Action) in.readParcelable(Action.class.getClassLoader());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<V2IActionBean> CREATOR = new Creator<V2IActionBean>() {
        @Override
        public V2IActionBean createFromParcel(Parcel in) {
            return new V2IActionBean(in);
        }

        @Override
        public V2IActionBean[] newArray(int size) {
            return new V2IActionBean[size];
        }
    };

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public int getSelectIndex() {
        return selectIndex;
    }

    public void setSelectIndex(int selectIndex) {
        this.selectIndex = selectIndex;
    }

    public V2IActionBean(Action action, int selectIndex) {
        this.action = action;
        this.selectIndex = selectIndex;
    }
}
