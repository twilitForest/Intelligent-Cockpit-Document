// ===========================================================================
// CONFIDENTIAL - FORD MOTOR COMPANY
//
// This is an unpublished work, which is a trade secret, created in 2017.
// Ford Motor Company owns all rights to this work and intends to maintain
// it in confidence to preserve its trade secret status. Ford Motor Company
// reserves the right to protect this work as an unpublished copyrighted work
// in the event of an inadvertent or deliberate unauthorized publication.
// Ford Motor Company also reserves its rights under the copyright laws to
// protect this work as a published work.  Those having access to this work
// may not copy it, use it, or disclose the information contained in it
// without the written authorization of Ford Motor Company.
// ===========================================================================

#ifndef LIBWIRWLANCONN_WIRWLANCON_IF_H_
#define LIBWIRWLANCONN_WIRWLANCON_IF_H_

#include <stdint.h>
#include <string>

#include "wirwlanconn_if_common.hpp"
#include "wirwlanconn_if_callback.hpp"

namespace fnv {
namespace cm {
namespace wwc {

class WirWlanConnectivitySettingsImpl;

class WirWlanConnectivitySettings {
public:
    WirWlanConnectivitySettings();
    virtual ~WirWlanConnectivitySettings();

    /**
     * Initialize WirWlanService with callbacks
     *
     * @param appId  application ID of the client
     * @param  cb  callback class to receive callbacks from WirWlanService
     */
    WWCRet_t initialize(const std::string& appId, WirWlanConnectivitySettingsCallback& cb);


    /**
     * Close WirWlanService
     *
     * @param appId  application ID of the client
     */
    WWCRet_t close(const std::string& appId);

    /**
     *  Turn Wi-Fi on
     */
    WWCRet_t wifiOn(void);

    /**
     * Turn Wi-Fi off
     */
    WWCRet_t wifiOff(void);

    /**
     * Get Wi-Fi state
     */
    WWCRet_t getWifiState(void);

    /**
     * Initiate scan for APs
     */
    WWCRet_t scanAPs(void);

    /**
     * Terminate the scan for APs
     */
    WWCRet_t cancelScanAPs(void);

    /**
     * Connect to an AP
     *
     * @param  profile  identifies the AP to connect to
     */
    WWCRet_t connectAP(WlanProfile_t& apInfo);

    /**
     * Cancel connection attempt to AP
     */
    WWCRet_t cancelConnectAP(void);

    /**
     * Disconnect from currently connected AP
     */
    WWCRet_t disconnectAP(void);

    /**
     * Removes an AP from list of known APs
     *
     * @param  profile  identifies the AP to remove
     */
    WWCRet_t forgetAP(ApInfo_t& apInfo);

    /**
     * Get WPS PIN
     */
    WWCRet_t getWpsPin(void);

    /**
     * Get network details for currently connected AP
     */
    WWCRet_t getNetworkDetails(void);

    /**
     * Turn on WiFi availability notifications
     */
    WWCRet_t wifiNotifOn(void);

    /**
     * Turn off WiFi availability notifications
     */
    WWCRet_t wifiNotifOff(void);

    /**
     * Get status of WiFi availability notifications
     */
    WWCRet_t getWifiNotifStatus(void);

private:

    /**
     *  pointer to implementation class
     */
    WirWlanConnectivitySettingsImpl * m_pImpl;
};

} // namespace wwc
} // namespace cm
} // namespace fnv

#endif // LIBWIRWLANCONN_WIRWLANCON_IF_H_
