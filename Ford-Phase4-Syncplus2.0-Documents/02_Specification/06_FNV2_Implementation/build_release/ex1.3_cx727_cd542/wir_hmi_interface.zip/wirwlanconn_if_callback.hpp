// ===========================================================================
// CONFIDENTIAL - FORD MOTOR COMPANY
//
// This is an unpublished work, which is a trade secret, created in 2017.
// Ford Motor Company owns all rights to this work and intends to maintain
// it in confidence to preserve its trade secret status. Ford Motor Company
// reserves the right to protect this work as an unpublished copyrighted work
// in the event of an inadvertent or deliberate unauthorized publication.
// Ford Motor Company also reserves its rights under the copyright laws to
// protect this work as a published work.  Those having access to this work
// may not copy it, use it, or disclose the information contained in it
// without the written authorization of Ford Motor Company.
// ===========================================================================

#ifndef LIBWIRWLANCONN_PUBLIC_WIRWLANCONN_IF_CALLBACK_HPP_
#define LIBWIRWLANCONN_PUBLIC_WIRWLANCONN_IF_CALLBACK_HPP_

#include <stdint.h>

namespace fnv {
namespace cm {
namespace wwc {

class WirWlanConnectivitySettingsCallback {
public:
    // dtor
    virtual ~WirWlanConnectivitySettingsCallback()
    {
        // Auto-generated destructor stub
    }

    // responses
    virtual void initializeResp(int32_t status)
    {
        // avoid build failure
    }
    virtual void wifiOnResp(int32_t status) = 0;
    virtual void wifiOffResp(int32_t status) = 0;
    virtual void getWifiStateResp(int32_t status, bool state)
    {
        // avoid build failure
    }
    virtual void scanAPsResp(int32_t status, ScanResults_t* scanResults) = 0;
    virtual void cancelScanAPsResp(int32_t status) = 0;
    virtual void connectAPResp(int32_t status, ApInfo_t* apInfo) = 0;
    virtual void cancelConnectAPResp(int32_t status) = 0;
    virtual void disconnectAPResp(int32_t status) = 0;
    virtual void forgetAPResp(int32_t status) = 0;
    virtual void getWpsPinResp(int32_t status, wpsSec_t* security) = 0;
    virtual void getNetworkDetailsResp(int32_t status, WlanProfile_t* netInfo) = 0;
    virtual void getWifiNotifStatusResp(int32_t status, bool notifStatus)
    {
        // avoid build failure
    }

    // notifications
    virtual void onWifiReady(void)
    {
        // avoid build failure
    }
    virtual void onWifiAvailable(void) = 0;
    virtual void onWifiUnavailable(void) = 0;
    virtual void onWifiConnected(WlanProfile_t* info) = 0;
    virtual void onWifiDisconnected(void) = 0;
    virtual void onWifiSignalStrength(int rssi) = 0;
    // This notification is deprecated, it is not supported/implemented
    virtual void onNetworkAvailable(void) = 0;
    // This notification is deprecated, it is not supported/implemented
    virtual void onNetworkAvailableCount(int count) = 0;
    virtual void onWifiMacAddress(char macAddr[WWC_WLAN_MAC_LEN]) = 0;
    virtual void onWifiMacAddressInd(MacAddrInd_t *macAddrInd)
    {
        // avoid build failure
    }

};

} // namespace wwc
} // namespace cm
} // namespace fnv


#endif /* LIBWIRWLANCONN_PUBLIC_WIRWLANCONN_IF_CALLBACK_HPP_ */
