// ===========================================================================
// CONFIDENTIAL - FORD MOTOR COMPANY
//
// This is an unpublished work, which is a trade secret, created in 2017.
// Ford Motor Company owns all rights to this work and intends to maintain
// it in confidence to preserve its trade secret status. Ford Motor Company
// reserves the right to protect this work as an unpublished copyrighted work
// in the event of an inadvertent or deliberate unauthorized publication.
// Ford Motor Company also reserves its rights under the copyright laws to
// protect this work as a published work.  Those having access to this work
// may not copy it, use it, or disclose the information contained in it
// without the written authorization of Ford Motor Company.
// ===========================================================================

#ifndef LIBWIRWLANCONN_PUBLIC_WIRWLANCONN_IF_COMMON_HPP_
#define LIBWIRWLANCONN_PUBLIC_WIRWLANCONN_IF_COMMON_HPP_

#include <stdint.h>
#include <string>
#include <logger_api.hpp>

// these are copied from wir_if_common.h
#define WWC_CMQNAME "CMSRVQ"

/**
 *
 * @def WWC_NAME_MAX
 * Max length of AppId string
 * supported by WIR
 *
 */
#define WWC_NAME_MAX 255

/**
 *
 * @def WWC_NAME_MAX_LEN 255
 * Max length of AppId string.
 * Set to OS supported NAME_MAX
 *
 */
#define WWC_NAME_MAX_LEN (NAME_MAX > WWC_NAME_MAX ? WWC_NAME_MAX : NAME_MAX )

#define LVLC 0
#define LVLE 1
#define LVLW 2
#define LVLI 3
#define LVLD 4

#define LOGC LVLC, __FILE__, __FUNCTION__, __LINE__
#define LOGE LVLE, __FILE__, __FUNCTION__, __LINE__
#define LOGW LVLW, __FILE__, __FUNCTION__, __LINE__
#define LOGI LVLI, __FILE__, __FUNCTION__, __LINE__
#define LOGD LVLD, __FILE__, __FUNCTION__, __LINE__

namespace fnv {
namespace cm {
namespace wwc {

// these are copied from wir_if_common.h
const int WWC_MAX_IPC_STRUCT_SIZE = 1024;
const int MAX_WWC_CLNT_IPC_STRUCT_SIZE = 4096;

const int WWC_CM_SERVQ_MSG_SIZE_MAX = 1024;
const int WWC_CM_SERVQ_MSG_PRIO_MAX = 8;
const int WWC_CM_SERVQ_NUM_MSGS_MAX = 32;

const int WWC_CM_CLNTQ_MSG_SIZE_MAX = 4096;
const int WWC_CM_CLNTQ_MSG_PRIO_MAX = 4;
const int WWC_CM_CLNTQ_NUM_MSGS_MAX = 8;

/**
 * @def WWC_IPV4_ADDR_LEN
 * Max length of a c-string that contains an IP4 address in dotted notation xxx.xxx.xxx.xxx
 */
const int WWC_IPV4_ADDR_LEN = 16;

/**
 * @def WLAN_MAC_LEN
 * Max length of a c-string that contains a MAC address.  Format XX:XX:XX:XX:XX:XX
 */
const int WWC_WLAN_MAC_LEN = 18;

/**
 * @def MAX_NUM_MAC_IND
 * Maximum number of mac addresses that can be returned in a
 * mac address indication
 */
const int WWC_MAX_NUM_MAC_PER_IND = 2;

/**
 * @def WLAN_SSID_LEN
 * Max length of a c-string that contains a SSID.
 */
const int WWC_WLAN_SSID_LEN = 33;

/**
 * @def MAX_NUM_WEP_KEY
 * Max number of WEP keys.
 */
const int WWC_MAX_NUM_WEP_KEY = 4;

/**
 * @def MAX_WEP_KEY_LEN
 * Max length of a WEP key.  THIS IS NOT A C-STRING.
 */
const int WWC_MAX_WEP_KEY_LEN = 27;

/**
 * @def MAX_WPS_PIN_LEN
 * Max length of a WPS PIN.  THIS IS NOT A C-STRING
 */
const int WWC_MAX_WPS_PIN_LEN = 8;
const int WWC_MAX_WPA_PASS_LEN = 64;

/**
 * @def WLAN_IP_LEN
 * Max length of a c-string that contains a IP address.  Formats include:
 * IPv4 - XXX.XXX.XXX.XXX
 * IPv6 - XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX
 * IPv4 mapped IPv6 - XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:YYY.YYY.YYY.YYY
 */
const int WWC_WLAN_IP_LEN = 46;

/**
 * @def WWC_MAX_NUM_WLAN_AP
 * Maximum number of APs that can be returned in scan results
 * Based on MAX_IPC_STRUCT_SIZE (512) / sizeof(ApInfo_t) (73)
 */
const int WWC_MAX_NUM_WLAN_AP = 30;

/**
 *
 * @def WWC_LIB_MAJOR_VERSION
 * Incompatible changes
 *
 */
const int WWC_LIB_MAJOR_VERSION = 1;

/**
 *
 * @def WWC_LIB_MINOR_VERSION
 * Backward compatible functionality
 *
 */
const int WWC_LIB_MINOR_VERSION = 0;

/**
 *
 * @def WWC_LIB_PATCH_VERSION
 * Backward compatible bug fixes
 *
 */
const int WWC_LIB_PATCH_VERSION = 1;

typedef enum WIRWLANCONN_Ret
{
    WWC_ERROR = 0,
    WWC_SUCCESS = 1
//More errors codes to be defined
} WWCRet_t;

/**
 *  WLAN structs, enums and definitions
 *
 *  - based on libwlan/wlan_data_types.hpp
 *  - however, std::string, std::array, std::vectors are removed
 *    so that data can be packaged and transmitted using message queues
 */

enum class Security
{
    Min = 0,
    Open,           /**< Open or no security */
    Wep,            /**< WEP */
    Wps,            /**< WPS (WiFi Protected Setup) */
    WpaPersonal,    /**< WPA/WPA2 Personal (passkey) */
    WpaEnterprise,  /**< WPA/WPA2 Enterprise (EAP-PEAP/EAP-TLS/etc)  NOT SUPPORTED */
    Max
};

enum class PairwiseCipher
{
    Min = 0,
    None,       /**< no pairwise cipher */
    Tkip,       /**< TKIP */
    Ccmp,       /**< CCMP/AES */
    TkipCcmp,   /**< Mixmode - tkip or ccmp */
    Max
};

enum class GroupCipher
{
    Min = 0,
    None,       /**< no group cipher */
    Tkip,       /**< TKIP */
    Ccmp,       /**< CCMP/AES */
    TkipCcmp,   /**< Mixmode - tkip or ccmp */
    Max
};

enum class Channel
{
    Min = 0,
    Ch1,    /**< Channel 1 - 2412 MHz */
    Ch2,    /**< Channel 2 - 2417 MHz - NA, Japan, and World */
    Ch3,    /**< Channel 3 - 2422 MHz - NA, Japan, and World */
    Ch4,    /**< Channel 4 - 2427 MHz - NA, Japan, and World */
    Ch5,    /**< Channel 5 - 2432 MHz - NA, Japan, and World */
    Ch6,    /**< Channel 6 - 2437 MHz - NA, Japan, and World */
    Ch7,    /**< Channel 7 - 2442 MHz - NA, Japan, and World */
    Ch8,    /**< Channel 8 - 2447 MHz - NA, Japan, and World */
    Ch9,    /**< Channel 9 - 2452 MHz - NA, Japan, and World */
    Ch10,   /**< Channel 10 - 2457 MHz - NA, Japan, and World  */
    Ch11,   /**< Channel 11 - 2462 MHz - NA, Japan, and World */
    Ch12,   /**< Channel 12 - 2467 MHz - Japen and World*/
    Ch13,   /**< Channel 13 - 2472 MHz - Japan and World*/
    Ch14,   /**< Channel 14 - 2484 MHz - Japan Only*/
    Ch34,   /**< Channel 34 */
    Ch36,   /**< Channel 36 */
    Ch38,   /**< Channel 38 */
    Ch40,   /**< Channel 40 */
    Ch42,   /**< Channel 42 */
    Ch44,   /**< Channel 44 */
    Ch46,   /**< Channel 46 */
    Ch48,   /**< Channel 48 */
    Ch50,   /**< Channel 50 */
    Ch52,   /**< Channel 52 */
    Ch54,   /**< Channel 54 */
    Ch56,   /**< Channel 56 */
    Ch58,   /**< Channel 58 */
    Ch60,   /**< Channel 60 */
    Ch62,   /**< Channel 62 */
    Ch64,   /**< Channel 64 */
    Ch100,  /**< Channel 100 */
    Ch102,  /**< Channel 102 */
    Ch104,  /**< Channel 104 */
    Ch106,  /**< Channel 106 */
    Ch108,  /**< Channel 108 */
    Ch110,  /**< Channel 110 */
    Ch112,  /**< Channel 112 */
    Ch114,  /**< Channel 114 */
    Ch116,  /**< Channel 116 */
    Ch118,  /**< Channel 118 */
    Ch120,  /**< Channel 120 */
    Ch122,  /**< Channel 122 */
    Ch124,  /**< Channel 124 */
    Ch126,  /**< Channel 126 */
    Ch128,  /**< Channel 128 */
    Ch132,  /**< Channel 132 */
    Ch134,  /**< Channel 134 */
    Ch136,  /**< Channel 136 */
    Ch138,  /**< Channel 138 */
    Ch140,  /**< Channel 140 */
    Ch142,  /**< Channel 142 */
    Ch144,  /**< Channel 144 */
    Ch149,  /**< Channel 149 */
    Ch151,  /**< Channel 151 */
    Ch153,  /**< Channel 153 */
    Ch155,  /**< Channel 155 */
    Ch157,  /**< Channel 157 */
    Ch159,  /**< Channel 159 */
    Ch161,  /**< Channel 161 */
    Ch165,  /**< Channel 165 */
    Ch169,  /**< Channel 169 */
    Ch173,  /**< Channel 173 */
    All,    /**< Use all channels */
    Any,    /**< Use any channel; for AP mode, let wlan_service pick channel */
    Any2GHz, /**< Use any 2.4 GHz channel; for AP mode, let wlan_service pick channel */
    Any5GHz, /**< Use any 5.0 GHz channel; for AP mode, let wlan_service pick channel */
    Max
};

enum class Bandwidth
{
    Min = 0,
    Mhz20,      /**< 20MHz channel */
    Mhz40,      /**< 40MHz channel; must use 11n/11ac.  Few devices support on 2.4Ghz */
    Mhz80,      /**< 80MHz channel; must use 11ac */
    Mhz8080,    /**< 80-80MHz, 2 non-contiguous 80MHz; must use 11ac */
    Mhz160,     /**< 160MHz channel; must 11ac */
    Max
};

enum class Ipv4AddrType
{
    Min = 0,
    None,       /**< No IPv4 Addressing is used */
    Static,     /**< Static IPv4 Address */
    DhcpClient, /**< DHCP Client IPv4 Address */
    DhcpServer, /**< DHCP Server IPv4 Address */
    Max
};

typedef struct ipv4Addr  {
    char            ip[WWC_WLAN_IP_LEN] = {'\0'};        /**< IP address of current connection */
    char            netmask[WWC_WLAN_IP_LEN] = {'\0'};   /**< Netmask of currenct connection */
    char            gateway[WWC_WLAN_IP_LEN] = {'\0'};   /**< default gateway of current connection */
    char            dnsPref[WWC_WLAN_IP_LEN] = {'\0'};   /**< Prefered DNS server */
    char            dnsAlt[WWC_WLAN_IP_LEN] = {'\0'};    /**< Secondary DNS server */
} ipv4Addr_t;

enum class Ipv6AddrType
{
    Min = 0,
    None,       /**< No IPv6 Addressing is used */
    Static,     /**< Static IPv6 Address */
    Max
};

typedef struct ipv6Addr  {
    // TODO: complete ipv6 addr structure
} ipv6Addr_t;

typedef enum _connection_type_
{
    // do not change the order
    CONNECTION_TYPE_PIN           = 0,
    CONNECTION_TYPE_WPS_PIN   = 1,
    CONNECTION_TYPE_WPS_PBC       = 2,
    CONNECTION_TYPE_OPEN      = 3,
    CONNECTION_TYPE_HIDDEN_SECURE = 4,
    CONNECTION_TYPE_HIDDEN_OPEN   = 5
    //insert here
} WifiConnectionType;

typedef enum _WifiConnectionStatus_
{
    WIFI_STATUS_FAIL_OTHER     = 103,    ///< Other Failure or Connecting to AP Failed
    WIFI_STATUS_FAIL          = 102,    ///< Failure
    WIFI_NOT_IMPLEMENTED      = 101,    ///< Not Implemented
    WIFI_STATUS_SUCCESS       = 0,      ///< Success
    WIFI_AP_SCAN_SUCCESS      = 1,      ///< Scan Successful
    WIFI_NO_APS_AVAILABLE     = 2,      ///< No Access Points available
    WIFI_CONNECTED            = 3,      ///< Connected to Access Point
    WIFI_NOT_CONNECTED        = 4,      ///< Wifi is not connected to Access Point
    WIFI_OTH_FAIL             = 5,      ///< Authentication Failure
    WIFI_CONNECTING           = 6,      ///< Connecting to Access Point
    WIFI_SECURITY_MISSMATCH   = 7,      ///< There is security type missmatch between what requested and what is in actual
    WIFI_AUTHENTICATING       = 11,
    WIFI_ABORTED              = 12,
    WIFI_WRONG_PASSWORD       = 13,
    WIFI_WRONG_WPS_PIN       = 14,
    WIFI_CONNECTION_PROGRESS  = 15,
    WIFI_RESTRICTED_NETWORK  = 16,       ///< Connection failure due to trying to connect to a restricted network eg : TCU hotspot
    WIFI_CANCEL_CONNECTION       = -3,
} EWifiConnectionStatus;

typedef struct ApInfo {
    char        ssid[WWC_WLAN_SSID_LEN] = {'\0'};    /**< SSID */
    char        bssid[WWC_WLAN_MAC_LEN] = {'\0'};   /**< MAC address of AP */
    Channel     channel = {Channel::Min};           /**< Channel */
    Bandwidth   bw = {Bandwidth::Min};              /**< bandwidth */
    int         rssi = {0};                         /**< RSSI of beacon/probe response */
    Security    security = {Security::Min};         /**< Security used by AP */
    bool        wps = {false};                      /**< does AP support WPS */
    bool        ess = {false};                      /**< is AP part of a Extended Service Set */
    char        ipv4Addr[WWC_IPV4_ADDR_LEN] = {'\0'};  /**< IPv4 address of AP */
    char        netmask[WWC_IPV4_ADDR_LEN] = {'\0'};   /**< netmask */
    bool        connected = {false};                   /**< connected to AP */
    bool        prevConnected = {false};               /**< previously connected*/
    bool        isHidden = {false};                    /**< hidden */
    WifiConnectionType    connectionType = {CONNECTION_TYPE_PIN};   /**< see wifi_service.h, WifiConnectionType */
    EWifiConnectionStatus connectionStatus = {WIFI_STATUS_SUCCESS}; /**< see wifi_service_protocol.h, EWifiConnectionType */
} ApInfo_t;

typedef struct ScanResults {
    int count;                                  ///< number AP in scan results
    ApInfo_t apList[WWC_MAX_NUM_WLAN_AP];       ///< array of ScanResult_t
} ScanResults_t;

typedef struct wepSecurity {
    char keys[WWC_MAX_NUM_WEP_KEY][WWC_MAX_WEP_KEY_LEN];
    uint8_t defaultKeyIndex = { 0 };
} wepSec_t;

typedef enum wpsType {
    Min = 0,
    Keypad,
    Pin,
    Pbs,
    Max
} WpsType_t;

typedef struct wpsSecurity {
    WpsType_t type = { WpsType_t::Min };
    char pin[WWC_MAX_WPS_PIN_LEN] = {'\0' };
} wpsSec_t;

typedef struct wpaPersonal {
    char            password[WWC_MAX_WPA_PASS_LEN] = {'\0'};    /**< Password */
    PairwiseCipher  pairCipher = {PairwiseCipher::TkipCcmp};    /**< Pairwise Ciphers to use */
    GroupCipher     groupCipher = {GroupCipher::TkipCcmp};      /**< Group Ciphers to use */
} wpaPskSec_t;

typedef struct eapPeap {
    // NOT CURRENTLY SUPPORTED
} eapPeap_t;

typedef struct eapTls {
    // NOT CURRENTLY SUPPORTED
} eapTls_t;

typedef struct eapTtls {
    // NOT CURRENTLY SUPPORTED
} eapTtls_t;

typedef struct eapSim {
    // NOT CURRENTLY SUPPORTED
} eapSim_t;

typedef struct eapAka {
    // NOT CURRENTLY SUPPORTED
} eapAka_t;

typedef struct eapAkaPrime {
    // NOT CURRENTLY SUPPORTED
} eapAkaPrime_t;

typedef struct eapFast {
    // NOT CURRENTLY SUPPORTED
} eapFast_t;

enum class EapType
{
    Min = 0,
    Peap,   /**< Peap */
    Tls,    /**< TLS */
    Ttls,   /**< TTLS */
    Sim,    /**< Sim */
    Aka,    /**< Prime */
    Prime,  /**< Aka' or Aka Prime */
    Fast,   /**< Fast */
    Max
};

union eap {
    eapPeap_t       peap;           /**< PEAP specific settings */
    eapTls_t        tls;            /**< TLS specific settings */
    eapTtls_t       ttls;           /**< TTLS specific settings */
    eapSim_t        sim;            /**< SIM specific settings */
    eapAka_t        aka;            /**< AKA specfic settings */
    eapAkaPrime_t   prime;          /**< AKA' specific settings */
    eapFast_t       fast;           /**< FAST specfic settings */
};

typedef struct wpaEnterprise {
    PairwiseCipher      pairCipher;     /**< Pairwise Ciphers to use */
    GroupCipher         groupCipher;    /**< Group Ciphers to use */
    EapType             type;           /**< EAP type to use */
    union eap           eap;
} wpaEapSec_t;

union security {
    wepSec_t        wep;                    /**< WEP Settings */
    wpsSec_t        wps;                    /**< WPS Settings */
    wpaPskSec_t     wpaPsk;                 /**< WPA/WPA2-Personal Settings */
    wpaEapSec_t     wpaEap;                 /**< WPA/WPA2-Enterprise Settings */
    security() { /* TBD */ };
};

union Ipv4 {
    ipv4Addr_t      staticIpv4;             /**< static IPv4 Settings */
    Ipv4() { /* TBD */ };
};

union Ipv6 {
    ipv6Addr_t      staticIpv6;             /**< static IPv6 Settings */
    Ipv6() { /* TBD */ };
};

typedef struct WlanProfile {
    char                ssid[WWC_WLAN_SSID_LEN] = {'\0'};       /**< SSID of network */
    char                bssid[WWC_WLAN_MAC_LEN] = {'\0'};       /**< Optional - BSSID of AP */
    Channel             channel = {Channel::Any};               /**< Optional - Channel of AP */
    Security            securityType = {Security::Open};        /**< Security settings to use */
    security      sec;
    Ipv4AddrType        ipv4AddrType = {Ipv4AddrType::DhcpClient};   /**< Type of IPv4 Addressing */
    Ipv4        ipv4;
    Ipv6AddrType        ipv6AddrType = {Ipv6AddrType::None};         /**< IPv6 Addressing */
    Ipv6        ipv6;
} WlanProfile_t;

typedef struct MacAddrInd {
    int count;
    char macAddr[WWC_MAX_NUM_MAC_PER_IND][WWC_WLAN_MAC_LEN];
} MacAddrInd_t;

void wwcLog(const int& level,
            const char* file,
            const char* fn,
            const int& line,
            const char* fmt,
            ...);

} // namespace wwc
} // namespace cm
} // namespace fnv




#endif /* LIBWIRWLANCONN_PUBLIC_WIRWLANCONN_IF_COMMON_HPP_ */
