/// CONFIDENTIAL - FORD MOTOR COMPANY
///
/// This is an unpublished work, which is a trade secret, created in
/// 2020.  Ford Motor Company owns all rights to this work and intends
/// to maintain it in confidence to preserve its trade secret status.
/// Ford Motor Company reserves the right to protect this work as an
/// unpublished copyrighted work in the event of an inadvertent or
/// deliberate unauthorized publication.  Ford Motor Company also
/// reserves its rights under the copyright laws to protect this work
/// as a published work.  Those having access to this work may not copy
/// it, use it, or disclose the information contained in it without
/// the written authorization of Ford Motor Company.

/// \file      sample_wir_app.cpp
///
/// \author    Othmane AIT EL CADI - <oaitelca@ford.com>
/// \date      04-05-2020

// Local includes.
#include "wir_client.hpp"

#include <iostream>
#include <unistd.h>

sample::wir::WirIntentType stringIntentToEnum(const std::string& intentStr)
{
    using namespace sample::wir;

    WirIntentType intentType;

    if (intentStr == "bgg")
    {
        intentType = WirIntentType::eINTENT_BGG;
    }
    else if (intentStr == "bgb")
    {
        intentType = WirIntentType::eINTENT_BGB;
    }
    else if (intentStr == "fgd")
    {
        intentType = WirIntentType::eINTENT_FGD;
    }
    else if (intentStr == "offp")
    {
        intentType = WirIntentType::eINTENT_OFFP;
    }
    else if (intentStr == "spcf")
    {
        intentType = WirIntentType::eINTENT_SPCF;
    }
    else if (intentStr == "spci")
    {
        intentType = WirIntentType::eINTENT_SPCI;
    }
    else if (intentStr == "spcw")
    {
        intentType = WirIntentType::eINTENT_SPCW;
    }
    else
    {
        intentType = WirIntentType::eINTENT_UNK;
    }

    return intentType;
}

// ===============================================================================================================================

bool isValidNumber(const std::string& str)
{
    return (str.empty() == false) && (str.find_first_not_of("0123456789") == std::string::npos);
}

// ===============================================================================================================================

int main(int argc, char* argv[])
{
    bool appIDSet = false;
    std::string appID{"com.ford.ecg.WIRTEST"};
    std::string intentStr{"fgd"};
    std::string priority{"0"};

    int option;
    while ((option = getopt(argc, argv, "a:i:p:")) != -1)
    {
        switch (option)
        {
        case 'a':
            appID = optarg;
            appIDSet = true;
            break;

        case 'i':
            intentStr = optarg;
            break;

        case 'p':
            priority = optarg;
            break;

        default:
        {
            printf("wrong argument!\n");
            printf("usage: sampleWirApp [-a appName] [-i intentType (fgd/bgg/bgb)] [-p priority (0/1/2)]\n");
            printf("-where: appName : application package identifier\n");
            printf("        intentType : intentType to be requested\n");
            printf("        priority : priority to be requested\n");

            return EXIT_FAILURE;
        }
        }
    }

    const sample::wir::WirIntentType intent = stringIntentToEnum(intentStr);
    if (intent == sample::wir::WirIntentType::eINTENT_UNK)
    {
        printf("Unknown intent value, it should be one of: bgg, bgb, fgd, offp, spcf, spci, spcw.\n");

        return EXIT_FAILURE;
    }

    if (isValidNumber(priority) == false)
    {
        printf("Unvalid priority value, it should be a number.\n");

        return EXIT_FAILURE;
    }
    const uint8_t ifacePriority = std::stoi(priority);

    if (appIDSet == false)
    {
        printf("appName not specified, defaulting to %s\n", appID.c_str());
    }

    printf("Initializing the WIR client...\n");
    sample::wir::WirClient wirClient{appID};
    bool result = wirClient.isInitialized();

    printf("WIR client initialization %s", (result == true) ? "successded" : "failed");

    if (result == true)
    {
        printf("Requesting allocation...\n");
        result = wirClient.allocate(intent, ifacePriority);

        printf("Press any key to exit...\n");
        std::cin.get();
    }

    printf("Closing the client...\n");

    return 0;
}
