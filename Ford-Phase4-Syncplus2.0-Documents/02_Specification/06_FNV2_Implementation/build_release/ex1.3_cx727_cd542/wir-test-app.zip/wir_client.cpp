/// CONFIDENTIAL - FORD MOTOR COMPANY
///
/// This is an unpublished work, which is a trade secret, created in
/// 2020.  Ford Motor Company owns all rights to this work and intends
/// to maintain it in confidence to preserve its trade secret status.
/// Ford Motor Company reserves the right to protect this work as an
/// unpublished copyrighted work in the event of an inadvertent or
/// deliberate unauthorized publication.  Ford Motor Company also
/// reserves its rights under the copyright laws to protect this work
/// as a published work.  Those having access to this work may not copy
/// it, use it, or disclose the information contained in it without
/// the written authorization of Ford Motor Company.

/// \file      wir_client.cpp
///
/// \author    Othmane AIT EL CADI - <oaitelca@ford.com>
/// \date      04-05-2020

// Local includes.
#include "wir_client.hpp"

#include <wir/wir_if_common.hpp>

#include <wir/wir_intent.hpp>
#include <wir/wir_intent_foreground.hpp>
#include <wir/wir_intent_background_besteffort.hpp>
#include <wir/wir_intent_background_guaranteed.hpp>
#include <wir/wir_intent_special.hpp>
#include <wir/wir_intent_offpeak.hpp>

#include <wir/wir_networkif_allocation.hpp>

namespace sample
{
namespace wir
{
WirClient::WirClient(const std::string& appID) : m_appID(appID)
{
    const auto res = m_wirInstance.initialize(m_appID, *this);

    if (res == fnv::cm::WIRRet_t::WIR_SUCCESS)
    {
        m_displayThread = std::thread{&WirClient::displayValues, this};

        m_isInitialized = true;
    }
}

// ===============================================================================================================================

WirClient::~WirClient()
{
    m_stopApp = true;
    m_wirIfAllocsCv.notify_one();
    m_displayThread.join();

    bool result = releaseAll();
    result &= (m_wirInstance.close(m_appID) == fnv::cm::WIRRet_t::WIR_SUCCESS);

    printf("WIR client done %s.\n", (result == true) ? "successfully" : "with errors");
}

// ===============================================================================================================================

bool WirClient::allocate(const WirIntentType intent, const uint8_t ifacePriority)
{
    auto res = fnv::cm::WIRRet_t::WIR_ERROR;
    uint32_t allocID = -1;

    switch (intent)
    {
    case WirIntentType::eINTENT_BGG:
    {
        const auto ifacePriorityLvl = (ifacePriority == 0) ?
                                          fnv::cm::NetworkInterfacePriorityLevelBackground_t::NET_IFACE_PRI_BG_0 :
                                          fnv::cm::NetworkInterfacePriorityLevelBackground_t::NET_IFACE_PRI_BG_1;
        fnv::cm::WirBackgroundGuaranteedIntent wirIntent = fnv::cm::WirBackgroundGuaranteedIntent(m_ifaceExpiry,
                                                                                                  ifacePriorityLvl);
        res = m_wirInstance.allocateNetworkInterface(wirIntent, allocID);
    }
    break;

    case WirIntentType::eINTENT_BGB:
    {
        const auto ifacePriorityLvl = (ifacePriority == 0) ?
                                          fnv::cm::NetworkInterfacePriorityLevelBackground_t::NET_IFACE_PRI_BG_0 :
                                          fnv::cm::NetworkInterfacePriorityLevelBackground_t::NET_IFACE_PRI_BG_1;
        fnv::cm::WirBackgroundBestEffortIntent wirIntent = fnv::cm::WirBackgroundBestEffortIntent(m_ifaceExpiry,
                                                                                                  ifacePriorityLvl);
        res = m_wirInstance.allocateNetworkInterface(wirIntent, allocID);
    }
    break;

    case WirIntentType::eINTENT_SPCF:
    {
        auto ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_0;
        switch (ifacePriority)
        {
        case 1:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_1;
            break;

        case 2:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_2;
            break;
        };

        const fnv::cm::NetworkInterfaceType_t iface = fnv::cm::NetworkInterfaceType_t::NET_IFACE_TCUCELL;
        const fnv::cm::CellularApnType_t apn = fnv::cm::CellularApnType_t::APN_FORD;
        fnv::cm::WirSpecialIntent wirIntent = fnv::cm::WirSpecialIntent(iface, apn, ifacePriorityLvl);

        res = m_wirInstance.allocateNetworkInterface(wirIntent, allocID);
    }
    break;

    case WirIntentType::eINTENT_SPCI:
    {
        auto ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_0;
        switch (ifacePriority)
        {
        case 1:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_1;
            break;

        case 2:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_2;
            break;
        };

        const fnv::cm::NetworkInterfaceType_t iface = fnv::cm::NetworkInterfaceType_t::NET_IFACE_TCUCELL;
        const fnv::cm::CellularApnType_t apn = fnv::cm::CellularApnType_t::APN_INTERNET;
        fnv::cm::WirSpecialIntent wirIntent = fnv::cm::WirSpecialIntent(iface, apn, ifacePriorityLvl);

        res = m_wirInstance.allocateNetworkInterface(wirIntent, allocID);
    }
    break;

    case WirIntentType::eINTENT_SPCW:
    {
        auto ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_0;
        switch (ifacePriority)
        {
        case 1:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_1;
            break;

        case 2:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_2;
            break;
        };

        const fnv::cm::NetworkInterfaceType_t iface = fnv::cm::NetworkInterfaceType_t::NET_IFACE_TCUWIFI;
        fnv::cm::WlanProfile_t wlanProfile;
        wlanProfile.ssid = "FNV2WLANSPCL";
        wlanProfile.password = "6815Flanders!";
        fnv::cm::WirSpecialIntent wirIntent = fnv::cm::WirSpecialIntent(iface, wlanProfile, ifacePriorityLvl);

        res = m_wirInstance.allocateNetworkInterface(wirIntent, allocID);
    }
    break;

    case WirIntentType::eINTENT_OFFP:
    {
        const auto ifacePriorityLvl = (ifacePriority == 0) ? fnv::cm::NetworkInterfacePriorityLevelOffPeak_t::NET_IFACE_PRI_OP_0 :
                                                             fnv::cm::NetworkInterfacePriorityLevelOffPeak_t::NET_IFACE_PRI_OP_1;
        fnv::cm::WirOffPeakIntent wirIntent = fnv::cm::WirOffPeakIntent(0, ifacePriorityLvl);

        res = m_wirInstance.allocateNetworkInterface(wirIntent, allocID);
    }
    break;

    case WirIntentType::eINTENT_FGD:
    {
        auto ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_0;
        switch (ifacePriority)
        {
        case 1:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_1;
            break;

        case 2:
            ifacePriorityLvl = fnv::cm::NetworkInterfacePriorityLevelForeground_t::NET_IFACE_PRI_FG_2;
            break;
        };

        fnv::cm::WirForegroundIntent wirIntent = fnv::cm::WirForegroundIntent(fnv::cm::WIFI_PREF_NO, ifacePriorityLvl);

        res = m_wirInstance.allocateNetworkInterface(wirIntent, allocID);
    }
    break;

    case WirIntentType::eINTENT_UNK:
        break;
    };

    if (res == fnv::cm::WIRRet_t::WIR_SUCCESS)
    {
        std::lock_guard<std::mutex> lock{m_wirIfAllocsMutex};
        m_wirIfAllocList.insert({allocID, fnv::cm::WirNetworkIfAllocation{}});
    }

    return (res == fnv::cm::WIRRet_t::WIR_SUCCESS);
}

// ===============================================================================================================================

void WirClient::displayValues()
{
    std::string msg;

    while (m_stopApp == false)
    {
        std::unique_lock<std::mutex> lock(m_wirIfAllocsMutex);
        m_wirIfAllocsCv.wait(lock, [this]() { return (m_ifUpdated || m_stopApp); });

        if (m_stopApp == true)
        {
            break;
        }

        m_ifUpdated = false;

        for (const auto& entry : m_wirIfAllocList)
        {
            const fnv::cm::WirNetworkIfAllocation& ifAlloc = entry.second;
            switch (ifAlloc.getAllocStatus())
            {
            case fnv::cm::NetworkInterfaceAllocationStatus_t::NET_IFACE_ALLOC_SUCCESS:
            {
                msg = ifAlloc.getIpAddr() + " : ";

                switch (ifAlloc.getIface())
                {
                case fnv::cm::NetworkInterfaceType_t::NET_IFACE_TCUCELL:
                    msg += "TCUCELL";
                    break;

                case fnv::cm::NetworkInterfaceType_t::NET_IFACE_TCUWIFI:
                    msg += "TCUWIFI";
                    break;

                case fnv::cm::NetworkInterfaceType_t::NET_IFACE_SYNCWIFI:
                    msg += "SYNCWIFI";
                    break;

                default:
                    msg += "UNKNOWN";
                    break;
                }
            }
            break;

            case fnv::cm::NetworkInterfaceAllocationStatus_t::NET_IFACE_ALLOC_INQUEUE:
                msg += "queued";
                break;

            default:
                msg += "failed";
            }

            printf("%u : %s\n", entry.first, msg.c_str());
            msg.clear();
        }
    }
}

// ===============================================================================================================================

bool WirClient::release(const uint32_t& allocID)
{
    bool result = (m_wirInstance.releaseNetworkInterface(allocID) == fnv::cm::WIRRet_t::WIR_SUCCESS);

    return result;
}

// ===============================================================================================================================

bool WirClient::releaseAll()
{
    bool result = false;

    for (const auto& entry : m_wirIfAllocList)
    {
        result &= release(entry.first);
    }
    m_wirIfAllocList.clear();

    return result;
}

// ===============================================================================================================================

void WirClient::updateWirNetIfAlloc(const uint32_t& allocID, const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc)
{
    std::lock_guard<std::mutex> lock{m_wirIfAllocsMutex};
    auto itr = m_wirIfAllocList.find(allocID);
    if (itr != m_wirIfAllocList.cend())
    {
        fnv::cm::WirNetworkIfAllocation& wirIfAlloc = itr->second;

        wirIfAlloc.setAllocStatus(wirNetIfAlloc.getAllocStatus());
        wirIfAlloc.setIface(wirNetIfAlloc.getIface());
        wirIfAlloc.setIpAddr(wirNetIfAlloc.getIpAddr());
    }

    m_ifUpdated = true;
    m_wirIfAllocsCv.notify_one();
}

// ===============================================================================================================================

void WirClient::networkInterfaceAllocationStatusCb(const uint32_t allocID, const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc)
{
    updateWirNetIfAlloc(allocID, wirNetIfAlloc);
}

// ===============================================================================================================================

void WirClient::networkInterfaceDownCb(const uint32_t allocID, const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc)
{
    updateWirNetIfAlloc(allocID, wirNetIfAlloc);
}

// ===============================================================================================================================

void WirClient::networkInterfaceUpCb(const uint32_t allocID, const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc)
{
    updateWirNetIfAlloc(allocID, wirNetIfAlloc);
}

}  // namespace wir
}  // namespace sample
