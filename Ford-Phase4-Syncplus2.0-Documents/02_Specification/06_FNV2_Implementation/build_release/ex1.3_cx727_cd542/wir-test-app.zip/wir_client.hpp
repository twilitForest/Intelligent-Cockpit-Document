/// CONFIDENTIAL - FORD MOTOR COMPANY
///
/// This is an unpublished work, which is a trade secret, created in
/// 2020.  Ford Motor Company owns all rights to this work and intends
/// to maintain it in confidence to preserve its trade secret status.
/// Ford Motor Company reserves the right to protect this work as an
/// unpublished copyrighted work in the event of an inadvertent or
/// deliberate unauthorized publication.  Ford Motor Company also
/// reserves its rights under the copyright laws to protect this work
/// as a published work.  Those having access to this work may not copy
/// it, use it, or disclose the information contained in it without
/// the written authorization of Ford Motor Company.

/// \file      wir_client.hpp
///
/// \brief     <brief description>
///
/// \author    Othmane AIT EL CADI - <oaitelca@ford.com>
/// \date      04-05-2020

#ifndef WIR_CLIENT_H_
#define WIR_CLIENT_H_

#include <thread>
#include <mutex>
#include <condition_variable>
#include <map>

#include <wir/wir_if.hpp>
#include <wir/wir_if_callback.hpp>

namespace sample
{
namespace wir
{
constexpr const uint32_t WIRALLOC_TIMEOUT = 60000;

enum class WirIntentType : uint8_t
{
    eINTENT_BGG,   ///< Background guaranteed intent.
    eINTENT_BGB,   ///< Background best effort intent.
    eINTENT_FGD,   ///< Foreground intent.
    eINTENT_OFFP,  ///< Off peak intent.
    eINTENT_SPCF,  ///< Special intent (Ford APN).
    eINTENT_SPCI,  ///< Special intent (Internet APN).
    eINTENT_SPCW,  ///< Special intent (WLAN).
    eINTENT_UNK    ///< Unknown intent.
};

// Each client implements WirelessInterfaceRouterCallbackInterface to handle
// notifications/alerts from Connection Manager. Instance of the
// implemented class shall be used to register the callbacks with
// WirelessInterfaceRouter.
class WirClient : public fnv::cm::WirelessInterfaceRouterCallbackInterface
{
public:
    WirClient(const std::string& appID);
    ~WirClient();

    bool allocate(const WirIntentType intent, const uint8_t ifacePriority);
    void displayValues();

    void networkInterfaceAllocationStatusCb(const uint32_t allocID,
                                            const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc) override;
    void networkInterfaceDownCb(const uint32_t allocID, const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc) override;
    void networkInterfaceUpCb(const uint32_t allocID, const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc) override;
    void networkPolicyUpdateCb(const uint16_t permission) override {}
    void dataTransportPauseCb(const uint32_t allocID) override {}
    void dataTransportResumeCb(const uint32_t allocID) override {}
    void dataTransportStopCb(const uint32_t allocID) override {}
    void requestActivityOverNetworkInterface(const uint32_t allocID, const fnv::cm::DataTransportState_t& ifState) override {}

    bool isInitialized() const { return m_isInitialized; }

private:
    bool release(const uint32_t& allocID);
    bool releaseAll();
    void updateWirNetIfAlloc(const uint32_t& allocID, const fnv::cm::WirNetworkIfAllocation& wirNetIfAlloc);

    uint32_t m_ifaceExpiry = WIRALLOC_TIMEOUT / 2000;
    bool m_isInitialized = false;
    std::string m_appID;
    fnv::cm::WirelessInterfaceRouter m_wirInstance;

    std::thread m_displayThread;
    using WirNetworkIfAllocations_t = std::map<uint32_t, fnv::cm::WirNetworkIfAllocation>;
    WirNetworkIfAllocations_t m_wirIfAllocList;
    std::mutex m_wirIfAllocsMutex;
    bool m_ifUpdated = false;
    std::condition_variable m_wirIfAllocsCv;
    std::atomic<bool> m_stopApp{false};
};

}  // namespace wir
}  // namespace sample

#endif /* WIR_CLIENT_H_ */
