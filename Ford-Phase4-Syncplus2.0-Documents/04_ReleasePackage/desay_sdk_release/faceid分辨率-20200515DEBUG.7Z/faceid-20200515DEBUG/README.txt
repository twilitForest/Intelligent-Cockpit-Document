
/*********************此版本仅供开发调试使用，不能用于测试  2020-05-15 *********************/

修改说明
1、faceid camera分辨率由1280x800改为1280x720


使用说明：

1、打开cmd，cd到faceid-20200515DEBUG目录，执行如下命令

adb root

adb remount

adb push system\bin\. /system/bin/

adb push system\lib\. /system/lib/

adb push system\lib64\. /system/lib64/

adb shell sync

adb reboot