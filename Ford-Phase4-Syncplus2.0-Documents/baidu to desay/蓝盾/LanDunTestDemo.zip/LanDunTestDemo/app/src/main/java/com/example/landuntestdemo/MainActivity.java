package com.example.landuntestdemo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    /**
     * isVehicleRun
     */
    private Button mIsVehicleRun;
    /**
     * getFrontWindshieldHeatingState
     */
    private Button mGetFrontWindshieldHeatingState;
    /**
     * getRearWindshieldHeatingStatus
     */
    private Button mGetRearWindshieldHeatingStatus;
    /**
     * getAirddistModedr
     */
    private Button mGetAirddistModedr;
    /**
     * getCompressorRunStatus
     */
    private Button mGetCompressorRunStatus;
    /**
     * getGlobalProperty
     */
    private Button mGetGlobalProperty;
    /**
     * isCarFrontClimateOpen
     */
    private Button mIsCarFrontClimatePen;
    /**
     * getRearWindshieldHeatingStatus
     */
    private Button mGetCarClimateCycleMode;
    /**
     * set_car_climate_cycle_mode
     */
    private Button mSetCarClimateCycleMode;
    /**
     * get_up_status
     */
    private Button mGetUpStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        onClickListener();

    }

    private void onClickListener() {
//        AARLanDunListener.onVehicleRunChange(boolean state){
//
//        }
//        AARLanDunListener.onFrontWindshieldHeatingState(int state){
//
//        }

//        AARLanDunListener.onRearWindshieldHeatingStatus(boolean state){
//
//        }

//        AARLanDunListener.onAirddistModedrChange(boolean state){
//
//        }

//        AARLanDunListener.onCompressorRunStatus(int state){
//
//        }
//        AARLanDunListener.onChangeEvent(int eventType,int[] intValues,float[] floatValues){
//        }

//        ClimateChangeListener.onOpenStatusChange(int position, boolean isOpen, int operation){
//
//        }

//        ClimateChangeListener.onCycleModeChange(int mode){
//
//        }
//        AARLanDunListener.onUpStatus(int status) {
//        }


    }

    private void initView() {

        mIsVehicleRun = findViewById(R.id.is_vehicle_run);
        mGetFrontWindshieldHeatingState = findViewById(R.id.get_front_windshield_heating_state);
        mGetRearWindshieldHeatingStatus = findViewById(R.id.get_rear_windshield_heating_status);
        mGetAirddistModedr = findViewById(R.id.get_airddist_modedr);
        mGetCompressorRunStatus = findViewById(R.id.get_compressor_run_status);
        mGetGlobalProperty = findViewById(R.id.get_global_property);
        mIsCarFrontClimatePen = findViewById(R.id.is_car_front_climate_pen);
        mGetCarClimateCycleMode = findViewById(R.id.get_car_climate_cycle_mode);
        mSetCarClimateCycleMode = findViewById(R.id.set_car_climate_cycle_mode);
        mGetUpStatus = findViewById(R.id.get_up_status);
        mGetGlobalProperty = findViewById(R.id.get_pm_value);


        mIsVehicleRun.setOnClickListener(this);
        mGetFrontWindshieldHeatingState.setOnClickListener(this);
        mGetRearWindshieldHeatingStatus.setOnClickListener(this);
        mGetAirddistModedr.setOnClickListener(this);
        mGetCompressorRunStatus.setOnClickListener(this);
        mGetGlobalProperty.setOnClickListener(this);
        mIsCarFrontClimatePen.setOnClickListener(this);
        mGetCarClimateCycleMode.setOnClickListener(this);
        mSetCarClimateCycleMode.setOnClickListener(this);
        mGetUpStatus.setOnClickListener(this);
        mGetGlobalProperty.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.is_vehicle_run:
//                AARLanManager.isVehicleRun();
                break;
            case R.id.get_front_windshield_heating_state:
//                AARLanManager.getFrontWindshieldHeatingState();
                break;
            case R.id.get_rear_windshield_heating_status:
//                AARLanManager.getRearWindshieldHeatingStatus();
                break;
            case R.id.get_airddist_modedr:
//                AARLanManager.getAirddistModedr();
                break;
            case R.id.get_compressor_run_status:
//                AARLanManager.getCompressorRunStatus();
                break;
            case R.id.get_global_property:
//                AARLanManager.getGlobalProperty(Integer.class,TYPE_PMSNSCABN_D_STAT=3);
                break;
            case R.id.is_car_front_climate_pen:
//                AARLanManager.isCarFrontClimateOpen();
                break;
            case R.id.get_car_climate_cycle_mode:
//                AARLanManager.getCarClimateCycleMode();
                break;
            case R.id.set_car_climate_cycle_mode:
//                AARLanManager.setCarClimateCycleMode();
                break;
            case R.id.get_up_status:
//                AARLanManager.getUpStatus();
                break;
            case R.id.get_pm_value:
//                 AARLanManager.getGlobalProperty(Integer.class, TYPE_PMCABN02MNTE_CONC_ACTL);
                break;
        }
    }
}